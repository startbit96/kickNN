

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bor. Mönchengladbach          34  12  3  2  47:18    9  5  3  39:22    86:40  +46   71
 2. Hertha BSC                    34  15  2  0  44:15    4  4  9  17:28    61:43  +18   63
 3. Eintracht Frankfurt           34  12  3  2  57:20    6  4  7  32:29    89:49  +40   61
 4. Hamburger SV                  34  11  5  1  33:14    7  2  8  22:24    55:38  +17   61
 5. 1. FC Köln                    34  12  2  3  45:16    5  5  7  32:35    77:51  +26   58
 6. Fortuna Düsseldorf            34  11  5  1  41:19    5  4  8  25:36    66:55  +11   57
 7. FC Schalke 04                 34  12  4  1  34:10    4  3 10  18:27    52:37  +15   55
 8. Kickers Offenbach             34  12  2  3  49:27    5  2 10  23:35    72:62  +10   55
 9. Eintracht Braunschweig        34  12  2  3  40:17    2  6  9  12:25    52:42  +10   50
10. Bayern München                34  10  3  4  35:24    4  3 10  22:39    57:63   -6   48
11. VfL Bochum                    34  13  3  1  42:16    1  2 14  11:37    53:53        47
12. 1. FC Kaiserslautern          34  11  3  3  34:11    2  2 13  22:44    56:55   +1   44
13. Rot-Weiss Essen               34   7  6  4  33:27    3  6  8  23:41    56:68  -12   42
14. MSV Duisburg                  34   8  4  5  35:31    4  2 11  24:46    59:77  -18   42
15. Werder Bremen                 34   8  4  5  30:23    1  3 13  15:46    45:69  -24   34
16. VfB Stuttgart                 34   8  3  6  31:23    0  5 12  19:56    50:79  -29   32
17. Tennis Borussia Berlin        34   4  4  9  22:35    1  2 14  16:54    38:89  -51   21
18. Wuppertaler SV                34   2  5 10  20:38    0  3 14  12:48    32:86  -54   14
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

