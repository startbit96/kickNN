# Summary

55 seasons, 2 levels (1 2), 83 teams in 80 datafiles

level 1
- 55 seasons: 2017-18 2016-17 2015-16 2014-15 2013-14 2012-13 2011-12 2010-11 2009-10 2008-09 2007-08 2006-07 2005-06 2004-05 2003-04 2002-03 2001-02 2000-01 1999-00 1998-99 1997-98 1996-97 1995-96 1994-95 1993-94 1992-93 1991-92 1990-91 1989-90 1988-89 1987-88 1986-87 1985-86 1984-85 1983-84 1982-83 1981-82 1980-81 1979-80 1978-79 1977-78 1976-77 1975-76 1974-75 1973-74 1972-73 1971-72 1970-71 1969-70 1968-69 1967-68 1966-67 1965-66 1964-65 1963-64 
- 55 teams: 1. FC Kaiserslautern (44) 1. FC Köln (47) 1. FC Nürnberg (32) 1. FC Saarbrücken (5) 1. FSV Mainz 05 (12) Alemannia Aachen (4) Arminia Bielefeld (17) Bayer 04 Leverkusen (39) Bayern München (53) Blau-Weiß 90 Berlin (-1992) (1) Bor. Mönchengladbach (50) Borussia Dortmund (51) Borussia Neunkirchen (3) Dynamo Dresden (4) Eintracht Braunschweig (21) Eintracht Frankfurt (49) Energie Cottbus (6) FC 08 Homburg (3) FC Augsburg (7) FC Ingolstadt 04 (2) FC Schalke 04 (50) FC St. Pauli (8) Fortuna Düsseldorf (23) Fortuna Köln (1) Greuther Fürth (1) Hamburger SV (55) Hannover 96 (29) Hansa Rostock (12) Hertha BSC (35) KFC Uerdingen (14) Karlsruher SC (24) Kickers Offenbach (7) MSV Duisburg (28) Preussen Münster (1) RB Leipzig (2) Rot-Weiss Essen (7) Rot-Weiß Oberhausen (4) SC Freiburg (18) SC Paderborn 07 (1) SC Tasmania 1900 Berlin (-1973) (1) SG Wattenscheid 09 (4) SSV Ulm 1846 (1) SV Darmstadt 98 (4) SV Waldhof Mannheim (7) SpVgg Unterhaching (2) Stuttgarter Kickers (2) TSG 1899 Hoffenheim (10) TSV 1860 München (20) Tennis Borussia Berlin (2) VfB Leipzig (-2004) (1) VfB Stuttgart (52) VfL Bochum (34) VfL Wolfsburg (21) Werder Bremen (54) Wuppertaler SV (3) 
  - 55 seasons: **Hamburger SV**
  - 54 seasons: **Werder Bremen**
  - 53 seasons: **Bayern München**
  - 52 seasons: **VfB Stuttgart**
  - 51 seasons: **Borussia Dortmund**
  - 50 seasons: **Bor. Mönchengladbach**, **FC Schalke 04**
  - 49 seasons: **Eintracht Frankfurt**
  - 47 seasons: **1. FC Köln**
  - 44 seasons: **1. FC Kaiserslautern**
  - 39 seasons: **Bayer 04 Leverkusen**
  - 35 seasons: **Hertha BSC**
  - 34 seasons: **VfL Bochum**
  - 32 seasons: **1. FC Nürnberg**
  - 29 seasons: **Hannover 96**
  - 28 seasons: **MSV Duisburg**
  - 24 seasons: **Karlsruher SC**
  - 23 seasons: **Fortuna Düsseldorf**
  - 21 seasons: **Eintracht Braunschweig**, **VfL Wolfsburg**
  - 20 seasons: **TSV 1860 München**
  - 18 seasons: **SC Freiburg**
  - 17 seasons: **Arminia Bielefeld**
  - 14 seasons: **KFC Uerdingen**
  - 12 seasons: **1. FSV Mainz 05**, **Hansa Rostock**
  - 10 seasons: **TSG 1899 Hoffenheim**
  - 8 seasons: **FC St. Pauli**
  - 7 seasons: **FC Augsburg**, **Kickers Offenbach**, **Rot-Weiss Essen**, **SV Waldhof Mannheim**
  - 6 seasons: **Energie Cottbus**
  - 5 seasons: **1. FC Saarbrücken**
  - 4 seasons: **Alemannia Aachen**, **Dynamo Dresden**, **Rot-Weiß Oberhausen**, **SG Wattenscheid 09**, **SV Darmstadt 98**
  - 3 seasons: **Borussia Neunkirchen**, **FC 08 Homburg**, **Wuppertaler SV**
  - 2 seasons: **FC Ingolstadt 04**, **RB Leipzig**, **SpVgg Unterhaching**, **Stuttgarter Kickers**, **Tennis Borussia Berlin**
  - 1 seasons: **Blau-Weiß 90 Berlin (-1992)**, **Fortuna Köln**, **Greuther Fürth**, **Preussen Münster**, **SC Paderborn 07**, **SC Tasmania 1900 Berlin (-1973)**, **SSV Ulm 1846**, **VfB Leipzig (-2004)**


level 2
- 25 seasons: 2017-18 2016-17 2015-16 2014-15 2013-14 2012-13 2011-12 2010-11 2009-10 2008-09 2007-08 2006-07 2005-06 2004-05 2003-04 2002-03 2001-02 2000-01 1999-00 1998-99 1997-98 1996-97 1995-96 1994-95 1993-94 
- 72 teams: 1. FC Heidenheim (4) 1. FC Kaiserslautern (11) 1. FC Köln (8) 1. FC Nürnberg (11) 1. FC Saarbrücken (6) 1. FC Schweinfurt 05 (1) 1. FC Union Berlin (12) 1. FSV Mainz 05 (13) Alemannia Aachen (12) Arminia Bielefeld (11) Bor. Mönchengladbach (3) Chemnitzer FC (5) Dynamo Dresden (7) Eintracht Braunschweig (9) Eintracht Frankfurt (6) Eintracht Trier (3) Energie Cottbus (11) FC 08 Homburg (2) FC Augsburg (5) FC Carl Zeiss Jena (6) FC Erzgebirge Aue (12) FC Ingolstadt 04 (7) FC Rot-Weiß Erfurt (1) FC St. Pauli (17) FSV Frankfurt (9) FSV Zwickau (4) Fortuna Düsseldorf (11) Fortuna Köln (7) Greuther Fürth (20) Gütersloh (3) Hannover 96 (8) Hansa Rostock (7) Hertha BSC (6) Holstein Kiel (1) KFC Uerdingen (4) Karlsruher SC (15) Kickers Offenbach (4) Lübeck (4) MSV Duisburg (14) Osnabrück (5) RB Leipzig (2) Rot Weiss Ahlen (8) Rot-Weiss Essen (4) Rot-Weiß Oberhausen (10) SC Freiburg (7) SC Paderborn 07 (9) SG Wattenscheid 09 (4) SSV Jahn Regensburg (3) SSV Reutlingen 05 (3) SSV Ulm 1846 (2) SV Babelsberg 03 (1) SV Darmstadt 98 (2) SV Meppen (5) SV Sandhausen (6) SV Wehen Wiesbaden (2) SpVgg Unterhaching (9) Sportfreunde Siegen (1) Stuttgarter Kickers (6) TSG 1899 Hoffenheim (1) TSV 1860 München (14) Tennis Borussia Berlin (3) TuS Koblenz (4) VfB Leipzig (-2004) (4) VfB Oldenburg (1) VfB Stuttgart (1) VfL Bochum (13) VfL Wolfsburg (4) VfR Aalen (3) VfR Mannheim (8) Wacker Burghausen (5) Wuppertaler SV (1) Würzburger Kickers (1) 
  - 20 seasons: **Greuther Fürth**
  - 17 seasons: **FC St. Pauli**
  - 15 seasons: **Karlsruher SC**
  - 14 seasons: **MSV Duisburg**, **TSV 1860 München**
  - 13 seasons: **1. FSV Mainz 05**, **VfL Bochum**
  - 12 seasons: **1. FC Union Berlin**, **Alemannia Aachen**, **FC Erzgebirge Aue**
  - 11 seasons: **1. FC Kaiserslautern**, **1. FC Nürnberg**, **Arminia Bielefeld**, **Energie Cottbus**, **Fortuna Düsseldorf**
  - 10 seasons: **Rot-Weiß Oberhausen**
  - 9 seasons: **Eintracht Braunschweig**, **FSV Frankfurt**, **SC Paderborn 07**, **SpVgg Unterhaching**
  - 8 seasons: **1. FC Köln**, **Hannover 96**, **Rot Weiss Ahlen**, **VfR Mannheim**
  - 7 seasons: **Dynamo Dresden**, **FC Ingolstadt 04**, **Fortuna Köln**, **Hansa Rostock**, **SC Freiburg**
  - 6 seasons: **1. FC Saarbrücken**, **Eintracht Frankfurt**, **FC Carl Zeiss Jena**, **Hertha BSC**, **SV Sandhausen**, **Stuttgarter Kickers**
  - 5 seasons: **Chemnitzer FC**, **FC Augsburg**, **Osnabrück**, **SV Meppen**, **Wacker Burghausen**
  - 4 seasons: **1. FC Heidenheim**, **FSV Zwickau**, **KFC Uerdingen**, **Kickers Offenbach**, **Lübeck**, **Rot-Weiss Essen**, **SG Wattenscheid 09**, **TuS Koblenz**, **VfB Leipzig (-2004)**, **VfL Wolfsburg**
  - 3 seasons: **Bor. Mönchengladbach**, **Eintracht Trier**, **Gütersloh**, **SSV Jahn Regensburg**, **SSV Reutlingen 05**, **Tennis Borussia Berlin**, **VfR Aalen**
  - 2 seasons: **FC 08 Homburg**, **RB Leipzig**, **SSV Ulm 1846**, **SV Darmstadt 98**, **SV Wehen Wiesbaden**
  - 1 seasons: **1. FC Schweinfurt 05**, **FC Rot-Weiß Erfurt**, **Holstein Kiel**, **SV Babelsberg 03**, **Sportfreunde Siegen**, **TSG 1899 Hoffenheim**, **VfB Oldenburg**, **VfB Stuttgart**, **Wuppertaler SV**, **Würzburger Kickers**


level 1 - 55 seasons:
- [`2010s/2017-18/1-bundesliga.csv`](2010s/2017-18/1-bundesliga.csv) =>  18 teams,  306 matches,  855 goals,  34 rounds,  Fri 18 Aug 2017 - Sat 12 May 2018
- [`2010s/2016-17/1-bundesliga.csv`](2010s/2016-17/1-bundesliga.csv) =>  18 teams,  306 matches,  877 goals,  34 rounds,  Fri 26 Aug 2016 - Sat 20 May 2017
- [`2010s/2015-16/1-bundesliga.csv`](2010s/2015-16/1-bundesliga.csv) =>  18 teams,  306 matches,  866 goals,  34 rounds,  Fri 14 Aug 2015 - Sat 14 May 2016
- [`2010s/2014-15/1-bundesliga.csv`](2010s/2014-15/1-bundesliga.csv) =>  18 teams,  306 matches,  843 goals,  34 rounds,  Fri 22 Aug 2014 - Sat 23 May 2015
- [`2010s/2013-14/1-bundesliga.csv`](2010s/2013-14/1-bundesliga.csv) =>  18 teams,  306 matches,  967 goals,  34 rounds,  Fri 09 Aug 2013 - Sat 10 May 2014
- [`2010s/2012-13/1-bundesliga.csv`](2010s/2012-13/1-bundesliga.csv) =>  18 teams,  306 matches,  898 goals,  34 rounds,  Fri 24 Aug 2012 - Sat 18 May 2013
- [`2010s/2011-12/1-bundesliga.csv`](2010s/2011-12/1-bundesliga.csv) =>  18 teams,  306 matches,  875 goals,  34 rounds,  Fri 05 Aug 2011 - Sat 05 May 2012
- [`2010s/2010-11/1-bundesliga.csv`](2010s/2010-11/1-bundesliga.csv) =>  18 teams,  306 matches,  894 goals,  34 rounds,  Fri 20 Aug 2010 - Sat 14 May 2011
- [`2000s/2009-10/1-bundesliga.csv`](2000s/2009-10/1-bundesliga.csv) =>  18 teams,  306 matches,  866 goals,  34 rounds,  Fri 07 Aug 2009 - Sat 08 May 2010
- [`2000s/2008-09/1-bundesliga.csv`](2000s/2008-09/1-bundesliga.csv) =>  18 teams,  306 matches,  894 goals,  34 rounds,  Fri 15 Aug 2008 - Sat 23 May 2009
- [`2000s/2007-08/1-bundesliga.csv`](2000s/2007-08/1-bundesliga.csv) =>  18 teams,  306 matches,  860 goals,  34 rounds,  Fri 10 Aug 2007 - Sat 17 May 2008
- [`2000s/2006-07/1-bundesliga.csv`](2000s/2006-07/1-bundesliga.csv) =>  18 teams,  306 matches,  837 goals,  34 rounds,  Fri 11 Aug 2006 - Sat 19 May 2007
- [`2000s/2005-06/1-bundesliga.csv`](2000s/2005-06/1-bundesliga.csv) =>  18 teams,  306 matches,  861 goals,  34 rounds,  Fri 05 Aug 2005 - Sat 13 May 2006
- [`2000s/2004-05/1-bundesliga.csv`](2000s/2004-05/1-bundesliga.csv) =>  18 teams,  306 matches,  890 goals,  34 rounds,  Fri 06 Aug 2004 - Sat 21 May 2005
- [`2000s/2003-04/1-bundesliga.csv`](2000s/2003-04/1-bundesliga.csv) =>  18 teams,  306 matches,  909 goals,  34 rounds,  Fri 01 Aug 2003 - Sat 22 May 2004
- [`2000s/2002-03/1-bundesliga.csv`](2000s/2002-03/1-bundesliga.csv) =>  18 teams,  306 matches,  821 goals,  34 rounds,  Fri 09 Aug 2002 - Sat 24 May 2003
- [`2000s/2001-02/1-bundesliga.csv`](2000s/2001-02/1-bundesliga.csv) =>  18 teams,  306 matches,  893 goals,  34 rounds,  Sat 28 Jul 2001 - Sat 04 May 2002
- [`2000s/2000-01/1-bundesliga.csv`](2000s/2000-01/1-bundesliga.csv) =>  18 teams,  306 matches,  897 goals,  34 rounds,  Fri 11 Aug 2000 - Sat 19 May 2001
- [`1990s/1999-00/1-bundesliga.csv`](1990s/1999-00/1-bundesliga.csv) =>  18 teams,  306 matches,  885 goals,  34 rounds,  Fri 13 Aug 1999 - Sat 20 May 2000
- [`1990s/1998-99/1-bundesliga.csv`](1990s/1998-99/1-bundesliga.csv) =>  18 teams,  306 matches,  866 goals,  34 rounds,  Fri 14 Aug 1998 - Sat 29 May 1999
- [`1990s/1997-98/1-bundesliga.csv`](1990s/1997-98/1-bundesliga.csv) =>  18 teams,  306 matches,  883 goals,  34 rounds,  Fri 01 Aug 1997 - Sat 09 May 1998
- [`1990s/1996-97/1-bundesliga.csv`](1990s/1996-97/1-bundesliga.csv) =>  18 teams,  306 matches,  911 goals,  34 rounds,  Fri 16 Aug 1996 - Sat 31 May 1997
- [`1990s/1995-96/1-bundesliga.csv`](1990s/1995-96/1-bundesliga.csv) =>  18 teams,  306 matches,  831 goals,  34 rounds,  Fri 11 Aug 1995 - Sat 18 May 1996
- [`1990s/1994-95/1-bundesliga.csv`](1990s/1994-95/1-bundesliga.csv) =>  18 teams,  306 matches,  918 goals,  34 rounds,  Fri 19 Aug 1994 - Sat 17 Jun 1995
- [`1990s/1993-94/1-bundesliga.csv`](1990s/1993-94/1-bundesliga.csv) =>  18 teams,  306 matches,  895 goals,  34 rounds,  Fri 06 Aug 1993 - Sat 07 May 1994
- [`1990s/1992-93/1-bundesliga.csv`](1990s/1992-93/1-bundesliga.csv) =>  18 teams,  306 matches,  893 goals,  34 rounds,  Fri 14 Aug 1992 - Sat 05 Jun 1993
- [`1990s/1991-92/1-bundesliga.csv`](1990s/1991-92/1-bundesliga.csv) =>  20 teams,  380 matches,  994 goals,  38 rounds,  Fri 02 Aug 1991 - Sat 16 May 1992
- [`1990s/1990-91/1-bundesliga.csv`](1990s/1990-91/1-bundesliga.csv) =>  18 teams,  306 matches,  886 goals,  34 rounds,  Wed 08 Aug 1990 - Sat 15 Jun 1991
- [`1980s/1989-90/1-bundesliga.csv`](1980s/1989-90/1-bundesliga.csv) =>  18 teams,  306 matches,  790 goals,  34 rounds,  Fri 28 Jul 1989 - Sat 12 May 1990
- [`1980s/1988-89/1-bundesliga.csv`](1980s/1988-89/1-bundesliga.csv) =>  18 teams,  306 matches,  852 goals,  34 rounds,  Fri 22 Jul 1988 - Sat 17 Jun 1989
- [`1980s/1987-88/1-bundesliga.csv`](1980s/1987-88/1-bundesliga.csv) =>  18 teams,  306 matches,  962 goals,  34 rounds,  Fri 31 Jul 1987 - Sat 21 May 1988
- [`1980s/1986-87/1-bundesliga.csv`](1980s/1986-87/1-bundesliga.csv) =>  18 teams,  306 matches,  990 goals,  34 rounds,  Fri 08 Aug 1986 - Tue 23 Jun 1987
- [`1980s/1985-86/1-bundesliga.csv`](1980s/1985-86/1-bundesliga.csv) =>  18 teams,  306 matches,  992 goals,  34 rounds,  Fri 09 Aug 1985 - Sat 26 Apr 1986
- [`1980s/1984-85/1-bundesliga.csv`](1980s/1984-85/1-bundesliga.csv) =>  18 teams,  306 matches,  1074 goals,  34 rounds,  Fri 24 Aug 1984 - Sat 08 Jun 1985
- [`1980s/1983-84/1-bundesliga.csv`](1980s/1983-84/1-bundesliga.csv) =>  18 teams,  306 matches,  1097 goals,  34 rounds,  Fri 12 Aug 1983 - Sat 26 May 1984
- [`1980s/1982-83/1-bundesliga.csv`](1980s/1982-83/1-bundesliga.csv) =>  18 teams,  306 matches,  1036 goals,  34 rounds,  Fri 20 Aug 1982 - Sat 04 Jun 1983
- [`1980s/1981-82/1-bundesliga.csv`](1980s/1981-82/1-bundesliga.csv) =>  18 teams,  306 matches,  1081 goals,  34 rounds,  Sat 08 Aug 1981 - Sat 29 May 1982
- [`1980s/1980-81/1-bundesliga.csv`](1980s/1980-81/1-bundesliga.csv) =>  18 teams,  306 matches,  1039 goals,  34 rounds,  Fri 15 Aug 1980 - Sat 13 Jun 1981
- [`1970s/1979-80/1-bundesliga.csv`](1970s/1979-80/1-bundesliga.csv) =>  18 teams,  306 matches,  1023 goals,  34 rounds,  Sat 11 Aug 1979 - Sat 31 May 1980
- [`1970s/1978-79/1-bundesliga.csv`](1970s/1978-79/1-bundesliga.csv) =>  18 teams,  306 matches,  963 goals,  34 rounds,  Fri 11 Aug 1978 - Sat 09 Jun 1979
- [`1970s/1977-78/1-bundesliga.csv`](1970s/1977-78/1-bundesliga.csv) =>  18 teams,  306 matches,  1014 goals,  34 rounds,  Sat 06 Aug 1977 - Sat 29 Apr 1978
- [`1970s/1976-77/1-bundesliga.csv`](1970s/1976-77/1-bundesliga.csv) =>  18 teams,  306 matches,  1084 goals,  34 rounds,  Sat 14 Aug 1976 - Sat 21 May 1977
- [`1970s/1975-76/1-bundesliga.csv`](1970s/1975-76/1-bundesliga.csv) =>  18 teams,  306 matches,  1009 goals,  34 rounds,  Sat 09 Aug 1975 - Sat 12 Jun 1976
- [`1970s/1974-75/1-bundesliga.csv`](1970s/1974-75/1-bundesliga.csv) =>  18 teams,  306 matches,  1056 goals,  34 rounds,  Sat 24 Aug 1974 - Sat 14 Jun 1975
- [`1970s/1973-74/1-bundesliga.csv`](1970s/1973-74/1-bundesliga.csv) =>  18 teams,  306 matches,  1085 goals,  34 rounds,  Sat 11 Aug 1973 - Sat 18 May 1974
- [`1970s/1972-73/1-bundesliga.csv`](1970s/1972-73/1-bundesliga.csv) =>  18 teams,  306 matches,  1045 goals,  34 rounds,  Sat 16 Sep 1972 - Sat 09 Jun 1973
- [`1970s/1971-72/1-bundesliga.csv`](1970s/1971-72/1-bundesliga.csv) =>  18 teams,  306 matches,  1006 goals,  34 rounds,  Sat 14 Aug 1971 - Wed 28 Jun 1972
- [`1970s/1970-71/1-bundesliga.csv`](1970s/1970-71/1-bundesliga.csv) =>  18 teams,  306 matches,  926 goals,  34 rounds,  Sat 15 Aug 1970 - Sat 05 Jun 1971
- [`1960s/1969-70/1-bundesliga.csv`](1960s/1969-70/1-bundesliga.csv) =>  18 teams,  306 matches,  951 goals,  34 rounds,  Sat 16 Aug 1969 - Sun 03 May 1970
- [`1960s/1968-69/1-bundesliga.csv`](1960s/1968-69/1-bundesliga.csv) =>  18 teams,  306 matches,  873 goals,  34 rounds,  Sat 17 Aug 1968 - Sat 07 Jun 1969
- [`1960s/1967-68/1-bundesliga.csv`](1960s/1967-68/1-bundesliga.csv) =>  18 teams,  306 matches,  993 goals,  34 rounds,  Fri 18 Aug 1967 - Tue 28 May 1968
- [`1960s/1966-67/1-bundesliga.csv`](1960s/1966-67/1-bundesliga.csv) =>  18 teams,  306 matches,  895 goals,  34 rounds,  Sat 20 Aug 1966 - Sat 03 Jun 1967
- [`1960s/1965-66/1-bundesliga.csv`](1960s/1965-66/1-bundesliga.csv) =>  18 teams,  306 matches,  987 goals,  34 rounds,  Sat 14 Aug 1965 - Sat 28 May 1966
- [`1960s/1964-65/1-bundesliga.csv`](1960s/1964-65/1-bundesliga.csv) =>  16 teams,  240 matches,  796 goals,  30 rounds,  Sat 22 Aug 1964 - Sat 15 May 1965
- [`1960s/1963-64/1-bundesliga.csv`](1960s/1963-64/1-bundesliga.csv) =>  16 teams,  240 matches,  857 goals,  30 rounds,  Sat 24 Aug 1963 - Sat 09 May 1964


level 2 - 25 seasons:
- [`2010s/2017-18/2-bundesliga2.csv`](2010s/2017-18/2-bundesliga2.csv) =>  18 teams,  306 matches,  843 goals,  34 rounds,  Fri 28 Jul 2017 - Sun 13 May 2018
- [`2010s/2016-17/2-bundesliga2.csv`](2010s/2016-17/2-bundesliga2.csv) =>  18 teams,  306 matches,  761 goals,  34 rounds,  Fri 05 Aug 2016 - Sun 21 May 2017
- [`2010s/2015-16/2-bundesliga2.csv`](2010s/2015-16/2-bundesliga2.csv) =>  18 teams,  306 matches,  808 goals,  34 rounds,  Fri 24 Jul 2015 - Sun 15 May 2016
- [`2010s/2014-15/2-bundesliga2.csv`](2010s/2014-15/2-bundesliga2.csv) =>  18 teams,  306 matches,  763 goals,  34 rounds,  Fri 01 Aug 2014 - Sun 24 May 2015
- [`2010s/2013-14/2-bundesliga2.csv`](2010s/2013-14/2-bundesliga2.csv) =>  18 teams,  306 matches,  785 goals,  34 rounds,  Fri 19 Jul 2013 - Sun 11 May 2014
- [`2010s/2012-13/2-bundesliga2.csv`](2010s/2012-13/2-bundesliga2.csv) =>  18 teams,  306 matches,  790 goals,  34 rounds,  Fri 03 Aug 2012 - Sun 19 May 2013
- [`2010s/2011-12/2-bundesliga2.csv`](2010s/2011-12/2-bundesliga2.csv) =>  18 teams,  306 matches,  855 goals,  34 rounds,  Fri 15 Jul 2011 - Sun 06 May 2012
- [`2010s/2010-11/2-bundesliga2.csv`](2010s/2010-11/2-bundesliga2.csv) =>  18 teams,  306 matches,  835 goals,  34 rounds,  Fri 20 Aug 2010 - Sun 15 May 2011
- [`2000s/2009-10/2-bundesliga2.csv`](2000s/2009-10/2-bundesliga2.csv) =>  18 teams,  306 matches,  809 goals,  34 rounds,  Fri 07 Aug 2009 - Sun 09 May 2010
- [`2000s/2008-09/2-bundesliga2.csv`](2000s/2008-09/2-bundesliga2.csv) =>  18 teams,  306 matches,  852 goals,  34 rounds,  Fri 15 Aug 2008 - Sun 24 May 2009
- [`2000s/2007-08/2-bundesliga2.csv`](2000s/2007-08/2-bundesliga2.csv) =>  18 teams,  306 matches,  872 goals,  34 rounds,  Fri 10 Aug 2007 - Sun 18 May 2008
- [`2000s/2006-07/2-bundesliga2.csv`](2000s/2006-07/2-bundesliga2.csv) =>  18 teams,  306 matches,  804 goals,  34 rounds,  Fri 11 Aug 2006 - Sun 20 May 2007
- [`2000s/2005-06/2-bundesliga2.csv`](2000s/2005-06/2-bundesliga2.csv) =>  18 teams,  306 matches,  794 goals,  34 rounds,  Sat 06 Aug 2005 - Sun 14 May 2006
- [`2000s/2004-05/2-bundesliga2.csv`](2000s/2004-05/2-bundesliga2.csv) =>  18 teams,  306 matches,  841 goals,  34 rounds,  Sat 07 Aug 2004 - Sun 22 May 2005
- [`2000s/2003-04/2-bundesliga2.csv`](2000s/2003-04/2-bundesliga2.csv) =>  18 teams,  306 matches,  842 goals,  34 rounds,  Sun 03 Aug 2003 - Sun 23 May 2004
- [`2000s/2002-03/2-bundesliga2.csv`](2000s/2002-03/2-bundesliga2.csv) =>  18 teams,  306 matches,  863 goals,  34 rounds,  Sat 10 Aug 2002 - Sun 25 May 2003
- [`2000s/2001-02/2-bundesliga2.csv`](2000s/2001-02/2-bundesliga2.csv) =>  18 teams,  306 matches,  962 goals,  34 rounds,  Fri 27 Jul 2001 - Sun 05 May 2002
- [`2000s/2000-01/2-bundesliga2.csv`](2000s/2000-01/2-bundesliga2.csv) =>  18 teams,  306 matches,  887 goals,  34 rounds,  Fri 11 Aug 2000 - Sun 20 May 2001
- [`1990s/1999-00/2-bundesliga2.csv`](1990s/1999-00/2-bundesliga2.csv) =>  18 teams,  306 matches,  865 goals,  34 rounds,  Fri 13 Aug 1999 - Thu 25 May 2000
- [`1990s/1998-99/2-bundesliga2.csv`](1990s/1998-99/2-bundesliga2.csv) =>  18 teams,  306 matches,  822 goals,  34 rounds,  Thu 30 Jul 1998 - Thu 17 Jun 1999
- [`1990s/1997-98/2-bundesliga2.csv`](1990s/1997-98/2-bundesliga2.csv) =>  18 teams,  306 matches,  774 goals,  34 rounds,  Fri 25 Jul 1997 - Sun 07 Jun 1998
- [`1990s/1996-97/2-bundesliga2.csv`](1990s/1996-97/2-bundesliga2.csv) =>  18 teams,  306 matches,  822 goals,  34 rounds,  Fri 02 Aug 1996 - Wed 11 Jun 1997
- [`1990s/1995-96/2-bundesliga2.csv`](1990s/1995-96/2-bundesliga2.csv) =>  18 teams,  306 matches,  791 goals,  34 rounds,  Fri 04 Aug 1995 - Sat 08 Jun 1996
- [`1990s/1994-95/2-bundesliga2.csv`](1990s/1994-95/2-bundesliga2.csv) =>  18 teams,  306 matches,  858 goals,  34 rounds,  Sat 20 Aug 1994 - Sun 18 Jun 1995
- [`1990s/1993-94/2-bundesliga2.csv`](1990s/1993-94/2-bundesliga2.csv) =>  20 teams,  380 matches,  949 goals,  38 rounds,  Wed 28 Jul 1993 - Sat 11 Jun 1994


2017-18 - 2 levels (1 2)
  - 1: [`2010s/2017-18/1-bundesliga.csv`](2010s/2017-18/1-bundesliga.csv) -  18 teams,  306 matches,  855 goals,  34 rounds,  Fri 18 Aug 2017 - Sat 12 May 2018
    - 1. FC Köln, 1. FSV Mainz 05, Bayer 04 Leverkusen, Bayern München, Bor. Mönchengladbach, Borussia Dortmund, Eintracht Frankfurt, FC Augsburg, FC Schalke 04, Hamburger SV, Hannover 96, Hertha BSC, RB Leipzig, SC Freiburg, TSG 1899 Hoffenheim, VfB Stuttgart, VfL Wolfsburg, Werder Bremen
      - (++) new in season 2017-18: (2) Hannover 96, VfB Stuttgart
      - (--) out down: (2) FC Ingolstadt 04, SV Darmstadt 98

  - 2: [`2010s/2017-18/2-bundesliga2.csv`](2010s/2017-18/2-bundesliga2.csv) -  18 teams,  306 matches,  843 goals,  34 rounds,  Fri 28 Jul 2017 - Sun 13 May 2018
    - 1. FC Heidenheim, 1. FC Kaiserslautern, 1. FC Nürnberg, 1. FC Union Berlin, Arminia Bielefeld, Dynamo Dresden, Eintracht Braunschweig, FC Erzgebirge Aue, FC Ingolstadt 04, FC St. Pauli, Fortuna Düsseldorf, Greuther Fürth, Holstein Kiel, MSV Duisburg, SSV Jahn Regensburg, SV Darmstadt 98, SV Sandhausen, VfL Bochum
      - (++) new in season 2017-18: (5) FC Ingolstadt 04, Holstein Kiel, MSV Duisburg, SSV Jahn Regensburg, SV Darmstadt 98
      - (--) out up/down: (5) Hannover 96, Karlsruher SC, TSV 1860 München, VfB Stuttgart, Würzburger Kickers

2016-17 - 2 levels (1 2)
  - 1: [`2010s/2016-17/1-bundesliga.csv`](2010s/2016-17/1-bundesliga.csv) -  18 teams,  306 matches,  877 goals,  34 rounds,  Fri 26 Aug 2016 - Sat 20 May 2017
    - 1. FC Köln, 1. FSV Mainz 05, Bayer 04 Leverkusen, Bayern München, Bor. Mönchengladbach, Borussia Dortmund, Eintracht Frankfurt, FC Augsburg, FC Ingolstadt 04, FC Schalke 04, Hamburger SV, Hertha BSC, RB Leipzig, SC Freiburg, SV Darmstadt 98, TSG 1899 Hoffenheim, VfL Wolfsburg, Werder Bremen
      - (++) new in season 2016-17: (2) RB Leipzig, SC Freiburg
      - (--) out down: (2) Hannover 96, VfB Stuttgart

  - 2: [`2010s/2016-17/2-bundesliga2.csv`](2010s/2016-17/2-bundesliga2.csv) -  18 teams,  306 matches,  761 goals,  34 rounds,  Fri 5 Aug 2016 - Sun 21 May 2017
    - 1. FC Heidenheim, 1. FC Kaiserslautern, 1. FC Nürnberg, 1. FC Union Berlin, Arminia Bielefeld, Dynamo Dresden, Eintracht Braunschweig, FC Erzgebirge Aue, FC St. Pauli, Fortuna Düsseldorf, Greuther Fürth, Hannover 96, Karlsruher SC, SV Sandhausen, TSV 1860 München, VfB Stuttgart, VfL Bochum, Würzburger Kickers
      - (++) new in season 2016-17: (5) Dynamo Dresden, FC Erzgebirge Aue, Hannover 96, VfB Stuttgart, Würzburger Kickers
      - (--) out up/down: (5) FSV Frankfurt, MSV Duisburg, RB Leipzig, SC Freiburg, SC Paderborn 07

2015-16 - 2 levels (1 2)
  - 1: [`2010s/2015-16/1-bundesliga.csv`](2010s/2015-16/1-bundesliga.csv) -  18 teams,  306 matches,  866 goals,  34 rounds,  Fri 14 Aug 2015 - Sat 14 May 2016
    - 1. FC Köln, 1. FSV Mainz 05, Bayer 04 Leverkusen, Bayern München, Bor. Mönchengladbach, Borussia Dortmund, Eintracht Frankfurt, FC Augsburg, FC Ingolstadt 04, FC Schalke 04, Hamburger SV, Hannover 96, Hertha BSC, SV Darmstadt 98, TSG 1899 Hoffenheim, VfB Stuttgart, VfL Wolfsburg, Werder Bremen
      - (++) new in season 2015-16: (2) FC Ingolstadt 04, SV Darmstadt 98
      - (--) out down: (2) SC Freiburg, SC Paderborn 07

  - 2: [`2010s/2015-16/2-bundesliga2.csv`](2010s/2015-16/2-bundesliga2.csv) -  18 teams,  306 matches,  808 goals,  34 rounds,  Fri 24 Jul 2015 - Sun 15 May 2016
    - 1. FC Heidenheim, 1. FC Kaiserslautern, 1. FC Nürnberg, 1. FC Union Berlin, Arminia Bielefeld, Eintracht Braunschweig, FC St. Pauli, FSV Frankfurt, Fortuna Düsseldorf, Greuther Fürth, Karlsruher SC, MSV Duisburg, RB Leipzig, SC Freiburg, SC Paderborn 07, SV Sandhausen, TSV 1860 München, VfL Bochum
      - (++) new in season 2015-16: (4) Arminia Bielefeld, MSV Duisburg, SC Freiburg, SC Paderborn 07
      - (--) out up/down: (4) FC Erzgebirge Aue, FC Ingolstadt 04, SV Darmstadt 98, VfR Aalen

2014-15 - 2 levels (1 2)
  - 1: [`2010s/2014-15/1-bundesliga.csv`](2010s/2014-15/1-bundesliga.csv) -  18 teams,  306 matches,  843 goals,  34 rounds,  Fri 22 Aug 2014 - Sat 23 May 2015
    - 1. FC Köln, 1. FSV Mainz 05, Bayer 04 Leverkusen, Bayern München, Bor. Mönchengladbach, Borussia Dortmund, Eintracht Frankfurt, FC Augsburg, FC Schalke 04, Hamburger SV, Hannover 96, Hertha BSC, SC Freiburg, SC Paderborn 07, TSG 1899 Hoffenheim, VfB Stuttgart, VfL Wolfsburg, Werder Bremen
      - (++) new in season 2014-15: (2) 1. FC Köln, SC Paderborn 07
      - (--) out down: (2) 1. FC Nürnberg, Eintracht Braunschweig

  - 2: [`2010s/2014-15/2-bundesliga2.csv`](2010s/2014-15/2-bundesliga2.csv) -  18 teams,  306 matches,  763 goals,  34 rounds,  Fri 1 Aug 2014 - Sun 24 May 2015
    - 1. FC Heidenheim, 1. FC Kaiserslautern, 1. FC Nürnberg, 1. FC Union Berlin, Eintracht Braunschweig, FC Erzgebirge Aue, FC Ingolstadt 04, FC St. Pauli, FSV Frankfurt, Fortuna Düsseldorf, Greuther Fürth, Karlsruher SC, RB Leipzig, SV Darmstadt 98, SV Sandhausen, TSV 1860 München, VfL Bochum, VfR Aalen
      - (++) new in season 2014-15: (5) 1. FC Heidenheim, 1. FC Nürnberg, Eintracht Braunschweig, RB Leipzig, SV Darmstadt 98
      - (--) out up/down: (5) 1. FC Köln, Arminia Bielefeld, Dynamo Dresden, Energie Cottbus, SC Paderborn 07

2013-14 - 2 levels (1 2)
  - 1: [`2010s/2013-14/1-bundesliga.csv`](2010s/2013-14/1-bundesliga.csv) -  18 teams,  306 matches,  967 goals,  34 rounds,  Fri 9 Aug 2013 - Sat 10 May 2014
    - 1. FC Nürnberg, 1. FSV Mainz 05, Bayer 04 Leverkusen, Bayern München, Bor. Mönchengladbach, Borussia Dortmund, Eintracht Braunschweig, Eintracht Frankfurt, FC Augsburg, FC Schalke 04, Hamburger SV, Hannover 96, Hertha BSC, SC Freiburg, TSG 1899 Hoffenheim, VfB Stuttgart, VfL Wolfsburg, Werder Bremen
      - (++) new in season 2013-14: (2) Eintracht Braunschweig, Hertha BSC
      - (--) out down: (2) Fortuna Düsseldorf, Greuther Fürth

  - 2: [`2010s/2013-14/2-bundesliga2.csv`](2010s/2013-14/2-bundesliga2.csv) -  18 teams,  306 matches,  785 goals,  34 rounds,  Fri 19 Jul 2013 - Sun 11 May 2014
    - 1. FC Kaiserslautern, 1. FC Köln, 1. FC Union Berlin, Arminia Bielefeld, Dynamo Dresden, Energie Cottbus, FC Erzgebirge Aue, FC Ingolstadt 04, FC St. Pauli, FSV Frankfurt, Fortuna Düsseldorf, Greuther Fürth, Karlsruher SC, SC Paderborn 07, SV Sandhausen, TSV 1860 München, VfL Bochum, VfR Aalen
      - (++) new in season 2013-14: (4) Arminia Bielefeld, Fortuna Düsseldorf, Greuther Fürth, Karlsruher SC
      - (--) out up/down: (4) Eintracht Braunschweig, Hertha BSC, MSV Duisburg, SSV Jahn Regensburg

2012-13 - 2 levels (1 2)
  - 1: [`2010s/2012-13/1-bundesliga.csv`](2010s/2012-13/1-bundesliga.csv) -  18 teams,  306 matches,  898 goals,  34 rounds,  Fri 24 Aug 2012 - Sat 18 May 2013
    - 1. FC Nürnberg, 1. FSV Mainz 05, Bayer 04 Leverkusen, Bayern München, Bor. Mönchengladbach, Borussia Dortmund, Eintracht Frankfurt, FC Augsburg, FC Schalke 04, Fortuna Düsseldorf, Greuther Fürth, Hamburger SV, Hannover 96, SC Freiburg, TSG 1899 Hoffenheim, VfB Stuttgart, VfL Wolfsburg, Werder Bremen
      - (++) new in season 2012-13: (3) Eintracht Frankfurt, Fortuna Düsseldorf, Greuther Fürth
      - (--) out down: (3) 1. FC Kaiserslautern, 1. FC Köln, Hertha BSC

  - 2: [`2010s/2012-13/2-bundesliga2.csv`](2010s/2012-13/2-bundesliga2.csv) -  18 teams,  306 matches,  790 goals,  34 rounds,  Fri 3 Aug 2012 - Sun 19 May 2013
    - 1. FC Kaiserslautern, 1. FC Köln, 1. FC Union Berlin, Dynamo Dresden, Eintracht Braunschweig, Energie Cottbus, FC Erzgebirge Aue, FC Ingolstadt 04, FC St. Pauli, FSV Frankfurt, Hertha BSC, MSV Duisburg, SC Paderborn 07, SSV Jahn Regensburg, SV Sandhausen, TSV 1860 München, VfL Bochum, VfR Aalen
      - (++) new in season 2012-13: (6) 1. FC Kaiserslautern, 1. FC Köln, Hertha BSC, SSV Jahn Regensburg, SV Sandhausen, VfR Aalen
      - (--) out up/down: (6) Alemannia Aachen, Eintracht Frankfurt, Fortuna Düsseldorf, Greuther Fürth, Hansa Rostock, Karlsruher SC

2011-12 - 2 levels (1 2)
  - 1: [`2010s/2011-12/1-bundesliga.csv`](2010s/2011-12/1-bundesliga.csv) -  18 teams,  306 matches,  875 goals,  34 rounds,  Fri 5 Aug 2011 - Sat 5 May 2012
    - 1. FC Kaiserslautern, 1. FC Köln, 1. FC Nürnberg, 1. FSV Mainz 05, Bayer 04 Leverkusen, Bayern München, Bor. Mönchengladbach, Borussia Dortmund, FC Augsburg, FC Schalke 04, Hamburger SV, Hannover 96, Hertha BSC, SC Freiburg, TSG 1899 Hoffenheim, VfB Stuttgart, VfL Wolfsburg, Werder Bremen
      - (++) new in season 2011-12: (2) FC Augsburg, Hertha BSC
      - (--) out down: (2) Eintracht Frankfurt, FC St. Pauli

  - 2: [`2010s/2011-12/2-bundesliga2.csv`](2010s/2011-12/2-bundesliga2.csv) -  18 teams,  306 matches,  855 goals,  34 rounds,  Fri 15 Jul 2011 - Sun 6 May 2012
    - 1. FC Union Berlin, Alemannia Aachen, Dynamo Dresden, Eintracht Braunschweig, Eintracht Frankfurt, Energie Cottbus, FC Erzgebirge Aue, FC Ingolstadt 04, FC St. Pauli, FSV Frankfurt, Fortuna Düsseldorf, Greuther Fürth, Hansa Rostock, Karlsruher SC, MSV Duisburg, SC Paderborn 07, TSV 1860 München, VfL Bochum
      - (++) new in season 2011-12: (5) Dynamo Dresden, Eintracht Braunschweig, Eintracht Frankfurt, FC St. Pauli, Hansa Rostock
      - (--) out up/down: (5) Arminia Bielefeld, FC Augsburg, Hertha BSC, Osnabrück, Rot-Weiß Oberhausen

2010-11 - 2 levels (1 2)
  - 1: [`2010s/2010-11/1-bundesliga.csv`](2010s/2010-11/1-bundesliga.csv) -  18 teams,  306 matches,  894 goals,  34 rounds,  Fri 20 Aug 2010 - Sat 14 May 2011
    - 1. FC Kaiserslautern, 1. FC Köln, 1. FC Nürnberg, 1. FSV Mainz 05, Bayer 04 Leverkusen, Bayern München, Bor. Mönchengladbach, Borussia Dortmund, Eintracht Frankfurt, FC Schalke 04, FC St. Pauli, Hamburger SV, Hannover 96, SC Freiburg, TSG 1899 Hoffenheim, VfB Stuttgart, VfL Wolfsburg, Werder Bremen
      - (++) new in season 2010-11: (2) 1. FC Kaiserslautern, FC St. Pauli
      - (--) out down: (2) Hertha BSC, VfL Bochum

  - 2: [`2010s/2010-11/2-bundesliga2.csv`](2010s/2010-11/2-bundesliga2.csv) -  18 teams,  306 matches,  835 goals,  34 rounds,  Fri 20 Aug 2010 - Sun 15 May 2011
    - 1. FC Union Berlin, Alemannia Aachen, Arminia Bielefeld, Energie Cottbus, FC Augsburg, FC Erzgebirge Aue, FC Ingolstadt 04, FSV Frankfurt, Fortuna Düsseldorf, Greuther Fürth, Hertha BSC, Karlsruher SC, MSV Duisburg, Osnabrück, Rot-Weiß Oberhausen, SC Paderborn 07, TSV 1860 München, VfL Bochum
      - (++) new in season 2010-11: (5) FC Erzgebirge Aue, FC Ingolstadt 04, Hertha BSC, Osnabrück, VfL Bochum
      - (--) out up/down: (5) 1. FC Kaiserslautern, FC St. Pauli, Hansa Rostock, Rot Weiss Ahlen, TuS Koblenz

2009-10 - 2 levels (1 2)
  - 1: [`2000s/2009-10/1-bundesliga.csv`](2000s/2009-10/1-bundesliga.csv) -  18 teams,  306 matches,  866 goals,  34 rounds,  Fri 7 Aug 2009 - Sat 8 May 2010
    - 1. FC Köln, 1. FC Nürnberg, 1. FSV Mainz 05, Bayer 04 Leverkusen, Bayern München, Bor. Mönchengladbach, Borussia Dortmund, Eintracht Frankfurt, FC Schalke 04, Hamburger SV, Hannover 96, Hertha BSC, SC Freiburg, TSG 1899 Hoffenheim, VfB Stuttgart, VfL Bochum, VfL Wolfsburg, Werder Bremen
      - (++) new in season 2009-10: (3) 1. FC Nürnberg, 1. FSV Mainz 05, SC Freiburg
      - (--) out down: (3) Arminia Bielefeld, Energie Cottbus, Karlsruher SC

  - 2: [`2000s/2009-10/2-bundesliga2.csv`](2000s/2009-10/2-bundesliga2.csv) -  18 teams,  306 matches,  809 goals,  34 rounds,  Fri 7 Aug 2009 - Sun 9 May 2010
    - 1. FC Kaiserslautern, 1. FC Union Berlin, Alemannia Aachen, Arminia Bielefeld, Energie Cottbus, FC Augsburg, FC St. Pauli, FSV Frankfurt, Fortuna Düsseldorf, Greuther Fürth, Hansa Rostock, Karlsruher SC, MSV Duisburg, Rot Weiss Ahlen, Rot-Weiß Oberhausen, SC Paderborn 07, TSV 1860 München, TuS Koblenz
      - (++) new in season 2009-10: (6) 1. FC Union Berlin, Arminia Bielefeld, Energie Cottbus, Fortuna Düsseldorf, Karlsruher SC, SC Paderborn 07
      - (--) out up/down: (6) 1. FC Nürnberg, 1. FSV Mainz 05, FC Ingolstadt 04, Osnabrück, SC Freiburg, SV Wehen Wiesbaden

2008-09 - 2 levels (1 2)
  - 1: [`2000s/2008-09/1-bundesliga.csv`](2000s/2008-09/1-bundesliga.csv) -  18 teams,  306 matches,  894 goals,  34 rounds,  Fri 15 Aug 2008 - Sat 23 May 2009
    - 1. FC Köln, Arminia Bielefeld, Bayer 04 Leverkusen, Bayern München, Bor. Mönchengladbach, Borussia Dortmund, Eintracht Frankfurt, Energie Cottbus, FC Schalke 04, Hamburger SV, Hannover 96, Hertha BSC, Karlsruher SC, TSG 1899 Hoffenheim, VfB Stuttgart, VfL Bochum, VfL Wolfsburg, Werder Bremen
      - (++) new in season 2008-09: (3) 1. FC Köln, Bor. Mönchengladbach, TSG 1899 Hoffenheim
      - (--) out down: (3) 1. FC Nürnberg, Hansa Rostock, MSV Duisburg

  - 2: [`2000s/2008-09/2-bundesliga2.csv`](2000s/2008-09/2-bundesliga2.csv) -  18 teams,  306 matches,  852 goals,  34 rounds,  Fri 15 Aug 2008 - Sun 24 May 2009
    - 1. FC Kaiserslautern, 1. FC Nürnberg, 1. FSV Mainz 05, Alemannia Aachen, FC Augsburg, FC Ingolstadt 04, FC St. Pauli, FSV Frankfurt, Greuther Fürth, Hansa Rostock, MSV Duisburg, Osnabrück, Rot Weiss Ahlen, Rot-Weiß Oberhausen, SC Freiburg, SV Wehen Wiesbaden, TSV 1860 München, TuS Koblenz
      - (++) new in season 2008-09: (7) 1. FC Nürnberg, FC Ingolstadt 04, FSV Frankfurt, Hansa Rostock, MSV Duisburg, Rot Weiss Ahlen, Rot-Weiß Oberhausen
      - (--) out up/down: (7) 1. FC Köln, Bor. Mönchengladbach, FC Carl Zeiss Jena, FC Erzgebirge Aue, Kickers Offenbach, SC Paderborn 07, TSG 1899 Hoffenheim

2007-08 - 2 levels (1 2)
  - 1: [`2000s/2007-08/1-bundesliga.csv`](2000s/2007-08/1-bundesliga.csv) -  18 teams,  306 matches,  860 goals,  34 rounds,  Fri 10 Aug 2007 - Sat 17 May 2008
    - 1. FC Nürnberg, Arminia Bielefeld, Bayer 04 Leverkusen, Bayern München, Borussia Dortmund, Eintracht Frankfurt, Energie Cottbus, FC Schalke 04, Hamburger SV, Hannover 96, Hansa Rostock, Hertha BSC, Karlsruher SC, MSV Duisburg, VfB Stuttgart, VfL Bochum, VfL Wolfsburg, Werder Bremen
      - (++) new in season 2007-08: (3) Hansa Rostock, Karlsruher SC, MSV Duisburg
      - (--) out down: (3) 1. FSV Mainz 05, Alemannia Aachen, Bor. Mönchengladbach

  - 2: [`2000s/2007-08/2-bundesliga2.csv`](2000s/2007-08/2-bundesliga2.csv) -  18 teams,  306 matches,  872 goals,  34 rounds,  Fri 10 Aug 2007 - Sun 18 May 2008
    - 1. FC Kaiserslautern, 1. FC Köln, 1. FSV Mainz 05, Alemannia Aachen, Bor. Mönchengladbach, FC Augsburg, FC Carl Zeiss Jena, FC Erzgebirge Aue, FC St. Pauli, Greuther Fürth, Kickers Offenbach, Osnabrück, SC Freiburg, SC Paderborn 07, SV Wehen Wiesbaden, TSG 1899 Hoffenheim, TSV 1860 München, TuS Koblenz
      - (++) new in season 2007-08: (7) 1. FSV Mainz 05, Alemannia Aachen, Bor. Mönchengladbach, FC St. Pauli, Osnabrück, SV Wehen Wiesbaden, TSG 1899 Hoffenheim
      - (--) out up/down: (7) Eintracht Braunschweig, Hansa Rostock, Karlsruher SC, MSV Duisburg, Rot-Weiss Essen, SpVgg Unterhaching, Wacker Burghausen

2006-07 - 2 levels (1 2)
  - 1: [`2000s/2006-07/1-bundesliga.csv`](2000s/2006-07/1-bundesliga.csv) -  18 teams,  306 matches,  837 goals,  34 rounds,  Fri 11 Aug 2006 - Sat 19 May 2007
    - 1. FC Nürnberg, 1. FSV Mainz 05, Alemannia Aachen, Arminia Bielefeld, Bayer 04 Leverkusen, Bayern München, Bor. Mönchengladbach, Borussia Dortmund, Eintracht Frankfurt, Energie Cottbus, FC Schalke 04, Hamburger SV, Hannover 96, Hertha BSC, VfB Stuttgart, VfL Bochum, VfL Wolfsburg, Werder Bremen
      - (++) new in season 2006-07: (3) Alemannia Aachen, Energie Cottbus, VfL Bochum
      - (--) out down: (3) 1. FC Kaiserslautern, 1. FC Köln, MSV Duisburg

  - 2: [`2000s/2006-07/2-bundesliga2.csv`](2000s/2006-07/2-bundesliga2.csv) -  18 teams,  306 matches,  804 goals,  34 rounds,  Fri 11 Aug 2006 - Sun 20 May 2007
    - 1. FC Kaiserslautern, 1. FC Köln, Eintracht Braunschweig, FC Augsburg, FC Carl Zeiss Jena, FC Erzgebirge Aue, Greuther Fürth, Hansa Rostock, Karlsruher SC, Kickers Offenbach, MSV Duisburg, Rot-Weiss Essen, SC Freiburg, SC Paderborn 07, SpVgg Unterhaching, TSV 1860 München, TuS Koblenz, Wacker Burghausen
      - (++) new in season 2006-07: (7) 1. FC Kaiserslautern, 1. FC Köln, FC Augsburg, FC Carl Zeiss Jena, MSV Duisburg, Rot-Weiss Essen, TuS Koblenz
      - (--) out up/down: (7) 1. FC Saarbrücken, Alemannia Aachen, Dynamo Dresden, Energie Cottbus, Rot Weiss Ahlen, Sportfreunde Siegen, VfL Bochum

2005-06 - 2 levels (1 2)
  - 1: [`2000s/2005-06/1-bundesliga.csv`](2000s/2005-06/1-bundesliga.csv) -  18 teams,  306 matches,  861 goals,  34 rounds,  Fri 5 Aug 2005 - Sat 13 May 2006
    - 1. FC Kaiserslautern, 1. FC Köln, 1. FC Nürnberg, 1. FSV Mainz 05, Arminia Bielefeld, Bayer 04 Leverkusen, Bayern München, Bor. Mönchengladbach, Borussia Dortmund, Eintracht Frankfurt, FC Schalke 04, Hamburger SV, Hannover 96, Hertha BSC, MSV Duisburg, VfB Stuttgart, VfL Wolfsburg, Werder Bremen
      - (++) new in season 2005-06: (3) 1. FC Köln, Eintracht Frankfurt, MSV Duisburg
      - (--) out down: (3) Hansa Rostock, SC Freiburg, VfL Bochum

  - 2: [`2000s/2005-06/2-bundesliga2.csv`](2000s/2005-06/2-bundesliga2.csv) -  18 teams,  306 matches,  794 goals,  34 rounds,  Sat 6 Aug 2005 - Sun 14 May 2006
    - 1. FC Saarbrücken, Alemannia Aachen, Dynamo Dresden, Eintracht Braunschweig, Energie Cottbus, FC Erzgebirge Aue, Greuther Fürth, Hansa Rostock, Karlsruher SC, Kickers Offenbach, Rot Weiss Ahlen, SC Freiburg, SC Paderborn 07, SpVgg Unterhaching, Sportfreunde Siegen, TSV 1860 München, VfL Bochum, Wacker Burghausen
      - (++) new in season 2005-06: (7) Eintracht Braunschweig, Hansa Rostock, Kickers Offenbach, SC Freiburg, SC Paderborn 07, Sportfreunde Siegen, VfL Bochum
      - (--) out up/down: (7) 1. FC Köln, Eintracht Frankfurt, Eintracht Trier, FC Rot-Weiß Erfurt, MSV Duisburg, Rot-Weiss Essen, Rot-Weiß Oberhausen

2004-05 - 2 levels (1 2)
  - 1: [`2000s/2004-05/1-bundesliga.csv`](2000s/2004-05/1-bundesliga.csv) -  18 teams,  306 matches,  890 goals,  34 rounds,  Fri 6 Aug 2004 - Sat 21 May 2005
    - 1. FC Kaiserslautern, 1. FC Nürnberg, 1. FSV Mainz 05, Arminia Bielefeld, Bayer 04 Leverkusen, Bayern München, Bor. Mönchengladbach, Borussia Dortmund, FC Schalke 04, Hamburger SV, Hannover 96, Hansa Rostock, Hertha BSC, SC Freiburg, VfB Stuttgart, VfL Bochum, VfL Wolfsburg, Werder Bremen
      - (++) new in season 2004-05: (3) 1. FC Nürnberg, 1. FSV Mainz 05, Arminia Bielefeld
      - (--) out down: (3) 1. FC Köln, Eintracht Frankfurt, TSV 1860 München

  - 2: [`2000s/2004-05/2-bundesliga2.csv`](2000s/2004-05/2-bundesliga2.csv) -  18 teams,  306 matches,  841 goals,  34 rounds,  Sat 7 Aug 2004 - Sun 22 May 2005
    - 1. FC Köln, 1. FC Saarbrücken, Alemannia Aachen, Dynamo Dresden, Eintracht Frankfurt, Eintracht Trier, Energie Cottbus, FC Erzgebirge Aue, FC Rot-Weiß Erfurt, Greuther Fürth, Karlsruher SC, MSV Duisburg, Rot Weiss Ahlen, Rot-Weiss Essen, Rot-Weiß Oberhausen, SpVgg Unterhaching, TSV 1860 München, Wacker Burghausen
      - (++) new in season 2004-05: (7) 1. FC Köln, 1. FC Saarbrücken, Dynamo Dresden, Eintracht Frankfurt, FC Rot-Weiß Erfurt, Rot-Weiss Essen, TSV 1860 München
      - (--) out up/down: (7) 1. FC Nürnberg, 1. FC Union Berlin, 1. FSV Mainz 05, Arminia Bielefeld, Lübeck, Osnabrück, SSV Jahn Regensburg

2003-04 - 2 levels (1 2)
  - 1: [`2000s/2003-04/1-bundesliga.csv`](2000s/2003-04/1-bundesliga.csv) -  18 teams,  306 matches,  909 goals,  34 rounds,  Fri 1 Aug 2003 - Sat 22 May 2004
    - 1. FC Kaiserslautern, 1. FC Köln, Bayer 04 Leverkusen, Bayern München, Bor. Mönchengladbach, Borussia Dortmund, Eintracht Frankfurt, FC Schalke 04, Hamburger SV, Hannover 96, Hansa Rostock, Hertha BSC, SC Freiburg, TSV 1860 München, VfB Stuttgart, VfL Bochum, VfL Wolfsburg, Werder Bremen
      - (++) new in season 2003-04: (3) 1. FC Köln, Eintracht Frankfurt, SC Freiburg
      - (--) out down: (3) 1. FC Nürnberg, Arminia Bielefeld, Energie Cottbus

  - 2: [`2000s/2003-04/2-bundesliga2.csv`](2000s/2003-04/2-bundesliga2.csv) -  18 teams,  306 matches,  842 goals,  34 rounds,  Sun 3 Aug 2003 - Sun 23 May 2004
    - 1. FC Nürnberg, 1. FC Union Berlin, 1. FSV Mainz 05, Alemannia Aachen, Arminia Bielefeld, Eintracht Trier, Energie Cottbus, FC Erzgebirge Aue, Greuther Fürth, Karlsruher SC, Lübeck, MSV Duisburg, Osnabrück, Rot Weiss Ahlen, Rot-Weiß Oberhausen, SSV Jahn Regensburg, SpVgg Unterhaching, Wacker Burghausen
      - (++) new in season 2003-04: (7) 1. FC Nürnberg, Arminia Bielefeld, Energie Cottbus, FC Erzgebirge Aue, Osnabrück, SSV Jahn Regensburg, SpVgg Unterhaching
      - (--) out up/down: (7) 1. FC Köln, Eintracht Braunschweig, Eintracht Frankfurt, FC St. Pauli, SC Freiburg, SSV Reutlingen 05, VfR Mannheim

2002-03 - 2 levels (1 2)
  - 1: [`2000s/2002-03/1-bundesliga.csv`](2000s/2002-03/1-bundesliga.csv) -  18 teams,  306 matches,  821 goals,  34 rounds,  Fri 9 Aug 2002 - Sat 24 May 2003
    - 1. FC Kaiserslautern, 1. FC Nürnberg, Arminia Bielefeld, Bayer 04 Leverkusen, Bayern München, Bor. Mönchengladbach, Borussia Dortmund, Energie Cottbus, FC Schalke 04, Hamburger SV, Hannover 96, Hansa Rostock, Hertha BSC, TSV 1860 München, VfB Stuttgart, VfL Bochum, VfL Wolfsburg, Werder Bremen
      - (++) new in season 2002-03: (3) Arminia Bielefeld, Hannover 96, VfL Bochum
      - (--) out down: (3) 1. FC Köln, FC St. Pauli, SC Freiburg

  - 2: [`2000s/2002-03/2-bundesliga2.csv`](2000s/2002-03/2-bundesliga2.csv) -  18 teams,  306 matches,  863 goals,  34 rounds,  Sat 10 Aug 2002 - Sun 25 May 2003
    - 1. FC Köln, 1. FC Union Berlin, 1. FSV Mainz 05, Alemannia Aachen, Eintracht Braunschweig, Eintracht Frankfurt, Eintracht Trier, FC St. Pauli, Greuther Fürth, Karlsruher SC, Lübeck, MSV Duisburg, Rot Weiss Ahlen, Rot-Weiß Oberhausen, SC Freiburg, SSV Reutlingen 05, VfR Mannheim, Wacker Burghausen
      - (++) new in season 2002-03: (7) 1. FC Köln, Eintracht Braunschweig, Eintracht Trier, FC St. Pauli, Lübeck, SC Freiburg, Wacker Burghausen
      - (--) out up/down: (7) 1. FC Saarbrücken, 1. FC Schweinfurt 05, Arminia Bielefeld, Hannover 96, SV Babelsberg 03, SpVgg Unterhaching, VfL Bochum

2001-02 - 2 levels (1 2)
  - 1: [`2000s/2001-02/1-bundesliga.csv`](2000s/2001-02/1-bundesliga.csv) -  18 teams,  306 matches,  893 goals,  34 rounds,  Sat 28 Jul 2001 - Sat 4 May 2002
    - 1. FC Kaiserslautern, 1. FC Köln, 1. FC Nürnberg, Bayer 04 Leverkusen, Bayern München, Bor. Mönchengladbach, Borussia Dortmund, Energie Cottbus, FC Schalke 04, FC St. Pauli, Hamburger SV, Hansa Rostock, Hertha BSC, SC Freiburg, TSV 1860 München, VfB Stuttgart, VfL Wolfsburg, Werder Bremen
      - (++) new in season 2001-02: (3) 1. FC Nürnberg, Bor. Mönchengladbach, FC St. Pauli
      - (--) out down: (3) Eintracht Frankfurt, SpVgg Unterhaching, VfL Bochum

  - 2: [`2000s/2001-02/2-bundesliga2.csv`](2000s/2001-02/2-bundesliga2.csv) -  18 teams,  306 matches,  962 goals,  34 rounds,  Fri 27 Jul 2001 - Sun 5 May 2002
    - 1. FC Saarbrücken, 1. FC Schweinfurt 05, 1. FC Union Berlin, 1. FSV Mainz 05, Alemannia Aachen, Arminia Bielefeld, Eintracht Frankfurt, Greuther Fürth, Hannover 96, Karlsruher SC, MSV Duisburg, Rot Weiss Ahlen, Rot-Weiß Oberhausen, SSV Reutlingen 05, SV Babelsberg 03, SpVgg Unterhaching, VfL Bochum, VfR Mannheim
      - (++) new in season 2001-02: (7) 1. FC Schweinfurt 05, 1. FC Union Berlin, Eintracht Frankfurt, Karlsruher SC, SV Babelsberg 03, SpVgg Unterhaching, VfL Bochum
      - (--) out up/down: (7) 1. FC Nürnberg, Bor. Mönchengladbach, Chemnitzer FC, FC St. Pauli, Osnabrück, SSV Ulm 1846, Stuttgarter Kickers

2000-01 - 2 levels (1 2)
  - 1: [`2000s/2000-01/1-bundesliga.csv`](2000s/2000-01/1-bundesliga.csv) -  18 teams,  306 matches,  897 goals,  34 rounds,  Fri 11 Aug 2000 - Sat 19 May 2001
    - 1. FC Kaiserslautern, 1. FC Köln, Bayer 04 Leverkusen, Bayern München, Borussia Dortmund, Eintracht Frankfurt, Energie Cottbus, FC Schalke 04, Hamburger SV, Hansa Rostock, Hertha BSC, SC Freiburg, SpVgg Unterhaching, TSV 1860 München, VfB Stuttgart, VfL Bochum, VfL Wolfsburg, Werder Bremen
      - (++) new in season 2000-01: (3) 1. FC Köln, Energie Cottbus, VfL Bochum
      - (--) out down: (3) Arminia Bielefeld, MSV Duisburg, SSV Ulm 1846

  - 2: [`2000s/2000-01/2-bundesliga2.csv`](2000s/2000-01/2-bundesliga2.csv) -  18 teams,  306 matches,  887 goals,  34 rounds,  Fri 11 Aug 2000 - Sun 20 May 2001
    - 1. FC Nürnberg, 1. FC Saarbrücken, 1. FSV Mainz 05, Alemannia Aachen, Arminia Bielefeld, Bor. Mönchengladbach, Chemnitzer FC, FC St. Pauli, Greuther Fürth, Hannover 96, MSV Duisburg, Osnabrück, Rot Weiss Ahlen, Rot-Weiß Oberhausen, SSV Reutlingen 05, SSV Ulm 1846, Stuttgarter Kickers, VfR Mannheim
      - (++) new in season 2000-01: (7) 1. FC Saarbrücken, Arminia Bielefeld, MSV Duisburg, Osnabrück, Rot Weiss Ahlen, SSV Reutlingen 05, SSV Ulm 1846
      - (--) out up/down: (7) 1. FC Köln, Energie Cottbus, Fortuna Köln, Karlsruher SC, Kickers Offenbach, Tennis Borussia Berlin, VfL Bochum

1999-00 - 2 levels (1 2)
  - 1: [`1990s/1999-00/1-bundesliga.csv`](1990s/1999-00/1-bundesliga.csv) -  18 teams,  306 matches,  885 goals,  34 rounds,  Fri 13 Aug 1999 - Sat 20 May 2000
    - 1. FC Kaiserslautern, Arminia Bielefeld, Bayer 04 Leverkusen, Bayern München, Borussia Dortmund, Eintracht Frankfurt, FC Schalke 04, Hamburger SV, Hansa Rostock, Hertha BSC, MSV Duisburg, SC Freiburg, SSV Ulm 1846, SpVgg Unterhaching, TSV 1860 München, VfB Stuttgart, VfL Wolfsburg, Werder Bremen
      - (++) new in season 1999-00: (3) Arminia Bielefeld, SSV Ulm 1846, SpVgg Unterhaching
      - (--) out down: (3) 1. FC Nürnberg, Bor. Mönchengladbach, VfL Bochum

  - 2: [`1990s/1999-00/2-bundesliga2.csv`](1990s/1999-00/2-bundesliga2.csv) -  18 teams,  306 matches,  865 goals,  34 rounds,  Fri 13 Aug 1999 - Thu 25 May 2000
    - 1. FC Köln, 1. FC Nürnberg, 1. FSV Mainz 05, Alemannia Aachen, Bor. Mönchengladbach, Chemnitzer FC, Energie Cottbus, FC St. Pauli, Fortuna Köln, Greuther Fürth, Hannover 96, Karlsruher SC, Kickers Offenbach, Rot-Weiß Oberhausen, Stuttgarter Kickers, Tennis Borussia Berlin, VfL Bochum, VfR Mannheim
      - (++) new in season 1999-00: (7) 1. FC Nürnberg, Alemannia Aachen, Bor. Mönchengladbach, Chemnitzer FC, Kickers Offenbach, VfL Bochum, VfR Mannheim
      - (--) out up/down: (7) Arminia Bielefeld, Fortuna Düsseldorf, Gütersloh, KFC Uerdingen, SG Wattenscheid 09, SSV Ulm 1846, SpVgg Unterhaching

1998-99 - 2 levels (1 2)
  - 1: [`1990s/1998-99/1-bundesliga.csv`](1990s/1998-99/1-bundesliga.csv) -  18 teams,  306 matches,  866 goals,  34 rounds,  Fri 14 Aug 1998 - Sat 29 May 1999
    - 1. FC Kaiserslautern, 1. FC Nürnberg, Bayer 04 Leverkusen, Bayern München, Bor. Mönchengladbach, Borussia Dortmund, Eintracht Frankfurt, FC Schalke 04, Hamburger SV, Hansa Rostock, Hertha BSC, MSV Duisburg, SC Freiburg, TSV 1860 München, VfB Stuttgart, VfL Bochum, VfL Wolfsburg, Werder Bremen
      - (++) new in season 1998-99: (3) 1. FC Nürnberg, Eintracht Frankfurt, SC Freiburg
      - (--) out down: (3) 1. FC Köln, Arminia Bielefeld, Karlsruher SC

  - 2: [`1990s/1998-99/2-bundesliga2.csv`](1990s/1998-99/2-bundesliga2.csv) -  18 teams,  306 matches,  822 goals,  34 rounds,  Thu 30 Jul 1998 - Thu 17 Jun 1999
    - 1. FC Köln, 1. FSV Mainz 05, Arminia Bielefeld, Energie Cottbus, FC St. Pauli, Fortuna Düsseldorf, Fortuna Köln, Greuther Fürth, Gütersloh, Hannover 96, KFC Uerdingen, Karlsruher SC, Rot-Weiß Oberhausen, SG Wattenscheid 09, SSV Ulm 1846, SpVgg Unterhaching, Stuttgarter Kickers, Tennis Borussia Berlin
      - (++) new in season 1998-99: (7) 1. FC Köln, Arminia Bielefeld, Hannover 96, Karlsruher SC, Rot-Weiß Oberhausen, SSV Ulm 1846, Tennis Borussia Berlin
      - (--) out up/down: (7) 1. FC Nürnberg, Eintracht Frankfurt, FC Carl Zeiss Jena, FSV Zwickau, SC Freiburg, SV Meppen, VfB Leipzig (-2004)

1997-98 - 2 levels (1 2)
  - 1: [`1990s/1997-98/1-bundesliga.csv`](1990s/1997-98/1-bundesliga.csv) -  18 teams,  306 matches,  883 goals,  34 rounds,  Fri 1 Aug 1997 - Sat 9 May 1998
    - 1. FC Kaiserslautern, 1. FC Köln, Arminia Bielefeld, Bayer 04 Leverkusen, Bayern München, Bor. Mönchengladbach, Borussia Dortmund, FC Schalke 04, Hamburger SV, Hansa Rostock, Hertha BSC, Karlsruher SC, MSV Duisburg, TSV 1860 München, VfB Stuttgart, VfL Bochum, VfL Wolfsburg, Werder Bremen
      - (++) new in season 1997-98: (3) 1. FC Kaiserslautern, Hertha BSC, VfL Wolfsburg
      - (--) out down: (3) FC St. Pauli, Fortuna Düsseldorf, SC Freiburg

  - 2: [`1990s/1997-98/2-bundesliga2.csv`](1990s/1997-98/2-bundesliga2.csv) -  18 teams,  306 matches,  774 goals,  34 rounds,  Fri 25 Jul 1997 - Sun 7 Jun 1998
    - 1. FC Nürnberg, 1. FSV Mainz 05, Eintracht Frankfurt, Energie Cottbus, FC Carl Zeiss Jena, FC St. Pauli, FSV Zwickau, Fortuna Düsseldorf, Fortuna Köln, Greuther Fürth, Gütersloh, KFC Uerdingen, SC Freiburg, SG Wattenscheid 09, SV Meppen, SpVgg Unterhaching, Stuttgarter Kickers, VfB Leipzig (-2004)
      - (++) new in season 1997-98: (7) 1. FC Nürnberg, Energie Cottbus, FC St. Pauli, Fortuna Düsseldorf, Greuther Fürth, SC Freiburg, SG Wattenscheid 09
      - (--) out up/down: (7) 1. FC Kaiserslautern, Hertha BSC, Lübeck, Rot-Weiss Essen, VfB Oldenburg, VfL Wolfsburg, VfR Mannheim

1996-97 - 2 levels (1 2)
  - 1: [`1990s/1996-97/1-bundesliga.csv`](1990s/1996-97/1-bundesliga.csv) -  18 teams,  306 matches,  911 goals,  34 rounds,  Fri 16 Aug 1996 - Sat 31 May 1997
    - 1. FC Köln, Arminia Bielefeld, Bayer 04 Leverkusen, Bayern München, Bor. Mönchengladbach, Borussia Dortmund, FC Schalke 04, FC St. Pauli, Fortuna Düsseldorf, Hamburger SV, Hansa Rostock, Karlsruher SC, MSV Duisburg, SC Freiburg, TSV 1860 München, VfB Stuttgart, VfL Bochum, Werder Bremen
      - (++) new in season 1996-97: (3) Arminia Bielefeld, MSV Duisburg, VfL Bochum
      - (--) out down: (3) 1. FC Kaiserslautern, Eintracht Frankfurt, KFC Uerdingen

  - 2: [`1990s/1996-97/2-bundesliga2.csv`](1990s/1996-97/2-bundesliga2.csv) -  18 teams,  306 matches,  822 goals,  34 rounds,  Fri 2 Aug 1996 - Wed 11 Jun 1997
    - 1. FC Kaiserslautern, 1. FSV Mainz 05, Eintracht Frankfurt, FC Carl Zeiss Jena, FSV Zwickau, Fortuna Köln, Gütersloh, Hertha BSC, KFC Uerdingen, Lübeck, Rot-Weiss Essen, SV Meppen, SpVgg Unterhaching, Stuttgarter Kickers, VfB Leipzig (-2004), VfB Oldenburg, VfL Wolfsburg, VfR Mannheim
      - (++) new in season 1996-97: (7) 1. FC Kaiserslautern, Eintracht Frankfurt, Gütersloh, KFC Uerdingen, Rot-Weiss Essen, Stuttgarter Kickers, VfB Oldenburg
      - (--) out up/down: (7) 1. FC Nürnberg, Arminia Bielefeld, Chemnitzer FC, Hannover 96, MSV Duisburg, SG Wattenscheid 09, VfL Bochum

1995-96 - 2 levels (1 2)
  - 1: [`1990s/1995-96/1-bundesliga.csv`](1990s/1995-96/1-bundesliga.csv) -  18 teams,  306 matches,  831 goals,  34 rounds,  Fri 11 Aug 1995 - Sat 18 May 1996
    - 1. FC Kaiserslautern, 1. FC Köln, Bayer 04 Leverkusen, Bayern München, Bor. Mönchengladbach, Borussia Dortmund, Eintracht Frankfurt, FC Schalke 04, FC St. Pauli, Fortuna Düsseldorf, Hamburger SV, Hansa Rostock, KFC Uerdingen, Karlsruher SC, SC Freiburg, TSV 1860 München, VfB Stuttgart, Werder Bremen
      - (++) new in season 1995-96: (3) FC St. Pauli, Fortuna Düsseldorf, Hansa Rostock
      - (--) out down: (3) Dynamo Dresden, MSV Duisburg, VfL Bochum

  - 2: [`1990s/1995-96/2-bundesliga2.csv`](1990s/1995-96/2-bundesliga2.csv) -  18 teams,  306 matches,  791 goals,  34 rounds,  Fri 4 Aug 1995 - Sat 8 Jun 1996
    - 1. FC Nürnberg, 1. FSV Mainz 05, Arminia Bielefeld, Chemnitzer FC, FC Carl Zeiss Jena, FSV Zwickau, Fortuna Köln, Hannover 96, Hertha BSC, Lübeck, MSV Duisburg, SG Wattenscheid 09, SV Meppen, SpVgg Unterhaching, VfB Leipzig (-2004), VfL Bochum, VfL Wolfsburg, VfR Mannheim
      - (++) new in season 1995-96: (6) Arminia Bielefeld, FC Carl Zeiss Jena, Lübeck, MSV Duisburg, SpVgg Unterhaching, VfL Bochum
      - (--) out up/down: (6) 1. FC Saarbrücken, FC 08 Homburg, FC St. Pauli, FSV Frankfurt, Fortuna Düsseldorf, Hansa Rostock

1994-95 - 2 levels (1 2)
  - 1: [`1990s/1994-95/1-bundesliga.csv`](1990s/1994-95/1-bundesliga.csv) -  18 teams,  306 matches,  918 goals,  34 rounds,  Fri 19 Aug 1994 - Sat 17 Jun 1995
    - 1. FC Kaiserslautern, 1. FC Köln, Bayer 04 Leverkusen, Bayern München, Bor. Mönchengladbach, Borussia Dortmund, Dynamo Dresden, Eintracht Frankfurt, FC Schalke 04, Hamburger SV, KFC Uerdingen, Karlsruher SC, MSV Duisburg, SC Freiburg, TSV 1860 München, VfB Stuttgart, VfL Bochum, Werder Bremen
      - (++) new in season 1994-95: (3) KFC Uerdingen, TSV 1860 München, VfL Bochum
      - (--) out down: (3) 1. FC Nürnberg, SG Wattenscheid 09, VfB Leipzig (-2004)

  - 2: [`1990s/1994-95/2-bundesliga2.csv`](1990s/1994-95/2-bundesliga2.csv) -  18 teams,  306 matches,  858 goals,  34 rounds,  Sat 20 Aug 1994 - Sun 18 Jun 1995
    - 1. FC Nürnberg, 1. FC Saarbrücken, 1. FSV Mainz 05, Chemnitzer FC, FC 08 Homburg, FC St. Pauli, FSV Frankfurt, FSV Zwickau, Fortuna Düsseldorf, Fortuna Köln, Hannover 96, Hansa Rostock, Hertha BSC, SG Wattenscheid 09, SV Meppen, VfB Leipzig (-2004), VfL Wolfsburg, VfR Mannheim
      - (++) new in season 1994-95: (6) 1. FC Nürnberg, FSV Frankfurt, FSV Zwickau, Fortuna Düsseldorf, SG Wattenscheid 09, VfB Leipzig (-2004)
      - (--) out up/down: (8) FC Carl Zeiss Jena, KFC Uerdingen, Rot-Weiss Essen, Stuttgarter Kickers, TSV 1860 München, Tennis Borussia Berlin, VfL Bochum, Wuppertaler SV

1993-94 - 2 levels (1 2)
  - 1: [`1990s/1993-94/1-bundesliga.csv`](1990s/1993-94/1-bundesliga.csv) -  18 teams,  306 matches,  895 goals,  34 rounds,  Fri 6 Aug 1993 - Sat 7 May 1994
    - 1. FC Kaiserslautern, 1. FC Köln, 1. FC Nürnberg, Bayer 04 Leverkusen, Bayern München, Bor. Mönchengladbach, Borussia Dortmund, Dynamo Dresden, Eintracht Frankfurt, FC Schalke 04, Hamburger SV, Karlsruher SC, MSV Duisburg, SC Freiburg, SG Wattenscheid 09, VfB Leipzig (-2004), VfB Stuttgart, Werder Bremen
      - (++) new in season 1993-94: (3) MSV Duisburg, SC Freiburg, VfB Leipzig (-2004)
      - (--) out down: (3) 1. FC Saarbrücken, KFC Uerdingen, VfL Bochum

  - 2: [`1990s/1993-94/2-bundesliga2.csv`](1990s/1993-94/2-bundesliga2.csv) -  20 teams,  380 matches,  949 goals,  38 rounds,  Wed 28 Jul 1993 - Sat 11 Jun 1994
    - 1. FC Saarbrücken, 1. FSV Mainz 05, Chemnitzer FC, FC 08 Homburg, FC Carl Zeiss Jena, FC St. Pauli, Fortuna Köln, Hannover 96, Hansa Rostock, Hertha BSC, KFC Uerdingen, Rot-Weiss Essen, SV Meppen, Stuttgarter Kickers, TSV 1860 München, Tennis Borussia Berlin, VfL Bochum, VfL Wolfsburg, VfR Mannheim, Wuppertaler SV




## Teams

```
  83 teams:
    [1]  1. FC Heidenheim                ::  136 matches in   4 seasons / 1 levels -    x      2 (4)     
    [2]  1. FC Kaiserslautern            :: 1866 matches in  55 seasons / 2 levels - 1 (44)    2 (11)    
    [3]  1. FC Köln                      :: 1866 matches in  55 seasons / 2 levels - 1 (47)    2 (8)     
    [4]  1. FC Nürnberg                  :: 1458 matches in  43 seasons / 2 levels - 1 (32)    2 (11)    
    [5]  1. FC Saarbrücken               ::  374 matches in  11 seasons / 2 levels - 1 (5)     2 (6)     
    [6]  1. FC Schweinfurt 05            ::   34 matches in   1 seasons / 1 levels -    x      2 (1)     
    [7]  1. FC Union Berlin              ::  408 matches in  12 seasons / 1 levels -    x      2 (12)    
    [8]  1. FSV Mainz 05                 ::  854 matches in  25 seasons / 2 levels - 1 (12)    2 (13)    
    [9]  Alemannia Aachen                ::  544 matches in  16 seasons / 2 levels - 1 (4)     2 (12)    
   [10]  Arminia Bielefeld               ::  952 matches in  28 seasons / 2 levels - 1 (17)    2 (11)    
   [11]  Bayer 04 Leverkusen             :: 1330 matches in  39 seasons / 1 levels - 1 (39)       x      
   [12]  Bayern München                  :: 1806 matches in  53 seasons / 1 levels - 1 (53)       x      
   [13]  Blau-Weiß 90 Berlin (-1992)     ::   34 matches in   1 seasons / 1 levels - 1 (1)        x      
   [14]  Bor. Mönchengladbach            :: 1806 matches in  53 seasons / 2 levels - 1 (50)    2 (3)     
   [15]  Borussia Dortmund               :: 1730 matches in  51 seasons / 1 levels - 1 (51)       x      
   [16]  Borussia Neunkirchen            ::   98 matches in   3 seasons / 1 levels - 1 (3)        x      
   [17]  Chemnitzer FC                   ::  174 matches in   5 seasons / 1 levels -    x      2 (5)     
   [18]  Dynamo Dresden                  ::  378 matches in  11 seasons / 2 levels - 1 (4)     2 (7)     
   [19]  Eintracht Braunschweig          :: 1012 matches in  30 seasons / 2 levels - 1 (21)    2 (9)     
   [20]  Eintracht Frankfurt             :: 1866 matches in  55 seasons / 2 levels - 1 (49)    2 (6)     
   [21]  Eintracht Trier                 ::  102 matches in   3 seasons / 1 levels -    x      2 (3)     
   [22]  Energie Cottbus                 ::  578 matches in  17 seasons / 2 levels - 1 (6)     2 (11)    
   [23]  FC 08 Homburg                   ::  174 matches in   5 seasons / 2 levels - 1 (3)     2 (2)     
   [24]  FC Augsburg                     ::  408 matches in  12 seasons / 2 levels - 1 (7)     2 (5)     
   [25]  FC Carl Zeiss Jena              ::  208 matches in   6 seasons / 1 levels -    x      2 (6)     
   [26]  FC Erzgebirge Aue               ::  408 matches in  12 seasons / 1 levels -    x      2 (12)    
   [27]  FC Ingolstadt 04                ::  306 matches in   9 seasons / 2 levels - 1 (2)     2 (7)     
   [28]  FC Rot-Weiß Erfurt              ::   34 matches in   1 seasons / 1 levels -    x      2 (1)     
   [29]  FC Schalke 04                   :: 1696 matches in  50 seasons / 1 levels - 1 (50)       x      
   [30]  FC St. Pauli                    ::  854 matches in  25 seasons / 2 levels - 1 (8)     2 (17)    
   [31]  FSV Frankfurt                   ::  306 matches in   9 seasons / 1 levels -    x      2 (9)     
   [32]  FSV Zwickau                     ::  136 matches in   4 seasons / 1 levels -    x      2 (4)     
   [33]  Fortuna Düsseldorf              :: 1160 matches in  34 seasons / 2 levels - 1 (23)    2 (11)    
   [34]  Fortuna Köln                    ::  276 matches in   8 seasons / 2 levels - 1 (1)     2 (7)     
   [35]  Greuther Fürth                  ::  714 matches in  21 seasons / 2 levels - 1 (1)     2 (20)    
   [36]  Gütersloh                       ::  102 matches in   3 seasons / 1 levels -    x      2 (3)     
   [37]  Hamburger SV                    :: 1866 matches in  55 seasons / 1 levels - 1 (55)       x      
   [38]  Hannover 96                     :: 1258 matches in  37 seasons / 2 levels - 1 (29)    2 (8)     
   [39]  Hansa Rostock                   ::  654 matches in  19 seasons / 2 levels - 1 (12)    2 (7)     
   [40]  Hertha BSC                      :: 1390 matches in  41 seasons / 2 levels - 1 (35)    2 (6)     
   [41]  Holstein Kiel                   ::   34 matches in   1 seasons / 1 levels -    x      2 (1)     
   [42]  KFC Uerdingen                   ::  616 matches in  18 seasons / 2 levels - 1 (14)    2 (4)     
   [43]  Karlsruher SC                   :: 1322 matches in  39 seasons / 2 levels - 1 (24)    2 (15)    
   [44]  Kickers Offenbach               ::  374 matches in  11 seasons / 2 levels - 1 (7)     2 (4)     
   [45]  Lübeck                          ::  136 matches in   4 seasons / 1 levels -    x      2 (4)     
   [46]  MSV Duisburg                    :: 1424 matches in  42 seasons / 2 levels - 1 (28)    2 (14)    
   [47]  Osnabrück                       ::  170 matches in   5 seasons / 1 levels -    x      2 (5)     
   [48]  Preussen Münster                ::   30 matches in   1 seasons / 1 levels - 1 (1)        x      
   [49]  RB Leipzig                      ::  136 matches in   4 seasons / 2 levels - 1 (2)     2 (2)     
   [50]  Rot Weiss Ahlen                 ::  272 matches in   8 seasons / 1 levels -    x      2 (8)     
   [51]  Rot-Weiss Essen                 ::  378 matches in  11 seasons / 2 levels - 1 (7)     2 (4)     
   [52]  Rot-Weiß Oberhausen             ::  476 matches in  14 seasons / 2 levels - 1 (4)     2 (10)    
   [53]  SC Freiburg                     ::  850 matches in  25 seasons / 2 levels - 1 (18)    2 (7)     
   [54]  SC Paderborn 07                 ::  340 matches in  10 seasons / 2 levels - 1 (1)     2 (9)     
   [55]  SC Tasmania 1900 Berlin (-1973)  ::   34 matches in   1 seasons / 1 levels - 1 (1)        x      
   [56]  SG Wattenscheid 09              ::  276 matches in   8 seasons / 2 levels - 1 (4)     2 (4)     
   [57]  SSV Jahn Regensburg             ::  102 matches in   3 seasons / 1 levels -    x      2 (3)     
   [58]  SSV Reutlingen 05               ::  102 matches in   3 seasons / 1 levels -    x      2 (3)     
   [59]  SSV Ulm 1846                    ::  102 matches in   3 seasons / 2 levels - 1 (1)     2 (2)     
   [60]  SV Babelsberg 03                ::   34 matches in   1 seasons / 1 levels -    x      2 (1)     
   [61]  SV Darmstadt 98                 ::  204 matches in   6 seasons / 2 levels - 1 (4)     2 (2)     
   [62]  SV Meppen                       ::  174 matches in   5 seasons / 1 levels -    x      2 (5)     
   [63]  SV Sandhausen                   ::  204 matches in   6 seasons / 1 levels -    x      2 (6)     
   [64]  SV Waldhof Mannheim             ::  238 matches in   7 seasons / 1 levels - 1 (7)        x      
   [65]  SV Wehen Wiesbaden              ::   68 matches in   2 seasons / 1 levels -    x      2 (2)     
   [66]  SpVgg Unterhaching              ::  374 matches in  11 seasons / 2 levels - 1 (2)     2 (9)     
   [67]  Sportfreunde Siegen             ::   34 matches in   1 seasons / 1 levels -    x      2 (1)     
   [68]  Stuttgarter Kickers             ::  280 matches in   8 seasons / 2 levels - 1 (2)     2 (6)     
   [69]  TSG 1899 Hoffenheim             ::  374 matches in  11 seasons / 2 levels - 1 (10)    2 (1)     
   [70]  TSV 1860 München                :: 1152 matches in  34 seasons / 2 levels - 1 (20)    2 (14)    
   [71]  Tennis Borussia Berlin          ::  174 matches in   5 seasons / 2 levels - 1 (2)     2 (3)     
   [72]  TuS Koblenz                     ::  136 matches in   4 seasons / 1 levels -    x      2 (4)     
   [73]  VfB Leipzig (-2004)             ::  170 matches in   5 seasons / 2 levels - 1 (1)     2 (4)     
   [74]  VfB Oldenburg                   ::   34 matches in   1 seasons / 1 levels -    x      2 (1)     
   [75]  VfB Stuttgart                   :: 1798 matches in  53 seasons / 2 levels - 1 (52)    2 (1)     
   [76]  VfL Bochum                      :: 1606 matches in  47 seasons / 2 levels - 1 (34)    2 (13)    
   [77]  VfL Wolfsburg                   ::  854 matches in  25 seasons / 2 levels - 1 (21)    2 (4)     
   [78]  VfR Aalen                       ::  102 matches in   3 seasons / 1 levels -    x      2 (3)     
   [79]  VfR Mannheim                    ::  276 matches in   8 seasons / 1 levels -    x      2 (8)     
   [80]  Wacker Burghausen               ::  170 matches in   5 seasons / 1 levels -    x      2 (5)     
   [81]  Werder Bremen                   :: 1832 matches in  54 seasons / 1 levels - 1 (54)       x      
   [82]  Wuppertaler SV                  ::  140 matches in   4 seasons / 2 levels - 1 (3)     2 (1)     
   [83]  Würzburger Kickers              ::   34 matches in   1 seasons / 1 levels -    x      2 (1)     
```


### Team Name Mappings



```
1. FC Heidenheim            => Heidenheim
1. FC Kaiserslautern        => Kaiserslautern
1. FC Köln                  => (2) FC Koln • 1. FC Koeln
1. FC Nürnberg              => (2) Nurnberg • 1. FC Nuernberg
1. FC Saarbrücken           => (2) Saarbrucken • 1. FC Saarbruecken
1. FC Schweinfurt 05        => Schweinfurt
1. FC Union Berlin          => Union Berlin
1. FSV Mainz 05             => Mainz
Alemannia Aachen            => Aachen
Arminia Bielefeld           => Bielefeld
Bayer 04 Leverkusen         => (2) Leverkusen • Bayer Leverkusen
Bayern München              => (2) Bayern Munich • Bayern Muenchen
Blau-Weiß 90 Berlin (-1992)  => Blau-Weiss 90 Berlin
Bor. Mönchengladbach        => (3) M'gladbach • M'Gladbach • Bor. Moenchengladbach
Borussia Dortmund           => Dortmund
Borussia Neunkirchen        
Chemnitzer FC               => Chemnitz
Dynamo Dresden              => Dresden
Eintracht Braunschweig      => Braunschweig
Eintracht Frankfurt         => Ein Frankfurt
Eintracht Trier             => Ein Trier
Energie Cottbus             => Cottbus
FC 08 Homburg               => Homburg
FC Augsburg                 => Augsburg
FC Carl Zeiss Jena          => CZ Jena
FC Erzgebirge Aue           => Erzgebirge Aue
FC Ingolstadt 04            => Ingolstadt
FC Rot-Weiß Erfurt          => Erfurt
FC Schalke 04               => Schalke 04
FC St. Pauli                => (2) St Pauli • St. Pauli
FSV Frankfurt               => Frankfurt FSV
FSV Zwickau                 => Zwickau
Fortuna Düsseldorf          => (3) Dusseldorf • Fortuna Dusseldorf • Fortuna Duesseldorf
Fortuna Köln                => (2) F Koln • Fortuna Koeln
Greuther Fürth              => (2) Greuther Furth • SpVgg Greuther Fuerth
Gütersloh                   => Gutersloh
Hamburger SV                => Hamburg
Hannover 96                 => Hannover
Hansa Rostock               
Hertha BSC                  => Hertha
Holstein Kiel               
KFC Uerdingen               => (2) Uerdingen • Bayer 05 Uerdingen
Karlsruher SC               => Karlsruhe
Kickers Offenbach           => Offenbach
Lübeck                      => Lubeck
MSV Duisburg                => Duisburg
Osnabrück                   => Osnabruck
Preussen Münster            => Preussen Muenster
RB Leipzig                  
Rot Weiss Ahlen             => Ahlen
Rot-Weiss Essen             => (2) Essen • RW Essen
Rot-Weiß Oberhausen         => (2) Oberhausen • Rot-Weiss Oberhausen
SC Freiburg                 => Freiburg
SC Paderborn 07             => Paderborn
SC Tasmania 1900 Berlin (-1973)  => Tasmania 1900 Berlin
SG Wattenscheid 09          => Wattenscheid
SSV Jahn Regensburg         => Regensburg
SSV Reutlingen 05           => Reutlingen
SSV Ulm 1846                => Ulm
SV Babelsberg 03            => Babelsberg
SV Darmstadt 98             => Darmstadt
SV Meppen                   => Meppen
SV Sandhausen               => Sandhausen
SV Waldhof Mannheim         => Waldhof Mannheim
SV Wehen Wiesbaden          => Wehen
SpVgg Unterhaching          => Unterhaching
Sportfreunde Siegen         => Siegen
Stuttgarter Kickers         => Stuttgarter K
TSG 1899 Hoffenheim         => (2) Hoffenheim • 1899 Hoffenheim
TSV 1860 München            => (2) Munich 1860 • TSV 1860 Muenchen
Tennis Borussia Berlin      => (2) TB Berlin • TeBe Berlin
TuS Koblenz                 => Koblenz
VfB Leipzig (-2004)         => (2) Leipzig • VfB Leipzig
VfB Oldenburg               => Oldenburg
VfB Stuttgart               => Stuttgart
VfL Bochum                  => Bochum
VfL Wolfsburg               => Wolfsburg
VfR Aalen                   => Aalen
VfR Mannheim                => Mannheim
Wacker Burghausen           => Burghausen
Werder Bremen               
Wuppertaler SV              => Wuppertaler
Würzburger Kickers          => Wurzburger Kickers
```



### Teams by City

- **Berlin › Berlin** (5): 
  - 1. FC Union Berlin  (1) Union Berlin
  - Blau-Weiß 90 Berlin (-1992)  (1) Blau-Weiss 90 Berlin
  - Hertha BSC  (1) Hertha
  - SC Tasmania 1900 Berlin (-1973)  (1) Tasmania 1900 Berlin
  - Tennis Borussia Berlin  (2) TB Berlin • TeBe Berlin
- **Bochum › Nordrhein-Westfalen** (2): 
  - SG Wattenscheid 09  (1) Wattenscheid
  - VfL Bochum  (1) Bochum
- **Frankfurt am Main › Hessen** (2): 
  - Eintracht Frankfurt  (1) Ein Frankfurt
  - FSV Frankfurt  (1) Frankfurt FSV
- **Hamburg › Hamburg** (2): 
  - FC St. Pauli  (2) St Pauli • St. Pauli
  - Hamburger SV  (1) Hamburg
- **Köln › Nordrhein-Westfalen** (2): 
  - 1. FC Köln  (2) FC Koln • 1. FC Koeln
  - Fortuna Köln  (2) F Koln • Fortuna Koeln
- **Leipzig › Sachsen** (2): 
  - RB Leipzig 
  - VfB Leipzig (-2004)  (2) Leipzig • VfB Leipzig
- **Mannheim › Baden-Württemberg** (2): 
  - SV Waldhof Mannheim  (1) Waldhof Mannheim
  - VfR Mannheim  (1) Mannheim
- **München › Bayern** (2): 
  - Bayern München  (2) Bayern Munich • Bayern Muenchen
  - TSV 1860 München  (2) Munich 1860 • TSV 1860 Muenchen
- **Stuttgart › Baden-Württemberg** (2): 
  - Stuttgarter Kickers  (1) Stuttgarter K
  - VfB Stuttgart  (1) Stuttgart
- **Aachen › Nordrhein-Westfalen** (1): Alemannia Aachen  (1) Aachen
- **Aalen › Baden-Württemberg** (1): VfR Aalen  (1) Aalen
- **Ahlen › Nordrhein-Westfalen** (1): Rot Weiss Ahlen  (1) Ahlen
- **Aue › Sachsen** (1): FC Erzgebirge Aue  (1) Erzgebirge Aue
- **Augsburg › Bayern** (1): FC Augsburg  (1) Augsburg
- **Bielefeld › Nordrhein-Westfalen** (1): Arminia Bielefeld  (1) Bielefeld
- **Braunschweig › Niedersachsen** (1): Eintracht Braunschweig  (1) Braunschweig
- **Bremen › Bremen** (1): Werder Bremen 
- **Burghausen › Bayern** (1): Wacker Burghausen  (1) Burghausen
- **Chemnitz › Sachsen** (1): Chemnitzer FC  (1) Chemnitz
- **Cottbus › Brandenburg** (1): Energie Cottbus  (1) Cottbus
- **Darmstadt › Hessen** (1): SV Darmstadt 98  (1) Darmstadt
- **Dortmund › Nordrhein-Westfalen** (1): Borussia Dortmund  (1) Dortmund
- **Dresden › Sachsen** (1): Dynamo Dresden  (1) Dresden
- **Duisburg › Nordrhein-Westfalen** (1): MSV Duisburg  (1) Duisburg
- **Düsseldorf › Nordrhein-Westfalen** (1): Fortuna Düsseldorf  (3) Dusseldorf • Fortuna Dusseldorf • Fortuna Duesseldorf
- **Erfurt › Thüringen** (1): FC Rot-Weiß Erfurt  (1) Erfurt
- **Essen › Nordrhein-Westfalen** (1): Rot-Weiss Essen  (2) Essen • RW Essen
- **Freiburg › Baden-Württemberg** (1): SC Freiburg  (1) Freiburg
- **Fürth › Bayern** (1): Greuther Fürth  (2) Greuther Furth • SpVgg Greuther Fuerth
- **Gelsenkirchen › Nordrhein-Westfalen** (1): FC Schalke 04  (1) Schalke 04
- **Gütersloh › Nordrhein-Westfalen** (1): Gütersloh  (1) Gutersloh
- **Hannover › Niedersachsen** (1): Hannover 96  (1) Hannover
- **Heidenheim an der Brenz › Baden-Württemberg** (1): 1. FC Heidenheim  (1) Heidenheim
- **Homburg › Saarland** (1): FC 08 Homburg  (1) Homburg
- **Ingolstadt › Bayern** (1): FC Ingolstadt 04  (1) Ingolstadt
- **Jena › Thüringen** (1): FC Carl Zeiss Jena  (1) CZ Jena
- **Kaiserslautern › Rheinland-Pfalz** (1): 1. FC Kaiserslautern  (1) Kaiserslautern
- **Karlsruhe › Baden-Württemberg** (1): Karlsruher SC  (1) Karlsruhe
- **Kiel › Schleswig-Holstein** (1): Holstein Kiel 
- **Koblenz › Rheinland-Pfalz** (1): TuS Koblenz  (1) Koblenz
- **Krefeld › Nordrhein-Westfalen** (1): KFC Uerdingen  (2) Uerdingen • Bayer 05 Uerdingen
- **Leverkusen › Nordrhein-Westfalen** (1): Bayer 04 Leverkusen  (2) Leverkusen • Bayer Leverkusen
- **Lübeck › Schleswig-Holstein** (1): Lübeck  (1) Lubeck
- **Mainz › Rheinland-Pfalz** (1): 1. FSV Mainz 05  (1) Mainz
- **Meppen › Niedersachsen** (1): SV Meppen  (1) Meppen
- **Mönchengladbach › Nordrhein-Westfalen** (1): Bor. Mönchengladbach  (3) Bor. Moenchengladbach • M'Gladbach • M'gladbach
- **Münster › Nordrhein-Westfalen** (1): Preussen Münster  (1) Preussen Muenster
- **Neunkirchen › Saarland** (1): Borussia Neunkirchen 
- **Nürnberg › Bayern** (1): 1. FC Nürnberg  (2) Nurnberg • 1. FC Nuernberg
- **Oberhausen › Nordrhein-Westfalen** (1): Rot-Weiß Oberhausen  (2) Oberhausen • Rot-Weiss Oberhausen
- **Offenbach am Main › Hessen** (1): Kickers Offenbach  (1) Offenbach
- **Oldenburg › Niedersachsen** (1): VfB Oldenburg  (1) Oldenburg
- **Osnabrück › Niedersachsen** (1): Osnabrück  (1) Osnabruck
- **Paderborn › Nordrhein-Westfalen** (1): SC Paderborn 07  (1) Paderborn
- **Potsdam › Brandenburg** (1): SV Babelsberg 03  (1) Babelsberg
- **Regensburg › Bayern** (1): SSV Jahn Regensburg  (1) Regensburg
- **Reutlingen › Baden-Württemberg** (1): SSV Reutlingen 05  (1) Reutlingen
- **Rostock › Mecklenburg-Vorpommern** (1): Hansa Rostock 
- **Saarbrücken › Saarland** (1): 1. FC Saarbrücken  (2) Saarbrucken • 1. FC Saarbruecken
- **Sandhausen › Baden-Württemberg** (1): SV Sandhausen  (1) Sandhausen
- **Schweinfurt › Bayern** (1): 1. FC Schweinfurt 05  (1) Schweinfurt
- **Siegen › Nordrhein-Westfalen** (1): Sportfreunde Siegen  (1) Siegen
- **Sinsheim › Baden-Württemberg** (1): TSG 1899 Hoffenheim  (2) Hoffenheim • 1899 Hoffenheim
- **Trier › Rheinland-Pfalz** (1): Eintracht Trier  (1) Ein Trier
- **Ulm › Baden-Württemberg** (1): SSV Ulm 1846  (1) Ulm
- **Unterhaching › Bayern** (1): SpVgg Unterhaching  (1) Unterhaching
- **Wiesbaden › Hessen** (1): SV Wehen Wiesbaden  (1) Wehen
- **Wolfsburg › Niedersachsen** (1): VfL Wolfsburg  (1) Wolfsburg
- **Wuppertal › Nordrhein-Westfalen** (1): Wuppertaler SV  (1) Wuppertaler
- **Würzburg › Bayern** (1): Würzburger Kickers  (1) Wurzburger Kickers
- **Zwickau › Sachsen** (1): FSV Zwickau  (1) Zwickau




### Season

- **1. FC Heidenheim** - 4 seasons in 1 level
  - 2 (4): 2018....2014 (4)
- **1. FC Kaiserslautern** - 55 seasons in 2 levels
  - 1 (44): 2012..2010 (2) 2006.........1997 (9) 1996.................................1963 (33)
  - 2 (11): 2018......2012 (6) 2010....2006 (4) 1996-97
  - ⇑ (2) / ⇓ (3): 2 2 2 2 2 2 ⇓1 1 ⇑2 2 2 2 ⇓1 1 1 1 1 1 1 1 1 ⇑2 ⇓1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 
- **1. FC Köln** - 55 seasons in 2 levels
  - 1 (47): 2018....2014 (4) 2012....2008 (4) 2005-06 2003-04 2002..2000 (2) 1998...................................1963 (35)
  - 2 (8): 2014..2012 (2) 2008..2006 (2) 2004-05 2002-03 2000..1998 (2)
  - ⇑ (5) / ⇓ (5): 1 1 1 1 ⇑2 2 ⇓1 1 1 1 ⇑2 2 ⇓1 ⇑2 ⇓1 ⇑2 ⇓1 1 ⇑2 2 ⇓1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 
- **1. FC Nürnberg** - 43 seasons in 2 levels
  - 1 (32): 2014.....2009 (5) 2008....2004 (4) 2003..2001 (2) 1998-99 1994.........1985 (9) 1984....1980 (4) 1978-79 1969......1963 (6)
  - 2 (11): 2018....2014 (4) 2008-09 2003-04 2001..1999 (2) 1997-98 1996..1994 (2)
  - ⇑ (4) / ⇓ (5): 2 2 2 2 ⇓1 1 1 1 1 ⇑2 ⇓1 1 1 1 ⇑2 ⇓1 1 ⇑2 2 ⇓1 ⇑2  **?? 1996-97 ??** 2 2 ⇓1 1 1 1 1 1 1 1 1  **?? 1984-85 ??** 1 1 1 1  **?? 1979-80 ??** 1  **?? 1977-78 ??** 1 1 1 1 1 1 
- **1. FC Saarbrücken** - 11 seasons in 2 levels
  - 1 (5): 1992-93 1985-86 1978..1976 (2) 1963-64
  - 2 (6): 2006..2004 (2) 2002..2000 (2) 1995..1993 (2)
  - ⇓ (1): 2 2  **?? 2003-04 ??** 2 2  **?? 1999-00 ??** 2 2 ⇓1  **?? 1991-92 ??** 1  **?? 1984-85 ??** 1 1  **?? 1975-76 ??** 1 
- **1. FC Schweinfurt 05** - 1 season in 1 level
  - 2 (1): 2001-02
- **1. FC Union Berlin** - 12 seasons in 1 level
  - 2 (12): 2018.........2009 (9) 2004...2001 (3)
- **1. FSV Mainz 05** - 25 seasons in 2 levels
  - 1 (12): 2018.........2009 (9) 2007...2004 (3)
  - 2 (13): 2009..2007 (2) 2004...........1993 (11)
  - ⇑ (2) / ⇓ (1): 1 1 1 1 1 1 1 1 1 ⇑2 2 ⇓1 1 1 ⇑2 2 2 2 2 2 2 2 2 2 2 
- **Alemannia Aachen** - 16 seasons in 2 levels
  - 1 (4): 2006-07 1970...1967 (3)
  - 2 (12): 2012.....2007 (5) 2006.......1999 (7)
  - ⇑ (1) / ⇓ (2): 2 2 2 2 2 ⇓1 ⇑2 2 2 2 2 2 2  **?? 1998-99 ??** ⇓1 1 1 
- **Arminia Bielefeld** - 28 seasons in 2 levels
  - 1 (17): 2009.....2004 (5) 2002-03 1999-00 1998..1996 (2) 1985.....1980 (5) 1978-79 1972..1970 (2)
  - 2 (11): 2018...2015 (3) 2013-14 2011..2009 (2) 2003-04 2002..2000 (2) 1998-99 1995-96
  - ⇑ (4) / ⇓ (5): 2 2 2  **?? 2014-15 ??** 2  **?? 2012-13 ??** 2 2 ⇓1 1 1 1 1 ⇑2 ⇓1 ⇑2 2 ⇓1 ⇑2 ⇓1 1 ⇑2  **?? 1994-95 ??** ⇓1 1 1 1 1  **?? 1979-80 ??** 1  **?? 1977-78 ??** 1 1 
- **Bayer 04 Leverkusen** - 39 seasons in 1 level
  - 1 (39): 2018.......................................1979 (39)
- **Bayern München** - 53 seasons in 1 level
  - 1 (53): 2018.....................................................1965 (53)
- **Blau-Weiß 90 Berlin (-1992)** - 1 season in 1 level
  - 1 (1): 1986-87
- **Bor. Mönchengladbach** - 53 seasons in 2 levels
  - 1 (50): 2018..........2008 (10) 2007......2001 (6) 1999..................................1965 (34)
  - 2 (3): 2007-08 2001..1999 (2)
  - ⇑ (2) / ⇓ (2): 1 1 1 1 1 1 1 1 1 1 ⇑2 ⇓1 1 1 1 1 1 ⇑2 2 ⇓1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 
- **Borussia Dortmund** - 51 seasons in 1 level
  - 1 (51): 2018..........................................1976 (42) 1972.........1963 (9)
- **Borussia Neunkirchen** - 3 seasons in 1 level
  - 1 (3): 1967-68 1966..1964 (2)
- **Chemnitzer FC** - 5 seasons in 1 level
  - 2 (5): 2001..1999 (2) 1996...1993 (3)
- **Dynamo Dresden** - 11 seasons in 2 levels
  - 1 (4): 1995....1991 (4)
  - 2 (7): 2018..2016 (2) 2014...2011 (3) 2006..2004 (2)
  - ⇓ (1): 2 2  **?? 2015-16 ??** 2 2 2  **?? 2010-11 ??** 2 2  **?? 2003-04 ??** ⇓1 1 1 1 
- **Eintracht Braunschweig** - 30 seasons in 2 levels
  - 1 (21): 2013-14 1985....1981 (4) 1980......1974 (6) 1973..........1963 (10)
  - 2 (9): 2018....2014 (4) 2013..2011 (2) 2007..2005 (2) 2002-03
  - ⇑ (1) / ⇓ (2): 2 2 2 2 ⇓1 ⇑2 2  **?? 2010-11 ??** 2 2  **?? 2004-05 ??** 2  **?? 2001-02 ??** ⇓1 1 1 1  **?? 1980-81 ??** 1 1 1 1 1 1  **?? 1973-74 ??** 1 1 1 1 1 1 1 1 1 1 
- **Eintracht Frankfurt** - 55 seasons in 2 levels
  - 1 (49): 2018......2012 (6) 2011......2005 (6) 2003-04 2001...1998 (3) 1996.................................1963 (33)
  - 2 (6): 2011-12 2004-05 2003..2001 (2) 1998..1996 (2)
  - ⇑ (4) / ⇓ (4): 1 1 1 1 1 1 ⇑2 ⇓1 1 1 1 1 1 ⇑2 ⇓1 ⇑2 2 ⇓1 1 1 ⇑2 2 ⇓1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 
- **Eintracht Trier** - 3 seasons in 1 level
  - 2 (3): 2005...2002 (3)
- **Energie Cottbus** - 17 seasons in 2 levels
  - 1 (6): 2009...2006 (3) 2003...2000 (3)
  - 2 (11): 2014.....2009 (5) 2006...2003 (3) 2000...1997 (3)
  - ⇑ (2) / ⇓ (2): 2 2 2 2 2 ⇓1 1 1 ⇑2 2 2 ⇓1 1 1 ⇑2 2 2 
- **FC 08 Homburg** - 5 seasons in 2 levels
  - 1 (3): 1989-90 1988..1986 (2)
  - 2 (2): 1995..1993 (2)
  - ⇓ (1): 2 2  **?? 1992-93 ??** ⇓1  **?? 1988-89 ??** 1 1 
- **FC Augsburg** - 12 seasons in 2 levels
  - 1 (7): 2018.......2011 (7)
  - 2 (5): 2011.....2006 (5)
  - ⇑ (1): 1 1 1 1 1 1 1 ⇑2 2 2 2 2 
- **FC Carl Zeiss Jena** - 6 seasons in 1 level
  - 2 (6): 2008..2006 (2) 1998...1995 (3) 1993-94
- **FC Erzgebirge Aue** - 12 seasons in 1 level
  - 2 (12): 2018..2016 (2) 2015.....2010 (5) 2008.....2003 (5)
- **FC Ingolstadt 04** - 9 seasons in 2 levels
  - 1 (2): 2017..2015 (2)
  - 2 (7): 2017-18 2015.....2010 (5) 2008-09
  - ⇑ (1) / ⇓ (1): 2 ⇓1 1 ⇑2 2 2 2 2  **?? 2009-10 ??** 2 
- **FC Rot-Weiß Erfurt** - 1 season in 1 level
  - 2 (1): 2004-05
- **FC Schalke 04** - 50 seasons in 1 level
  - 1 (50): 2018...........................1991 (27) 1988....1984 (4) 1982-83 1981..................1963 (18)
- **FC St. Pauli** - 25 seasons in 2 levels
  - 1 (8): 2010-11 2001-02 1997..1995 (2) 1991...1988 (3) 1977-78
  - 2 (17): 2018.......2011 (7) 2010...2007 (3) 2002-03 2001....1997 (4) 1995..1993 (2)
  - ⇑ (3) / ⇓ (4): 2 2 2 2 2 2 2 ⇓1 ⇑2 2 2  **?? 2006-07 ??** 2 ⇓1 ⇑2 2 2 2 ⇓1 1 ⇑2 2  **?? 1992-93 ??** ⇓1 1 1  **?? 1987-88 ??** 1 
- **FSV Frankfurt** - 9 seasons in 1 level
  - 2 (9): 2016........2008 (8) 1994-95
- **FSV Zwickau** - 4 seasons in 1 level
  - 2 (4): 1998....1994 (4)
- **Fortuna Düsseldorf** - 34 seasons in 2 levels
  - 1 (23): 2012-13 1997..1995 (2) 1992...1989 (3) 1987................1971 (16) 1966-67
  - 2 (11): 2018.....2013 (5) 2012...2009 (3) 1999..1997 (2) 1994-95
  - ⇑ (2) / ⇓ (3): 2 2 2 2 2 ⇓1 ⇑2 2 2  **?? 2008-09 ??** 2 2 ⇓1 1 ⇑2  **?? 1993-94 ??** ⇓1 1 1  **?? 1988-89 ??** 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1  **?? 1970-71 ??** 1 
- **Fortuna Köln** - 8 seasons in 2 levels
  - 1 (1): 1973-74
  - 2 (7): 2000.......1993 (7)
  - ⇓ (1): 2 2 2 2 2 2 2  **?? 1992-93 ??** ⇓1 
- **Greuther Fürth** - 21 seasons in 2 levels
  - 1 (1): 2012-13
  - 2 (20): 2018.....2013 (5) 2012...............1997 (15)
  - ⇑ (1) / ⇓ (1): 2 2 2 2 2 ⇓1 ⇑2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 
- **Gütersloh** - 3 seasons in 1 level
  - 2 (3): 1999...1996 (3)
- **Hamburger SV** - 55 seasons in 1 level
  - 1 (55): 2018.......................................................1963 (55)
- **Hannover 96** - 37 seasons in 2 levels
  - 1 (29): 2017-18 2016..............2002 (14) 1989..1987 (2) 1985-86 1975-76 1974..........1964 (10)
  - 2 (8): 2016-17 2002....1998 (4) 1996...1993 (3)
  - ⇑ (2) / ⇓ (2): 1 ⇑2 ⇓1 1 1 1 1 1 1 1 1 1 1 1 1 1 ⇑2 2 2 2  **?? 1997-98 ??** 2 2 2  **?? 1992-93 ??** ⇓1 1  **?? 1986-87 ??** 1  **?? 1984-85 ??** 1  **?? 1974-75 ??** 1 1 1 1 1 1 1 1 1 1 
- **Hansa Rostock** - 19 seasons in 2 levels
  - 1 (12): 2007-08 2005..........1995 (10) 1991-92
  - 2 (7): 2011-12 2010..2008 (2) 2007..2005 (2) 1995..1993 (2)
  - ⇑ (2) / ⇓ (3): 2  **?? 2010-11 ??** 2 2 ⇓1 ⇑2 2 ⇓1 1 1 1 1 1 1 1 1 1 ⇑2 2  **?? 1992-93 ??** ⇓1 
- **Hertha BSC** - 41 seasons in 2 levels
  - 1 (35): 2018.....2013 (5) 2011-12 2010.............1997 (13) 1990-91 1982-83 1980............1968 (12) 1965..1963 (2)
  - 2 (6): 2012-13 2010-11 1997....1993 (4)
  - ⇑ (3) / ⇓ (3): 1 1 1 1 1 ⇑2 ⇓1 ⇑2 ⇓1 1 1 1 1 1 1 1 1 1 1 1 1 ⇑2 2 2 2  **?? 1992-93 ??** ⇓1  **?? 1989-90 ??** 1  **?? 1981-82 ??** 1 1 1 1 1 1 1 1 1 1 1 1  **?? 1967-68 ??** 1 1 
- **Holstein Kiel** - 1 season in 1 level
  - 2 (1): 2017-18
- **KFC Uerdingen** - 18 seasons in 2 levels
  - 1 (14): 1996..1994 (2) 1992-93 1991........1983 (8) 1981..1979 (2) 1975-76
  - 2 (4): 1999...1996 (3) 1993-94
  - ⇑ (1) / ⇓ (2): 2 2 2 ⇓1 1 ⇑2 ⇓1  **?? 1991-92 ??** 1 1 1 1 1 1 1 1  **?? 1982-83 ??** 1 1  **?? 1978-79 ??** 1 
- **Karlsruher SC** - 39 seasons in 2 levels
  - 1 (24): 2009..2007 (2) 1998...........1987 (11) 1984-85 1983...1980 (3) 1977..1975 (2) 1968.....1963 (5)
  - 2 (15): 2017....2013 (4) 2012...2009 (3) 2007......2001 (6) 2000..1998 (2)
  - ⇑ (1) / ⇓ (2): 2 2 2 2  **?? 2012-13 ??** 2 2 2 ⇓1 1 ⇑2 2 2 2 2 2  **?? 2000-01 ??** 2 2 ⇓1 1 1 1 1 1 1 1 1 1 1  **?? 1986-87 ??** 1  **?? 1983-84 ??** 1 1 1  **?? 1979-80 ??** 1 1  **?? 1974-75 ??** 1 1 1 1 1 
- **Kickers Offenbach** - 11 seasons in 2 levels
  - 1 (7): 1983-84 1976....1972 (4) 1970-71 1968-69
  - 2 (4): 2008...2005 (3) 1999-00
  - ⇓ (1): 2 2 2  **?? 2004-05 ??** 2  **?? 1998-99 ??** ⇓1  **?? 1982-83 ??** 1 1 1 1  **?? 1971-72 ??** 1  **?? 1969-70 ??** 1 
- **Lübeck** - 4 seasons in 1 level
  - 2 (4): 2004..2002 (2) 1997..1995 (2)
- **MSV Duisburg** - 42 seasons in 2 levels
  - 1 (28): 2007-08 2005-06 2000....1996 (4) 1995..1993 (2) 1991-92 1982...................1963 (19)
  - 2 (14): 2017-18 2015-16 2013.....2008 (5) 2006-07 2005.....2000 (5) 1995-96
  - ⇑ (3) / ⇓ (4): 2  **?? 2016-17 ??** 2  **?? 2014-15 ??** 2 2 2 2 2 ⇓1 ⇑2 ⇓1 ⇑2 2 2 2 2 ⇓1 1 1 1 ⇑2 ⇓1 1  **?? 1992-93 ??** 1  **?? 1990-91 ??** 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 
- **Osnabrück** - 5 seasons in 1 level
  - 2 (5): 2010-11 2009..2007 (2) 2003-04 2000-01
- **Preussen Münster** - 1 season in 1 level
  - 1 (1): 1963-64
- **RB Leipzig** - 4 seasons in 2 levels
  - 1 (2): 2018..2016 (2)
  - 2 (2): 2016..2014 (2)
  - ⇑ (1): 1 1 ⇑2 2 
- **Rot Weiss Ahlen** - 8 seasons in 1 level
  - 2 (8): 2010..2008 (2) 2006......2000 (6)
- **Rot-Weiss Essen** - 11 seasons in 2 levels
  - 1 (7): 1977....1973 (4) 1971..1969 (2) 1966-67
  - 2 (4): 2006-07 2004-05 1996-97 1993-94
  - ⇓ (1): 2  **?? 2005-06 ??** 2  **?? 2003-04 ??** 2  **?? 1995-96 ??** 2  **?? 1992-93 ??** ⇓1 1 1 1  **?? 1972-73 ??** 1 1  **?? 1968-69 ??** 1 
- **Rot-Weiß Oberhausen** - 14 seasons in 2 levels
  - 1 (4): 1973....1969 (4)
  - 2 (10): 2011...2008 (3) 2005.......1998 (7)
  - ⇓ (1): 2 2 2  **?? 2007-08 ??** 2 2 2 2 2 2 2  **?? 1997-98 ??** ⇓1 1 1 1 
- **SC Freiburg** - 25 seasons in 2 levels
  - 1 (18): 2018..2016 (2) 2015......2009 (6) 2005..2003 (2) 2002....1998 (4) 1997....1993 (4)
  - 2 (7): 2015-16 2009....2005 (4) 2002-03 1997-98
  - ⇑ (4) / ⇓ (4): 1 1 ⇑2 ⇓1 1 1 1 1 1 ⇑2 2 2 2 ⇓1 1 ⇑2 ⇓1 1 1 1 ⇑2 ⇓1 1 1 1 
- **SC Paderborn 07** - 10 seasons in 2 levels
  - 1 (1): 2014-15
  - 2 (9): 2015-16 2014.....2009 (5) 2008...2005 (3)
  - ⇑ (1) / ⇓ (1): 2 ⇓1 ⇑2 2 2 2 2  **?? 2008-09 ??** 2 2 2 
- **SC Tasmania 1900 Berlin (-1973)** - 1 season in 1 level
  - 1 (1): 1965-66
- **SG Wattenscheid 09** - 8 seasons in 2 levels
  - 1 (4): 1994....1990 (4)
  - 2 (4): 1999..1997 (2) 1996..1994 (2)
  - ⇓ (1): 2 2  **?? 1996-97 ??** 2 2 ⇓1 1 1 1 
- **SSV Jahn Regensburg** - 3 seasons in 1 level
  - 2 (3): 2017-18 2012-13 2003-04
- **SSV Reutlingen 05** - 3 seasons in 1 level
  - 2 (3): 2003...2000 (3)
- **SSV Ulm 1846** - 3 seasons in 2 levels
  - 1 (1): 1999-00
  - 2 (2): 2000-01 1998-99
  - ⇑ (1) / ⇓ (1): 2 ⇓1 ⇑2 
- **SV Babelsberg 03** - 1 season in 1 level
  - 2 (1): 2001-02
- **SV Darmstadt 98** - 6 seasons in 2 levels
  - 1 (4): 2017..2015 (2) 1981-82 1978-79
  - 2 (2): 2017-18 2014-15
  - ⇑ (1) / ⇓ (2): 2 ⇓1 1 ⇑2  **?? 2013-14 ??** ⇓1  **?? 1980-81 ??** 1 
- **SV Meppen** - 5 seasons in 1 level
  - 2 (5): 1998.....1993 (5)
- **SV Sandhausen** - 6 seasons in 1 level
  - 2 (6): 2018......2012 (6)
- **SV Waldhof Mannheim** - 7 seasons in 1 level
  - 1 (7): 1990.......1983 (7)
- **SV Wehen Wiesbaden** - 2 seasons in 1 level
  - 2 (2): 2009..2007 (2)
- **SpVgg Unterhaching** - 11 seasons in 2 levels
  - 1 (2): 2001..1999 (2)
  - 2 (9): 2007....2003 (4) 2001-02 1999....1995 (4)
  - ⇑ (1) / ⇓ (1): 2 2 2 2  **?? 2002-03 ??** 2 ⇓1 1 ⇑2 2 2 2 
- **Sportfreunde Siegen** - 1 season in 1 level
  - 2 (1): 2005-06
- **Stuttgarter Kickers** - 8 seasons in 2 levels
  - 1 (2): 1991-92 1988-89
  - 2 (6): 2001.....1996 (5) 1993-94
  - ⇓ (1): 2 2 2 2 2  **?? 1995-96 ??** 2  **?? 1992-93 ??** ⇓1  **?? 1990-91 ??** 1 
- **TSG 1899 Hoffenheim** - 11 seasons in 2 levels
  - 1 (10): 2018..........2008 (10)
  - 2 (1): 2007-08
  - ⇑ (1): 1 1 1 1 1 1 1 1 1 1 ⇑2 
- **TSV 1860 München** - 34 seasons in 2 levels
  - 1 (20): 2004..........1994 (10) 1981..1979 (2) 1977-78 1970.......1963 (7)
  - 2 (14): 2017.............2004 (13) 1993-94
  - ⇑ (1) / ⇓ (2): 2 2 2 2 2 2 2 2 2 2 2 2 2 ⇓1 1 1 1 1 1 1 1 1 1 ⇑2  **?? 1992-93 ??** ⇓1 1  **?? 1978-79 ??** 1  **?? 1976-77 ??** 1 1 1 1 1 1 1 
- **Tennis Borussia Berlin** - 5 seasons in 2 levels
  - 1 (2): 1976-77 1974-75
  - 2 (3): 2000..1998 (2) 1993-94
  - ⇓ (1): 2 2  **?? 1997-98 ??** 2  **?? 1992-93 ??** ⇓1  **?? 1975-76 ??** 1 
- **TuS Koblenz** - 4 seasons in 1 level
  - 2 (4): 2010....2006 (4)
- **VfB Leipzig (-2004)** - 5 seasons in 2 levels
  - 1 (1): 1993-94
  - 2 (4): 1998....1994 (4)
  - ⇓ (1): 2 2 2 2 ⇓1 
- **VfB Oldenburg** - 1 season in 1 level
  - 2 (1): 1996-97
- **VfB Stuttgart** - 53 seasons in 2 levels
  - 1 (52): 2017-18 2016.......................................1977 (39) 1975............1963 (12)
  - 2 (1): 2016-17
  - ⇑ (1) / ⇓ (1): 1 ⇑2 ⇓1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1  **?? 1976-77 ??** 1 1 1 1 1 1 1 1 1 1 1 1 
- **VfL Bochum** - 47 seasons in 2 levels
  - 1 (34): 2010....2006 (4) 2005...2002 (3) 2000-01 1999...1996 (3) 1994-95 1993......................1971 (22)
  - 2 (13): 2018........2010 (8) 2005-06 2001-02 1999-00 1995-96 1993-94
  - ⇑ (5) / ⇓ (6): 2 2 2 2 2 2 2 2 ⇓1 1 1 1 ⇑2 ⇓1 1 1 ⇑2 ⇓1 ⇑2 ⇓1 1 1 ⇑2 ⇓1 ⇑2 ⇓1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 
- **VfL Wolfsburg** - 25 seasons in 2 levels
  - 1 (21): 2018.....................1997 (21)
  - 2 (4): 1997....1993 (4)
  - ⇑ (1): 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 ⇑2 2 2 2 
- **VfR Aalen** - 3 seasons in 1 level
  - 2 (3): 2015...2012 (3)
- **VfR Mannheim** - 8 seasons in 1 level
  - 2 (8): 2003....1999 (4) 1997....1993 (4)
- **Wacker Burghausen** - 5 seasons in 1 level
  - 2 (5): 2007.....2002 (5)
- **Werder Bremen** - 54 seasons in 1 level
  - 1 (54): 2018.....................................1981 (37) 1980.................1963 (17)
- **Wuppertaler SV** - 4 seasons in 2 levels
  - 1 (3): 1975...1972 (3)
  - 2 (1): 1993-94
  - ⇓ (1): 2  **?? 1992-93 ??** ⇓1 1 1 
- **Würzburger Kickers** - 1 season in 1 level
  - 2 (1): 2016-17



