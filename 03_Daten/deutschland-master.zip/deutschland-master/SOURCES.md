
### Sources

- [open sport forum](http://groups.google.com/group/opensport)
- [football-data.co.uk](http://www.football-data.co.uk/germanym.php)

