

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Werder Bremen                 34  14  3  0  38:5     5  7  5  25:25    63:30  +33   67
 2. Bayern München                34  12  4  1  43:16    6  7  4  31:29    74:45  +29   65
 3. Borussia Dortmund             34  12  1  4  41:18    6  4  7  20:25    61:43  +18   59
 4. Eintracht Frankfurt           34   9  6  2  38:19    6  6  5  18:20    56:39  +17   57
 5. Bayer 04 Leverkusen           34  10  6  1  43:17    4  6  7  21:28    64:45  +19   54
 6. Karlsruher SC                 34  11  6  0  40:16    3  5  9  20:38    60:54   +6   53
 7. 1. FC Kaiserslautern          34   9  5  3  30:15    4  4  9  20:25    50:40  +10   48
 8. VfB Stuttgart                 34  10  3  4  35:22    2  9  6  21:28    56:50   +6   48
 9. Bor. Mönchengladbach          34   6  7  4  33:30    7  2  8  26:29    59:59        48
10. FC Schalke 04                 34   5  9  3  22:18    6  3  8  20:25    42:43   -1   45
11. 1. FC Köln                    34  10  2  5  30:17    2  2 13  11:34    41:51  -10   40
12. Hamburger SV                  34   5  6  6  22:17    3  9  5  20:27    42:44   -2   39
13. 1. FC Nürnberg                34   7  5  5  19:16    3  3 11  11:31    30:47  -17   38
14. SG Wattenscheid 09            34   8  5  4  29:21    2  3 12  17:46    46:67  -21   38
15. VfL Bochum                    34   7  7  3  32:19    1  3 13  13:33    45:52   -7   34
16. Dynamo Dresden                34   7  6  4  21:13    0  7 10  11:36    32:49  -17   34
17. KFC Uerdingen                 34   5  6  6  20:29    2  4 11  15:35    35:64  -29   31
18. 1. FC Saarbrücken             34   4  5  8  18:31    1  8  8  19:40    37:71  -34   28
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

