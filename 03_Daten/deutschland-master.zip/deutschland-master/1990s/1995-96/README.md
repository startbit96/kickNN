

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Borussia Dortmund             34  12  4  1  45:14    7  7  3  31:24    76:38  +38   68
 2. Bayern München                34  11  3  3  35:20    8  2  7  31:26    66:46  +20   62
 3. FC Schalke 04                 34   8  7  2  28:16    6  7  4  17:20    45:36   +9   56
 4. Bor. Mönchengladbach          34   8  5  4  29:22    7  3  7  23:29    52:51   +1   53
 5. Hamburger SV                  34   7 10  0  29:15    5  4  8  23:32    52:47   +5   50
 6. Hansa Rostock                 34   7  5  5  23:19    6  5  6  24:24    47:43   +4   49
 7. Karlsruher SC                 34   6  6  5  28:23    6  6  5  25:24    53:47   +6   48
 8. TSV 1860 München              34   8  7  2  31:15    3  5  9  21:31    52:46   +6   45
 9. Werder Bremen                 34   7  6  4  22:19    3  8  6  17:23    39:42   -3   44
10. VfB Stuttgart                 34   6  5  6  29:26    4  8  5  30:36    59:62   -3   43
11. SC Freiburg                   34   7  4  6  17:18    4  5  8  13:23    30:41  -11   42
12. 1. FC Köln                    34   5  7  5  18:14    4  6  7  15:21    33:35   -2   40
13. Fortuna Düsseldorf            34   6  8  3  24:19    2  8  7  16:28    40:47   -7   40
14. Bayer 04 Leverkusen           34   4  8  5  16:15    4  6  7  21:23    37:38   -1   38
15. FC St. Pauli                  34   6  4  7  24:28    3  7  7  19:23    43:51   -8   38
16. 1. FC Kaiserslautern          34   4  9  4  19:16    2  9  6  12:21    31:37   -6   36
17. Eintracht Frankfurt           34   7  4  6  29:28    0  7 10  14:40    43:68  -25   32
18. KFC Uerdingen                 34   4  6  7  26:32    1  5 11   7:24    33:56  -23   26
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. VfL Bochum                    34  11  5  1  39:13   10  1  6  29:17    68:30  +38   69
 2. Arminia Bielefeld             34  11  4  2  34:19    5  5  7  21:26    55:45  +10   57
 3. MSV Duisburg                  34   9  6  2  32:16    6  5  6  23:21    55:37  +18   56
 4. SpVgg Unterhaching            34  10  5  2  33:12    4  5  8  19:26    52:38  +14   52
 5. FSV Zwickau                   34  13  1  3  29:13    2  3 12  10:35    39:48   -9   49
 6. FC Carl Zeiss Jena            34  10  4  3  33:21    3  5  9  16:33    49:54   -5   48
 7. VfR Mannheim                  34  12  1  4  36:21    1  6 10  13:26    49:47   +2   46
 8. Fortuna Köln                  34   9  3  5  21:13    3  7  7  16:24    37:37        46
 9. Hertha BSC                    34   6  6  5  18:17    5  6  6  19:18    37:35   +2   45
10. VfB Leipzig (-2004)           34   9  6  2  22:13    4  0 13  13:36    35:49  -14   45
11. SV Meppen                     34   8  7  2  28:15    2  7  8  17:28    45:43   +2   44
12. 1. FSV Mainz 05               34   8  4  5  20:12    4  4  9  17:29    37:41   -4   44
13. VfL Wolfsburg                 34   6  7  4  23:25    4  7  6  18:21    41:46   -5   44
14. Lübeck                        34   9  3  5  25:16    4  2 11  15:29    40:45   -5   44
15. Chemnitzer FC                 34   8  3  6  24:20    3  6  8  19:31    43:51   -8   42
16. 1. FC Nürnberg                34   5  5  7  16:20    4  7  6  17:20    33:40   -7   39
17. Hannover 96                   34   8  5  4  25:15    2  2 13  13:33    38:48  -10   37
18. SG Wattenscheid 09            34   6  5  6  28:24    2  2 13  10:33    38:57  -19   31
```

(Source: [`2-bundesliga2.csv`](2-bundesliga2.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

