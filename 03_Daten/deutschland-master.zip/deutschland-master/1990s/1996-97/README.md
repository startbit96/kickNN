

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bayern München                34  13  4  0  37:12    7  7  3  31:22    68:34  +34   71
 2. Bayer 04 Leverkusen           34  15  1  1  47:13    6  5  6  22:28    69:41  +28   69
 3. Borussia Dortmund             34  12  4  1  38:13    7  2  8  25:28    63:41  +22   63
 4. VfB Stuttgart                 34  12  2  3  46:17    6  5  6  32:23    78:40  +38   61
 5. VfL Bochum                    34  11  5  1  36:17    3  6  8  18:34    54:51   +3   53
 6. Karlsruher SC                 34   8  5  4  32:18    5  5  7  23:26    55:44  +11   49
 7. TSV 1860 München              34   9  3  5  34:25    4  7  6  22:31    56:56        49
 8. Werder Bremen                 34  10  5  2  27:16    4  1 12  26:36    53:52   +1   48
 9. MSV Duisburg                  34   6  5  6  25:27    6  4  7  19:22    44:49   -5   45
10. 1. FC Köln                    34   9  1  7  35:30    4  4  9  27:32    62:62        44
11. Bor. Mönchengladbach          34   9  5  3  34:17    3  2 12  12:31    46:48   -2   43
12. FC Schalke 04                 34   5  7  5  19:14    6  3  8  16:26    35:40   -5   43
13. Hamburger SV                  34   8  4  5  28:28    2  7  8  18:32    46:60  -14   41
14. Arminia Bielefeld             34   7  2  8  23:22    4  5  8  23:32    46:54   -8   40
15. Hansa Rostock                 34   6  4  7  20:20    5  3  9  15:26    35:46  -11   40
16. Fortuna Düsseldorf            34   5  5  7  17:25    4  1 12   9:32    26:57  -31   33
17. SC Freiburg                   34   6  4  7  23:24    2  1 14  20:43    43:67  -24   29
18. FC St. Pauli                  34   5  4  8  24:28    2  2 13   8:41    32:69  -37   27
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. 1. FC Kaiserslautern          34  14  3  0  57:14    5  8  4  17:14    74:28  +46   68
 2. VfL Wolfsburg                 34   9  8  0  34:14    5  8  4  18:15    52:29  +23   58
 3. Hertha BSC                    34  10  3  4  32:16    7  4  6  25:22    57:38  +19   58
 4. 1. FSV Mainz 05               34  10  6  1  28:10    4  6  7  22:24    50:34  +16   54
 5. Stuttgarter Kickers           34   8  5  4  24:15    6  6  5  14:12    38:27  +11   53
 6. SpVgg Unterhaching            34   7  8  2  19:12    4  8  5  16:17    35:29   +6   49
 7. Eintracht Frankfurt           34   9  3  5  25:14    4  6  7  18:32    43:46   -3   48
 8. VfB Leipzig (-2004)           34   8  5  4  36:20    4  5  8  17:34    53:54   -1   46
 9. Gütersloh                     34   9  7  1  25:12    3  2 12  18:39    43:51   -8   45
10. KFC Uerdingen                 34   8  2  7  30:20    5  3  9  16:24    46:44   +2   44
11. SV Meppen                     34   7  9  1  24:15    3  5  9  20:33    44:48   -4   44
12. Fortuna Köln                  34   8  4  5  31:17    3  5  9  21:30    52:47   +5   42
13. FC Carl Zeiss Jena            34   6 10  1  29:22    3  5  9  15:27    44:49   -5   42
14. FSV Zwickau                   34  10  3  4  21:12    2  3 12  13:36    34:48  -14   42
15. VfR Mannheim                  34   9  5  3  32:18    1  5 11  13:38    45:56  -11   40
16. Lübeck                        34   6  5  6  21:21    2  7  8  11:32    32:53  -21   36
17. Rot-Weiss Essen               34   7  1  9  27:30    1  4 12  20:44    47:74  -27   29
18. VfB Oldenburg                 34   5  6  6  22:23    1  3 13  11:44    33:67  -34   27
```

(Source: [`2-bundesliga2.csv`](2-bundesliga2.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

