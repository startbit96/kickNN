

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bayern München                34  14  3  0  48:15   10  3  4  28:13    76:28  +48   78
 2. Bayer 04 Leverkusen           34   9  6  2  33:15    8  6  3  28:15    61:30  +31   63
 3. Hertha BSC                    34  14  1  2  38:10    4  7  6  21:22    59:32  +27   62
 4. Borussia Dortmund             34  14  2  1  35:10    2  7  8  13:24    48:34  +14   57
 5. 1. FC Kaiserslautern          34  11  3  3  33:18    6  3  8  18:29    51:47   +4   57
 6. VfL Wolfsburg                 34  10  5  2  35:17    5  5  7  19:32    54:49   +5   55
 7. Hamburger SV                  34   9  5  3  25:14    4  6  7  22:32    47:46   +1   50
 8. MSV Duisburg                  34   9  5  3  32:18    4  5  8  16:27    48:45   +3   49
 9. TSV 1860 München              34   7  4  6  28:23    4  4  9  21:33    49:56   -7   41
10. FC Schalke 04                 34   5  6  6  20:23    5  5  7  21:31    41:54  -13   41
11. VfB Stuttgart                 34   8  5  4  25:15    1  7  9  16:33    41:48   -7   39
12. SC Freiburg                   34   5  6  6  17:18    5  3  9  19:26    36:44   -8   39
13. Werder Bremen                 34   4  6  7  23:24    6  2  9  18:23    41:47   -6   38
14. Hansa Rostock                 34   7  6  4  30:22    2  5 10  19:36    49:58   -9   38
15. Eintracht Frankfurt           34   6  6  5  26:21    3  4 10  18:33    44:54  -10   37
16. 1. FC Nürnberg                34   3 11  3  23:23    4  5  8  17:27    40:50  -10   37
17. VfL Bochum                    34   5  3  9  21:28    2  5 10  19:37    40:65  -25   29
18. Bor. Mönchengladbach          34   4  4  9  25:35    0  5 12  16:44    41:79  -38   21
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Arminia Bielefeld             34  12  2  3  27:7     8  5  4  35:25    62:32  +30   67
 2. SpVgg Unterhaching            34  14  2  1  30:7     5  4  8  17:23    47:30  +17   63
 3. SSV Ulm 1846                  34   9  7  1  41:26    6  6  5  22:25    63:51  +12   58
 4. Hannover 96                   34  10  5  2  34:17    6  4  7  18:19    52:36  +16   57
 5. Karlsruher SC                 34  11  2  4  34:16    6  3  8  20:27    54:43  +11   56
 6. Tennis Borussia Berlin        34   9  5  3  27:19    6  4  7  20:20    47:39   +8   54
 7. 1. FSV Mainz 05               34  10  6  1  27:10    4  2 11  21:34    48:44   +4   50
 8. Greuther Fürth                34   9  4  4  22:11    4  6  7  18:20    40:31   +9   49
 9. FC St. Pauli                  34   7  5  5  23:16    5  4  8  26:30    49:46   +3   45
10. 1. FC Köln                    34   8  3  6  25:24    4  6  7  21:29    46:53   -7   45
11. Energie Cottbus               34   9  3  5  35:19    1  8  8  13:23    48:42   +6   41
12. Rot-Weiß Oberhausen           34   6  5  6  20:26    3  9  5  20:21    40:47   -7   41
13. Stuttgarter Kickers           34   7  5  5  23:22    4  3 10  15:31    38:53  -15   41
14. Fortuna Köln                  34   7  5  5  27:23    2  8  7  22:32    49:55   -6   40
15. Gütersloh                     34   9  4  4  25:19    1  3 13  14:39    39:58  -19   37
16. KFC Uerdingen                 34   4  5  8  21:25    3  5  9  13:32    34:57  -23   31
17. SG Wattenscheid 09            34   5  7  5  21:23    2  2 13  10:23    31:46  -15   30
18. Fortuna Düsseldorf            34   2 10  5  21:29    3  3 11  14:30    35:59  -24   28
```

(Source: [`2-bundesliga2.csv`](2-bundesliga2.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

