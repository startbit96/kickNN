

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. VfB Stuttgart                 38  14  3  2  40:16    7  7  5  22:16    62:32  +30   73
 2. Borussia Dortmund             38  13  6  0  44:18    7  6  6  22:29    66:47  +19   72
 3. Eintracht Frankfurt           38  10  7  2  40:16    8  7  4  36:25    76:41  +35   68
 4. 1. FC Kaiserslautern          38  13  6  0  45:16    4  4 11  13:26    58:42  +16   61
 5. 1. FC Nürnberg                38  11  5  3  32:19    7  2 10  22:32    54:51   +3   61
 6. Bayer 04 Leverkusen           38  11  4  4  35:16    4  9  6  18:23    53:39  +14   58
 7. 1. FC Köln                    38   6 11  2  32:16    7  7  5  26:25    58:41  +17   57
 8. Karlsruher SC                 38  10  5  4  28:20    6  4  9  20:30    48:50   -2   57
 9. Werder Bremen                 38   7  7  5  25:21    4  9  6  19:24    44:45   -1   49
10. Bayern München                38   9  3  7  35:32    4  7  8  24:29    59:61   -2   49
11. Dynamo Dresden                38  10  5  4  24:13    2  5 12  10:37    34:50  -16   46
12. FC Schalke 04                 38   9  8  2  32:12    2  4 13  13:33    45:45        45
13. Bor. Mönchengladbach          38   8  8  3  21:16    2  6 11  16:33    37:49  -12   44
14. Hamburger SV                  38   6  7  6  15:17    3  9  7  17:26    32:43  -11   43
15. VfL Bochum                    38   6  7  6  23:29    4  6  9  15:26    38:55  -17   43
16. SG Wattenscheid 09            38   7  5  7  29:22    2  9  8  21:38    50:60  -10   41
17. Stuttgarter Kickers           38   5  6  8  21:23    5  5  9  32:41    53:64  -11   41
18. Hansa Rostock                 38   9  6  4  33:18    1  5 13  10:37    43:55  -12   41
19. MSV Duisburg                  38   6  8  5  29:22    1  8 10  14:33    43:55  -12   37
20. Fortuna Düsseldorf            38   4  7  8  21:28    2  5 12  20:41    41:69  -28   30
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

