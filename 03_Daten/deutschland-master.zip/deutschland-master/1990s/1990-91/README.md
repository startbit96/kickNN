

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. 1. FC Kaiserslautern          34  11  5  1  33:18    8  5  4  39:27    72:45  +27   67
 2. Bayern München                34   9  5  3  46:19    9  4  4  28:22    74:41  +33   63
 3. Hamburger SV                  34  11  3  3  36:13    5  5  7  24:25    60:38  +22   56
 4. Werder Bremen                 34  10  5  2  32:14    4  9  4  14:15    46:29  +17   56
 5. Eintracht Frankfurt           34  11  3  3  44:21    4  7  6  19:19    63:40  +23   55
 6. VfB Stuttgart                 34   8  5  4  34:24    6  5  6  23:20    57:44  +13   52
 7. 1. FC Köln                    34   8  5  4  25:23    5  6  6  25:20    50:43   +7   50
 8. Bayer 04 Leverkusen           34   7  7  3  29:23    4  6  7  18:23    47:46   +1   46
 9. Bor. Mönchengladbach          34   6 10  1  25:16    3  7  7  24:38    49:54   -5   44
10. Borussia Dortmund             34   4  7  6  22:27    6  7  4  24:30    46:57  -11   44
11. Fortuna Düsseldorf            34   7  3  7  26:25    4  7  6  14:24    40:49   -9   43
12. SG Wattenscheid 09            34   5  7  5  19:21    4  8  5  23:30    42:51   -9   42
13. Karlsruher SC                 34   7  7  3  31:22    1  8  8  15:30    46:52   -6   39
14. 1. FC Nürnberg                34   6  4  7  27:30    4  5  8  13:24    40:54  -14   39
15. VfL Bochum                    34   5  6  6  19:16    4  5  8  31:36    50:52   -2   38
16. FC St. Pauli                  34   4 10  3  19:18    2  5 10  14:35    33:53  -20   33
17. KFC Uerdingen                 34   3  7  7  20:27    2  6  9  14:27    34:54  -20   28
18. Hertha BSC                    34   1  7  9  14:28    2  1 14  23:56    37:84  -47   17
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

