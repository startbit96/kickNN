

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Borussia Dortmund             34  13  3  1  35:13    7  6  4  32:20    67:33  +34   69
 2. Werder Bremen                 34  13  3  1  44:16    7  5  5  26:23    70:39  +31   68
 3. SC Freiburg                   34  11  4  2  38:15    9  2  6  28:29    66:44  +22   66
 4. 1. FC Kaiserslautern          34  10  7  0  32:16    7  5  5  26:25    58:41  +17   63
 5. Bor. Mönchengladbach          34  10  5  2  37:16    7  4  6  29:25    66:41  +25   60
 6. Bayern München                34   9  7  1  32:19    6  6  5  23:22    55:41  +14   58
 7. Bayer 04 Leverkusen           34   7  5  5  31:23    6  5  6  31:28    62:51  +11   49
 8. Karlsruher SC                 34   8  7  2  38:26    3  7  7  13:21    51:47   +4   47
 9. Eintracht Frankfurt           34  10  3  4  28:18    2  6  9  13:31    41:49   -8   45
10. 1. FC Köln                    34   8  3  6  31:28    3  7  7  23:26    54:54        43
11. FC Schalke 04                 34   7  6  4  28:18    3  5  9  20:36    48:54   -6   41
12. VfB Stuttgart                 34   8  6  3  36:26    2  4 11  16:40    52:66  -14   40
13. Hamburger SV                  34   7  4  6  24:21    3  5  9  19:29    43:50   -7   39
14. TSV 1860 München              34   7  4  6  26:23    1  7  9  15:34    41:57  -16   35
15. KFC Uerdingen                 34   5  7  5  23:22    2  4 11  14:30    37:52  -15   32
16. VfL Bochum                    34   6  2  9  21:23    3  2 12  22:44    43:67  -24   31
17. MSV Duisburg                  34   5  4  8  19:29    1  4 12  12:35    31:64  -33   26
18. Dynamo Dresden                34   3  6  8  17:26    1  2 14  16:42    33:68  -35   20
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Hansa Rostock                 34  13  2  2  47:14    6  6  5  19:16    66:30  +36   65
 2. FC St. Pauli                  34  10  7  0  36:11    5  7  5  22:22    58:33  +25   59
 3. Fortuna Düsseldorf            34   6  9  2  24:16    9  4  4  27:19    51:35  +16   58
 4. VfL Wolfsburg                 34  11  4  2  30:13    4  9  4  21:27    51:40  +11   58
 5. SV Meppen                     34  11  4  2  37:18    4  7  6  17:20    54:38  +16   56
 6. VfR Mannheim                  34  10  4  3  32:20    3 12  2  16:15    48:35  +13   55
 7. Fortuna Köln                  34   8  5  4  34:17    5  3  9  21:32    55:49   +6   47
 8. 1. FC Saarbrücken             34   8  6  3  29:17    3  7  7  16:26    45:43   +2   46
 9. VfB Leipzig (-2004)           34   8  3  6  18:12    4  5  8  25:29    43:41   +2   44
10. SG Wattenscheid 09            34   7  6  4  32:24    4  5  8  18:28    50:52   -2   44
11. Hertha BSC                    34   6  7  4  26:19    4  5  8  15:26    41:45   -4   42
12. Chemnitzer FC                 34   7  7  3  26:15    3  5  9  18:34    44:49   -5   42
13. Hannover 96                   34   8  5  4  36:23    2  6  9  16:27    52:50   +2   41
14. 1. FSV Mainz 05               34   7  7  3  34:25    3  3 11  16:30    50:55   -5   40
15. 1. FC Nürnberg                34   5  9  3  21:15    3  5  9  17:32    38:47   -9   38
16. FSV Zwickau                   34   5  9  3  19:16    1  8  8  13:34    32:50  -18   35
17. FC 08 Homburg                 34   6  5  6  25:19    2  2 13  16:44    41:63  -22   31
18. FSV Frankfurt                 34   2  3 12  17:41    1  3 13  22:62    39:103 -64   15
```

(Source: [`2-bundesliga2.csv`](2-bundesliga2.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

