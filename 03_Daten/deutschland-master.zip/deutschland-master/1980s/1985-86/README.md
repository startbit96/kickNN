

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bayern München                34  14  1  2  58:14    7  6  4  24:17    82:31  +51   70
 2. Werder Bremen                 34  13  4  0  55:13    7  5  5  28:28    83:41  +42   69
 3. KFC Uerdingen                 34  13  2  2  38:24    6  5  6  25:36    63:60   +3   64
 4. VfB Stuttgart                 34  11  3  3  39:14    6  4  7  30:31    69:45  +24   58
 5. Bor. Mönchengladbach          34  10  5  2  39:18    5  7  5  26:33    65:51  +14   57
 6. Hamburger SV                  34  12  2  3  35:11    5  3  9  17:24    52:35  +17   56
 7. Bayer 04 Leverkusen           34  13  3  1  42:18    2  7  8  21:33    63:51  +12   55
 8. VfL Bochum                    34  10  3  4  38:23    4  1 12  17:34    55:57   -2   46
 9. SV Waldhof Mannheim           34   9  5  3  29:16    2  6  9  12:28    41:44   -3   44
10. 1. FC Nürnberg                34   8  3  6  31:22    4  2 11  20:32    51:54   -3   41
11. FC Schalke 04                 34   9  4  4  37:21    2  4 11  16:37    53:58   -5   41
12. 1. FC Kaiserslautern          34   8  6  3  26:14    2  4 11  23:40    49:54   -5   40
13. Fortuna Düsseldorf            34   8  5  4  31:28    3  2 12  23:50    54:78  -24   40
14. 1. FC Köln                    34   7  6  4  31:22    2  5 10  15:37    46:59  -13   38
15. Borussia Dortmund             34   8  5  4  34:24    2  3 12  15:41    49:65  -16   38
16. Eintracht Frankfurt           34   6  8  3  23:18    1  6 10  12:31    35:49  -14   35
17. 1. FC Saarbrücken             34   5  7  5  25:28    1  2 14  14:40    39:68  -29   27
18. Hannover 96                   34   4  4  9  20:33    1  4 12  23:59    43:92  -49   23
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

