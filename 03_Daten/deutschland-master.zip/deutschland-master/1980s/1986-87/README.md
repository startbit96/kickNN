

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bayern München                34  14  2  1  41:14    6 11  0  26:17    67:31  +36   73
 2. Hamburger SV                  34  14  2  1  38:12    5  7  5  31:25    69:37  +32   66
 3. Bor. Mönchengladbach          34  11  2  4  42:18    7  5  5  32:26    74:44  +30   61
 4. Werder Bremen                 34  13  3  1  45:19    4  3 10  20:35    65:54  +11   57
 5. Borussia Dortmund             34  10  5  2  40:17    5  5  7  30:33    70:50  +20   55
 6. Bayer 04 Leverkusen           34  10  3  4  34:19    6  4  7  22:19    56:38  +18   55
 7. 1. FC Kaiserslautern          34  11  3  3  41:21    4  4  9  23:30    64:51  +13   52
 8. 1. FC Köln                    34   8  6  3  27:19    5  3  9  23:34    50:53   -3   48
 9. KFC Uerdingen                 34   8  6  3  30:22    4  5  8  21:27    51:49   +2   47
10. 1. FC Nürnberg                34   8  7  2  39:25    4  4  9  23:37    62:62        47
11. VfB Stuttgart                 34  10  4  3  41:18    3  2 12  14:31    55:49   +6   45
12. FC Schalke 04                 34  10  3  4  36:24    2  5 10  14:34    50:58   -8   44
13. VfL Bochum                    34   7  7  3  30:16    2  7  8  22:28    52:44   +8   41
14. SV Waldhof Mannheim           34  10  6  1  36:20    0  2 15  16:51    52:71  -19   38
15. Eintracht Frankfurt           34   8  4  5  29:20    0  5 12  13:33    42:53  -11   33
16. FC 08 Homburg                 34   6  6  5  24:23    0  3 14   9:56    33:79  -46   27
17. Fortuna Düsseldorf            34   6  4  7  24:35    1  2 14  18:56    42:91  -49   27
18. Blau-Weiß 90 Berlin (-1992)   34   2  8  7  20:31    1  4 12  16:45    36:76  -40   21
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

