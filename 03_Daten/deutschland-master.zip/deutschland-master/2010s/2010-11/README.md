

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Borussia Dortmund             34  12  4  1  35:8    11  2  4  32:14    67:22  +45   75
 2. Bayer 04 Leverkusen           34   9  5  3  33:24   11  3  3  31:20    64:44  +20   68
 3. Bayern München                34  13  2  2  48:13    6  6  5  33:27    81:40  +41   65
 4. Hannover 96                   34  12  1  4  32:17    7  2  8  17:28    49:45   +4   60
 5. 1. FSV Mainz 05               34   8  2  7  22:16   10  2  5  30:23    52:39  +13   58
 6. 1. FC Nürnberg                34   9  2  6  28:19    4  6  7  19:26    47:45   +2   47
 7. 1. FC Kaiserslautern          34   6  6  5  25:19    7  1  9  23:32    48:51   -3   46
 8. Hamburger SV                  34   7  5  5  29:24    5  4  8  17:28    46:52   -6   45
 9. SC Freiburg                   34   8  2  7  24:24    5  3  9  17:26    41:50   -9   44
10. 1. FC Köln                    34  11  2  4  30:21    2  3 12  17:41    47:62  -15   44
11. TSG 1899 Hoffenheim           34   7  5  5  28:21    4  5  8  22:29    50:50        43
12. VfB Stuttgart                 34   7  2  8  33:27    5  4  8  27:32    60:59   +1   42
13. Werder Bremen                 34   6  6  5  26:23    4  5  8  21:38    47:61  -14   41
14. FC Schalke 04                 34   7  3  7  24:18    4  4  9  14:26    38:44   -6   40
15. VfL Wolfsburg                 34   5  6  6  27:26    4  5  8  16:22    43:48   -5   38
16. Bor. Mönchengladbach          34   5  3  9  26:31    5  3  9  22:34    48:65  -17   36
17. Eintracht Frankfurt           34   5  4  8  13:24    4  3 10  18:25    31:49  -18   34
18. FC St. Pauli                  34   4  3 10  21:35    4  2 11  14:33    35:68  -33   29
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Hertha BSC                    34  12  2  3  38:16   11  3  3  31:12    69:28  +41   74
 2. FC Augsburg                   34  10  4  3  31:14    9  4  4  27:13    58:27  +31   65
 3. VfL Bochum                    34  11  2  4  28:18    9  3  5  21:17    49:35  +14   65
 4. Greuther Fürth                34  10  5  2  24:11    7  5  5  23:16    47:27  +20   61
 5. FC Erzgebirge Aue             34  10  4  3  21:11    6  4  7  19:26    40:37   +3   56
 6. Energie Cottbus               34  10  5  2  37:18    6  2  9  28:34    65:52  +13   55
 7. Fortuna Düsseldorf            34  13  1  3  34:9     3  4 10  15:30    49:39  +10   53
 8. MSV Duisburg                  34  11  1  5  33:17    4  6  7  20:21    53:38  +15   52
 9. TSV 1860 München              34   7  7  3  27:16    7  3  7  23:20    50:36  +14   52
10. Alemannia Aachen              34   7  5  5  30:32    6  4  7  28:28    58:60   -2   48
11. 1. FC Union Berlin            34   7  6  4  25:19    4  3 10  14:26    39:45   -6   42
12. SC Paderborn 07               34   7  6  4  21:20    3  3 11  11:27    32:47  -15   39
13. FSV Frankfurt                 34   8  1  8  24:23    3  4 10  18:31    42:54  -12   38
14. FC Ingolstadt 04              34   5  5  7  18:19    4  5  8  22:27    40:46   -6   37
15. Karlsruher SC                 34   7  4  6  28:29    1  5 11  18:43    46:72  -26   33
16. Osnabrück                     34   6  4  7  24:25    2  3 12  16:37    40:62  -22   31
17. Rot-Weiß Oberhausen           34   6  3  8  18:25    1  4 12  12:40    30:65  -35   28
18. Arminia Bielefeld             34   3  4 10  18:34    1  4 12  10:31    28:65  -37   20
```

(Source: [`2-bundesliga2.csv`](2-bundesliga2.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

