

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bayern München                34  15  1  1  51:8    13  3  1  29:9     80:17  +63   88
 2. Borussia Dortmund             34  14  3  0  49:14   10  3  4  33:20    82:34  +48   78
 3. Bayer 04 Leverkusen           34  10  3  4  31:17    8  3  6  25:23    56:40  +16   60
 4. Bor. Mönchengladbach          34  13  1  3  42:18    4  3 10  25:32    67:50  +17   55
 5. FC Schalke 04                 34   8  5  4  28:24    7  2  8  23:25    51:49   +2   52
 6. 1. FSV Mainz 05               34   8  4  5  23:18    6  4  7  23:24    46:42   +4   50
 7. Hertha BSC                    34   9  5  3  24:15    5  3  9  18:27    42:42        50
 8. VfL Wolfsburg                 34   9  5  3  32:17    3  4 10  15:32    47:49   -2   45
 9. 1. FC Köln                    34   5  5  7  16:18    5  8  4  22:24    38:42   -4   43
10. Hamburger SV                  34   5  4  8  20:23    6  4  7  20:23    40:46   -6   41
11. FC Ingolstadt 04              34   7  5  5  22:18    3  5  9  11:24    33:42   -9   40
12. FC Augsburg                   34   3  6  8  18:27    6  5  6  24:25    42:52  -10   38
13. Werder Bremen                 34   5  5  7  27:30    5  3  9  23:35    50:65  -15   38
14. SV Darmstadt 98               34   2  6  9  15:29    7  5  5  23:24    38:53  -15   38
15. TSG 1899 Hoffenheim           34   6  6  5  22:25    3  4 10  17:29    39:54  -15   37
16. Eintracht Frankfurt           34   6  6  5  22:24    3  3 11  12:28    34:52  -18   36
17. VfB Stuttgart                 34   6  1 10  22:32    3  5  9  28:43    50:75  -25   33
18. Hannover 96                   34   4  0 13  15:30    3  4 10  16:32    31:62  -31   25
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. SC Freiburg                   34  13  2  2  47:20    9  4  4  28:19    75:39  +36   72
 2. RB Leipzig                    34  11  3  3  33:17    9  4  4  21:15    54:32  +22   67
 3. 1. FC Nürnberg                34  11  5  1  33:18    8  3  6  35:23    68:41  +27   65
 4. FC St. Pauli                  34   9  2  6  26:22    6  6  5  19:17    45:39   +6   53
 5. VfL Bochum                    34   7  7  3  31:19    6  5  6  25:21    56:40  +16   51
 6. 1. FC Union Berlin            34   9  6  2  32:20    4  4  9  24:30    56:50   +6   49
 7. Karlsruher SC                 34   7  7  3  23:14    5  4  8  12:23    35:37   -2   47
 8. Eintracht Braunschweig        34   7  6  4  21:15    5  4  8  23:23    44:38   +6   46
 9. Greuther Fürth                34   8  2  7  25:25    5  5  7  24:30    49:55   -6   46
10. 1. FC Kaiserslautern          34   5  6  6  18:19    7  3  7  31:28    49:47   +2   45
11. 1. FC Heidenheim              34   6  6  5  23:24    5  6  6  19:16    42:40   +2   45
12. SV Sandhausen                 34   6  5  6  18:23    6  2  9  22:27    40:50  -10   43
13. Arminia Bielefeld             34   4  8  5  14:19    4 10  3  24:20    38:39   -1   42
14. Fortuna Düsseldorf            34   6  3  8  18:22    3  5  9  14:25    32:47  -15   35
15. TSV 1860 München              34   6  5  6  17:17    2  5 10  15:29    32:46  -14   34
16. MSV Duisburg                  34   6  5  6  17:22    1  6 10  15:32    32:54  -22   32
17. FSV Frankfurt                 34   4  1 12  18:37    4  7  6  15:22    33:59  -26   32
18. SC Paderborn 07               34   2  7  8  13:28    4  3 10  15:27    28:55  -27   28
```

(Source: [`2-bundesliga2.csv`](2-bundesliga2.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

