

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bayern München                34  13  4  0  55:9    12  3  2  34:13    89:22  +67   82
 2. RB Leipzig                    34  12  2  3  35:16    8  5  4  31:23    66:39  +27   67
 3. Borussia Dortmund             34  13  4  0  41:12    5  6  6  31:28    72:40  +32   64
 4. TSG 1899 Hoffenheim           34  11  6  0  35:14    5  8  4  29:23    64:37  +27   62
 5. 1. FC Köln                    34   9  6  2  29:17    3  7  7  22:25    51:42   +9   49
 6. Hertha BSC                    34  12  1  4  28:19    3  3 11  15:28    43:47   -4   49
 7. SC Freiburg                   34  10  2  5  23:24    4  4  9  19:36    42:60  -18   48
 8. Werder Bremen                 34   8  1  8  28:24    5  5  7  33:40    61:64   -3   45
 9. Bor. Mönchengladbach          34   7  5  5  26:18    5  4  8  19:31    45:49   -4   45
10. FC Schalke 04                 34   8  5  4  29:15    3  5  9  16:25    45:40   +5   43
11. Eintracht Frankfurt           34   7  7  3  24:18    4  2 11  12:25    36:43   -7   42
12. Bayer 04 Leverkusen           34   5  6  6  27:28    6  2  9  26:27    53:55   -2   41
13. FC Augsburg                   34   5  6  6  22:25    4  5  8  13:26    35:51  -16   38
14. Hamburger SV                  34   8  4  5  21:25    2  4 11  12:36    33:61  -28   38
15. 1. FSV Mainz 05               34   7  4  6  30:26    3  3 11  14:29    44:55  -11   37
16. VfL Wolfsburg                 34   5  3  9  15:25    5  4  8  19:27    34:52  -18   37
17. FC Ingolstadt 04              34   4  5  8  21:30    4  3 10  15:27    36:57  -21   32
18. SV Darmstadt 98               34   6  3  8  18:25    1  1 15  10:38    28:63  -35   25
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. VfB Stuttgart                 34  13  2  2  40:15    8  4  5  23:22    63:37  +26   69
 2. Hannover 96                   34  14  2  1  26:9     5  8  4  25:23    51:32  +19   67
 3. Eintracht Braunschweig        34  13  3  1  35:17    6  6  5  15:19    50:36  +14   66
 4. 1. FC Union Berlin            34  11  3  3  29:12    7  3  7  22:27    51:39  +12   60
 5. Dynamo Dresden                34   6  8  3  27:21    7  3  7  26:25    53:46   +7   50
 6. 1. FC Heidenheim              34   7  5  5  24:18    5  5  7  19:21    43:39   +4   46
 7. FC St. Pauli                  34   5  7  5  20:14    7  2  8  19:21    39:35   +4   45
 8. Greuther Fürth                34   9  2  6  18:17    3  7  7  15:23    33:40   -7   45
 9. VfL Bochum                    34   7  8  2  27:22    3  6  8  15:25    42:47   -5   44
10. SV Sandhausen                 34   6  6  5  22:14    4  6  7  19:22    41:36   +5   42
11. Fortuna Düsseldorf            34   4  7  6  19:22    6  5  6  18:17    37:39   -2   42
12. 1. FC Nürnberg                34   6  3  8  23:25    6  3  8  23:27    46:52   -6   42
13. 1. FC Kaiserslautern          34   8  5  4  17:9     2  6  9  12:24    29:33   -4   41
14. FC Erzgebirge Aue             34   7  4  6  21:24    3  5  9  16:28    37:52  -15   39
15. Arminia Bielefeld             34   7  6  4  31:23    1  7  9  19:31    50:54   -4   37
16. TSV 1860 München              34   7  4  6  24:21    3  2 12  13:26    37:47  -10   36
17. Würzburger Kickers            34   4  8  5  14:14    3  5  9  18:27    32:41   -9   34
18. Karlsruher SC                 34   3  5  9  18:29    2  5 10   9:27    27:56  -29   25
```

(Source: [`2-bundesliga2.csv`](2-bundesliga2.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

