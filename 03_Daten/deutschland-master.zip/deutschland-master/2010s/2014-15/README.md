

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bayern München                34  14  1  2  46:7    11  3  3  34:11    80:18  +62   79
 2. VfL Wolfsburg                 34  13  4  0  38:13    7  5  5  34:25    72:38  +34   69
 3. Bor. Mönchengladbach          34  12  3  2  32:14    7  6  4  21:12    53:26  +27   66
 4. Bayer 04 Leverkusen           34  10  6  1  39:15    7  4  6  23:22    62:37  +25   61
 5. FC Augsburg                   34   9  4  4  28:21    6  0 11  15:22    43:43        49
 6. FC Schalke 04                 34  10  5  2  26:14    3  4 10  16:26    42:40   +2   48
 7. Borussia Dortmund             34   9  3  5  26:15    4  4  9  21:27    47:42   +5   46
 8. TSG 1899 Hoffenheim           34   9  3  5  31:26    3  5  9  18:29    49:55   -6   44
 9. Eintracht Frankfurt           34   9  5  3  36:26    2  5 10  20:36    56:62   -6   43
10. Werder Bremen                 34   8  4  5  25:24    3  6  8  25:41    50:65  -15   43
11. 1. FSV Mainz 05               34   6  6  5  27:19    3  7  7  18:28    45:47   -2   40
12. 1. FC Köln                    34   4  9  4  18:17    5  4  8  16:23    34:40   -6   40
13. Hannover 96                   34   6  4  7  21:25    3  6  8  19:31    40:56  -16   37
14. VfB Stuttgart                 34   5  4  8  18:28    4  5  8  24:32    42:60  -18   36
15. Hertha BSC                    34   6  4  7  17:22    3  4 10  19:30    36:52  -16   35
16. Hamburger SV                  34   6  5  6  16:18    3  3 11   9:32    25:50  -25   35
17. SC Freiburg                   34   5  6  6  21:22    2  7  8  15:25    36:47  -11   34
18. SC Paderborn 07               34   4  6  7  21:31    3  4 10  10:34    31:65  -34   31
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. FC Ingolstadt 04              34  10  5  2  32:19    7  8  2  21:13    53:32  +21   64
 2. SV Darmstadt 98               34  11  5  1  30:10    4  9  4  14:16    44:26  +18   59
 3. Karlsruher SC                 34   7  8  2  19:7     8  5  4  27:19    46:26  +20   58
 4. 1. FC Kaiserslautern          34  11  5  1  27:12    3  9  5  18:19    45:31  +14   56
 5. RB Leipzig                    34  10  4  3  27:16    3  7  7  12:15    39:31   +8   50
 6. Eintracht Braunschweig        34   9  4  4  25:17    6  1 10  19:24    44:41   +3   50
 7. 1. FC Union Berlin            34   8  5  4  24:21    4  6  7  22:30    46:51   -5   47
 8. 1. FC Heidenheim              34   8  4  5  29:15    4  6  7  20:29    49:44   +5   46
 9. 1. FC Nürnberg                34   9  4  4  24:17    4  2 11  18:30    42:47   -5   45
10. Fortuna Düsseldorf            34   4  7  6  24:29    7  4  6  24:23    48:52   -4   44
11. VfL Bochum                    34   4 10  3  28:24    5  5  7  25:31    53:55   -2   42
12. SV Sandhausen                 34   4  8  5  12:17    6  4  7  20:20    32:37   -5   42
13. FSV Frankfurt                 34   3  7  7  18:27    7  2  8  23:26    41:53  -12   39
14. Greuther Fürth                34   6  5  6  22:20    2  8  7  12:22    34:42   -8   37
15. FC St. Pauli                  34   8  3  6  24:19    2  4 11  16:32    40:51  -11   37
16. TSV 1860 München              34   4  4  9  18:27    5  5  7  23:24    41:51  -10   36
17. FC Erzgebirge Aue             34   6  3  8  18:21    3  6  8  14:26    32:47  -15   36
18. VfR Aalen                     34   5  6  6  23:21    2  6  9  11:25    34:46  -12   33
```

(Source: [`2-bundesliga2.csv`](2-bundesliga2.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

