

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bayern München                34  15  1  1  48:15   14  2  1  46:8     94:23  +71   90
 2. Borussia Dortmund             34  11  2  4  41:19   11  3  3  39:19    80:38  +42   71
 3. FC Schalke 04                 34  12  2  3  37:16    7  5  5  26:27    63:43  +20   64
 4. Bayer 04 Leverkusen           34  10  3  4  35:22    9  1  7  25:19    60:41  +19   61
 5. VfL Wolfsburg                 34  11  3  3  37:22    7  3  7  26:28    63:50  +13   60
 6. Bor. Mönchengladbach          34  11  3  3  38:17    5  4  8  21:26    59:43  +16   55
 7. 1. FSV Mainz 05               34  10  3  4  28:17    6  2  9  24:37    52:54   -2   53
 8. FC Augsburg                   34   9  3  5  27:22    6  4  7  20:25    47:47        52
 9. TSG 1899 Hoffenheim           34   7  6  4  43:31    4  5  8  29:39    72:70   +2   44
10. Hannover 96                   34   8  5  4  27:25    4  1 12  19:34    46:59  -13   42
11. Hertha BSC                    34   6  3  8  20:24    5  5  7  20:24    40:48   -8   41
12. Werder Bremen                 34   6  6  5  21:30    4  3 10  21:36    42:66  -24   39
13. Eintracht Frankfurt           34   5  5  7  22:24    4  4  9  18:33    40:57  -17   36
14. SC Freiburg                   34   6  4  7  25:30    3  5  9  18:31    43:61  -18   36
15. VfB Stuttgart                 34   5  4  8  28:28    3  4 10  21:34    49:62  -13   32
16. Hamburger SV                  34   5  3  9  24:34    2  3 12  27:41    51:75  -24   27
17. 1. FC Nürnberg                34   3  5  9  16:32    2  6  9  21:38    37:70  -33   26
18. Eintracht Braunschweig        34   5  3  9  18:24    1  4 12  11:36    29:60  -31   25
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. 1. FC Köln                    34  10  5  2  30:8     9  6  2  23:12    53:20  +33   68
 2. SC Paderborn 07               34  10  4  3  30:16    8  4  5  33:32    63:48  +15   62
 3. Greuther Fürth                34  10  3  4  29:16    7  6  4  35:22    64:38  +26   60
 4. 1. FC Kaiserslautern          34   9  5  3  33:17    6  4  7  22:22    55:39  +16   54
 5. Karlsruher SC                 34   7  8  2  31:19    5  6  6  16:15    47:34  +13   50
 6. Fortuna Düsseldorf            34   8  4  5  24:21    5  7  5  21:23    45:44   +1   50
 7. TSV 1860 München              34   8  3  6  21:19    5  6  6  17:22    38:41   -3   48
 8. FC St. Pauli                  34   5  5  7  18:23    8  4  5  26:26    44:49   -5   48
 9. 1. FC Union Berlin            34   7  6  4  26:20    4  5  8  22:27    48:47   +1   44
10. FC Ingolstadt 04              34   5  3  9  19:20    6  8  3  15:13    34:33   +1   44
11. VfR Aalen                     34   6  6  5  21:16    5  5  7  15:23    36:39   -3   44
12. SV Sandhausen                 34   7  5  5  17:18    5  3  9  12:17    29:35   -6   44
13. FSV Frankfurt                 34   7  5  5  23:22    4  3 10  23:29    46:51   -5   41
14. FC Erzgebirge Aue             34   9  3  5  25:22    2  5 10  17:32    42:54  -12   41
15. VfL Bochum                    34   5  4  8  16:24    6  3  8  14:19    30:43  -13   40
16. Arminia Bielefeld             34   4  7  6  19:23    5  1 11  21:35    40:58  -18   35
17. Dynamo Dresden                34   4  9  4  23:24    1  8  8  13:29    36:53  -17   32
18. Energie Cottbus               34   5  3  9  22:30    1  4 12  13:29    35:59  -24   25
```

(Source: [`2-bundesliga2.csv`](2-bundesliga2.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

