

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bayern München                34  14  2  1  56:15   13  1  3  36:13    92:28  +64   84
 2. FC Schalke 04                 34  10  5  2  27:15    8  4  5  26:22    53:37  +16   63
 3. TSG 1899 Hoffenheim           34  11  4  2  38:16    4  6  7  28:32    66:48  +18   55
 4. Borussia Dortmund             34   9  4  4  40:21    6  6  5  24:26    64:47  +17   55
 5. Bayer 04 Leverkusen           34   8  5  4  29:19    7  5  5  29:25    58:44  +14   55
 6. RB Leipzig                    34   9  4  4  34:26    6  4  7  23:27    57:53   +4   53
 7. VfB Stuttgart                 34  10  4  3  18:9     5  2 10  18:27    36:36        51
 8. Eintracht Frankfurt           34   8  4  5  26:19    6  3  8  19:26    45:45        49
 9. Bor. Mönchengladbach          34   9  4  4  28:20    4  4  9  19:32    47:52   -5   47
10. Hertha BSC                    34   5  7  5  23:27    5  6  6  20:19    43:46   -3   43
11. Werder Bremen                 34   6  7  4  20:17    4  5  8  17:23    37:40   -3   42
12. FC Augsburg                   34   6  4  7  24:24    4  7  6  19:22    43:46   -3   41
13. Hannover 96                   34   8  3  6  28:25    2  6  9  16:29    44:54  -10   39
14. 1. FSV Mainz 05               34   7  3  7  22:21    2  6  9  16:31    38:52  -14   36
15. SC Freiburg                   34   7  6  4  17:17    1  6 10  15:39    32:56  -24   36
16. VfL Wolfsburg                 34   3  8  6  23:25    3  7  7  13:23    36:48  -12   33
17. Hamburger SV                  34   6  4  7  17:19    2  3 12  12:34    29:53  -24   31
18. 1. FC Köln                    34   3  5  9  20:30    2  2 13  15:40    35:70  -35   22
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Fortuna Düsseldorf            34  10  4  3  30:20    9  2  6  27:24    57:44  +13   63
 2. 1. FC Nürnberg                34   8  4  5  32:23    9  5  3  29:16    61:39  +22   60
 3. Holstein Kiel                 34   8  7  2  36:19    6  7  4  35:25    71:44  +27   56
 4. Arminia Bielefeld             34   7  6  4  25:20    5  6  6  26:27    51:47   +4   48
 5. SSV Jahn Regensburg           34  10  0  7  31:27    4  6  7  22:26    53:53        48
 6. VfL Bochum                    34   8  5  4  22:16    5  4  8  15:24    37:40   -3   48
 7. MSV Duisburg                  34   6  5  6  27:28    7  4  6  25:28    52:56   -4   48
 8. 1. FC Union Berlin            34   7  7  3  30:19    5  4  8  24:27    54:46   +8   47
 9. FC Ingolstadt 04              34   5  4  8  24:26    7  5  5  23:19    47:45   +2   45
10. SV Darmstadt 98               34   6  5  6  27:24    4  8  5  20:21    47:45   +2   43
11. SV Sandhausen                 34   7  5  5  19:15    4  5  8  16:18    35:33   +2   43
12. FC St. Pauli                  34   5  8  4  20:20    6  2  9  15:28    35:48  -13   43
13. 1. FC Heidenheim              34   9  3  5  32:27    2  6  9  18:29    50:56   -6   42
14. Dynamo Dresden                34   5  4  8  19:27    6  4  7  23:25    42:52  -10   41
15. Greuther Fürth                34   9  4  4  26:18    1  6 10  11:30    37:48  -11   40
16. FC Erzgebirge Aue             34   7  5  5  18:20    3  5  9  17:29    35:49  -14   40
17. Eintracht Braunschweig        34   6  6  5  20:18    2  9  6  17:25    37:43   -6   39
18. 1. FC Kaiserslautern          34   4  7  6  18:20    5  1 11  24:35    42:55  -13   35
```

(Source: [`2-bundesliga2.csv`](2-bundesliga2.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

