

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Borussia Dortmund             34  14  2  1  44:12   11  4  2  36:13    80:25  +55   81
 2. Bayern München                34  14  1  2  49:6     9  3  5  28:16    77:22  +55   73
 3. FC Schalke 04                 34  13  1  3  47:14    7  3  7  27:30    74:44  +30   64
 4. Bor. Mönchengladbach          34   9  7  1  29:10    8  2  7  20:14    49:24  +25   60
 5. Bayer 04 Leverkusen           34   8  4  5  28:24    7  5  5  24:20    52:44   +8   54
 6. VfB Stuttgart                 34  10  3  4  36:17    5  5  7  27:29    63:46  +17   53
 7. Hannover 96                   34  10  7  0  31:17    2  5 10  10:28    41:45   -4   48
 8. VfL Wolfsburg                 34  10  2  5  29:22    3  3 11  18:38    47:60  -13   44
 9. Werder Bremen                 34   8  4  5  31:23    3  5  9  18:35    49:58   -9   42
10. 1. FC Nürnberg                34   6  4  7  22:25    6  2  9  16:24    38:49  -11   42
11. TSG 1899 Hoffenheim           34   4  9  4  21:17    6  2  9  20:30    41:47   -6   41
12. SC Freiburg                   34   6  6  5  24:20    4  4  9  21:41    45:61  -16   40
13. 1. FSV Mainz 05               34   7  3  7  27:26    2  9  6  20:25    47:51   -4   39
14. FC Augsburg                   34   6  7  4  20:19    2  7  8  16:30    36:49  -13   38
15. Hamburger SV                  34   3  7  7  19:29    5  5  7  16:28    35:57  -22   36
16. Hertha BSC                    34   4  3 10  19:29    3  7  7  19:35    38:64  -26   31
17. 1. FC Köln                    34   5  4  8  20:29    3  2 12  19:46    39:75  -36   30
18. 1. FC Kaiserslautern          34   2  5 10  12:28    2  6  9  12:26    24:54  -30   23
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Greuther Fürth                34  14  1  2  46:12    6  9  2  27:15    73:27  +46   70
 2. Eintracht Frankfurt           34  11  5  1  38:12    9  3  5  38:21    76:33  +43   68
 3. Fortuna Düsseldorf            34  11  5  1  35:17    5  9  3  29:18    64:35  +29   62
 4. FC St. Pauli                  34  12  3  2  36:16    6  5  6  23:18    59:34  +25   62
 5. SC Paderborn 07               34   9  6  2  28:16    8  4  5  23:26    51:42   +9   61
 6. TSV 1860 München              34  10  2  5  35:22    7  4  6  27:24    62:46  +16   57
 7. 1. FC Union Berlin            34  11  2  4  30:18    3  4 10  25:40    55:58   -3   48
 8. Eintracht Braunschweig        34   6  8  3  21:15    4  7  6  16:20    37:35   +2   45
 9. Dynamo Dresden                34   8  5  4  30:20    4  4  9  20:32    50:52   -2   45
10. MSV Duisburg                  34   8  2  7  23:18    2  7  8  19:29    42:47   -5   39
11. VfL Bochum                    34   7  3  7  23:23    3  4 10  18:32    41:55  -14   37
12. FC Ingolstadt 04              34   6  8  3  28:21    2  5 10  15:37    43:58  -15   37
13. FSV Frankfurt                 34   3 10  4  20:26    4  4  9  23:33    43:59  -16   35
14. Energie Cottbus               34   4  8  5  18:25    4  3 10  12:24    30:49  -19   35
15. FC Erzgebirge Aue             34   5  7  5  19:22    3  4 10  12:33    31:55  -24   35
16. Karlsruher SC                 34   8  3  6  23:28    1  3 13  11:32    34:60  -26   33
17. Alemannia Aachen              34   4  6  7  15:24    2  7  8  15:23    30:47  -17   31
18. Hansa Rostock                 34   3  7  7  20:32    2  5 10  14:31    34:63  -29   27
```

(Source: [`2-bundesliga2.csv`](2-bundesliga2.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

