

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bayern München                34  13  3  1  37:12   10  3  4  33:13    70:25  +45   75
 2. VfB Stuttgart                 34   9  5  3  30:14    8  3  6  23:25    53:39  +14   59
 3. Borussia Dortmund             34  10  6  1  31:13    5  7  5  20:14    51:27  +24   58
 4. Hamburger SV                  34  13  3  1  30:11    2  8  7  16:25    46:36  +10   56
 5. Hertha BSC                    34  10  4  3  35:19    6  2  9  17:24    52:43   +9   54
 6. Werder Bremen                 34  10  2  5  34:23    6  2  9  17:27    51:50   +1   52
 7. FC Schalke 04                 34   6  8  3  23:16    6  5  6  23:24    46:40   +6   49
 8. VfL Wolfsburg                 34  11  2  4  26:15    2  5 10  13:27    39:42   -3   46
 9. VfL Bochum                    34   6  5  6  26:25    6  4  7  29:31    55:56   -1   45
10. TSV 1860 München              34   6  5  6  22:22    6  4  7  22:30    44:52   -8   45
11. Hannover 96                   34   4  6  7  28:33    8  1  8  19:24    47:57  -10   43
12. Bor. Mönchengladbach          34  10  5  2  31:11    1  4 12  12:34    43:45   -2   42
13. Hansa Rostock                 34   6  5  6  20:18    5  3  9  15:23    35:41   -6   41
14. 1. FC Kaiserslautern          34   9  3  5  23:12    1  7  9  17:30    40:42   -2   40
15. Bayer 04 Leverkusen           34   6  3  8  27:28    5  4  8  20:28    47:56   -9   40
16. Arminia Bielefeld             34   7  5  5  23:16    1  7  9  12:30    35:46  -11   36
17. 1. FC Nürnberg                34   4  4  9  16:24    4  2 11  17:36    33:60  -27   30
18. Energie Cottbus               34   4  3 10  17:30    3  6  8  17:34    34:64  -30   30
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. SC Freiburg                   34  12  3  2  38:16    8  4  5  20:16    58:32  +26   67
 2. 1. FC Köln                    34  12  3  2  40:23    6  8  3  23:22    63:45  +18   65
 3. Eintracht Frankfurt           34  10  5  2  34:16    7  6  4  25:17    59:33  +26   62
 4. 1. FSV Mainz 05               34  11  4  2  34:18    8  1  8  30:21    64:39  +25   62
 5. Greuther Fürth                34   9  6  2  30:11    6  6  5  25:24    55:35  +20   57
 6. Alemannia Aachen              34  10  2  5  30:13    4  7  6  27:35    57:48   +9   51
 7. Eintracht Trier               34   7  2  8  27:23    7  4  6  26:23    53:46   +7   48
 8. MSV Duisburg                  34   9  5  3  25:17    3  5  9  17:30    42:47   -5   46
 9. 1. FC Union Berlin            34   3 10  4  19:22    7  5  5  17:26    36:48  -12   45
10. Wacker Burghausen             34   6  7  4  25:19    4  7  6  23:22    48:41   +7   44
11. Lübeck                        34  10  3  4  33:16    3  2 12  18:34    51:50   +1   44
12. Rot Weiss Ahlen               34   7  5  5  27:26    4  2 11  21:34    48:60  -12   40
13. SSV Reutlingen 05             34   6  1 10  24:28    5  5  7  19:25    43:53  -10   39
14. Karlsruher SC                 34   5  7  5  19:21    4  5  8  16:26    35:47  -12   39
15. Rot-Weiß Oberhausen           34  10  4  3  30:17    0  3 14   8:31    38:48  -10   37
16. Eintracht Braunschweig        34   3  6  8  17:24    5  4  8  16:29    33:53  -20   34
17. FC St. Pauli                  34   4  6  7  28:28    3  4 10  20:39    48:67  -19   31
18. VfR Mannheim                  34   3  3 11  12:33    3  4 10  20:38    32:71  -39   25
```

(Source: [`2-bundesliga2.csv`](2-bundesliga2.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

