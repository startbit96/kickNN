

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bayern München                34  12  5  0  41:8    10  5  2  27:13    68:21  +47   76
 2. Werder Bremen                 34  13  0  4  48:19    7  6  4  27:26    75:45  +30   66
 3. FC Schalke 04                 34  10  4  3  29:13    8  6  3  26:19    55:32  +23   64
 4. Hamburger SV                  34   9  5  3  30:11    5  7  5  17:15    47:26  +21   54
 5. VfL Wolfsburg                 34   7  6  4  28:17    8  3  6  30:29    58:46  +12   54
 6. VfB Stuttgart                 34  12  2  3  39:19    4  2 11  18:38    57:57        52
 7. Bayer 04 Leverkusen           34   9  4  4  32:13    6  2  9  25:27    57:40  +17   51
 8. Hannover 96                   34   8  5  4  32:27    5  5  7  22:29    54:56   -2   49
 9. Eintracht Frankfurt           34   8  4  5  24:24    4  6  7  19:26    43:50   -7   46
10. Hertha BSC                    34   9  3  5  21:18    3  5  9  18:26    39:44   -5   44
11. Karlsruher SC                 34   6  6  5  23:22    5  4  8  15:31    38:53  -15   43
12. VfL Bochum                    34   5  9  3  32:28    5  2 10  16:26    48:54   -6   41
13. Borussia Dortmund             34   7  5  5  29:24    3  5  9  21:38    50:62  -12   40
14. Energie Cottbus               34   8  2  7  25:20    1  7  9  10:36    35:56  -21   36
15. Arminia Bielefeld             34   7  4  6  21:18    1  6 10  14:42    35:60  -25   34
16. 1. FC Nürnberg                34   5  7  5  21:18    2  3 12  14:33    35:51  -16   31
17. Hansa Rostock                 34   5  4  8  17:21    3  2 12  13:31    30:52  -22   30
18. MSV Duisburg                  34   3  3 11  19:29    5  2 10  17:26    36:55  -19   29
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bor. Mönchengladbach          34  10  5  2  31:15    8  7  2  40:23    71:38  +33   66
 2. TSG 1899 Hoffenheim           34  11  2  4  34:17    6  7  4  26:23    60:40  +20   60
 3. 1. FC Köln                    34  11  4  2  31:16    6  5  6  31:28    62:44  +18   60
 4. 1. FSV Mainz 05               34  11  4  2  43:15    5  6  6  19:21    62:36  +26   58
 5. SC Freiburg                   34  11  3  3  26:16    4  7  6  23:28    49:44   +5   55
 6. Greuther Fürth                34   9  5  3  35:21    5  5  7  18:26    53:47   +6   52
 7. Alemannia Aachen              34   8  5  4  33:25    6  4  7  16:19    49:44   +5   51
 8. TuS Koblenz                   34   7  8  2  26:20    5  3  9  20:27    46:47   -1   47
 9. SV Wehen Wiesbaden            34   6  6  5  27:24    5  5  7  20:29    47:53   -6   44
10. FC St. Pauli                  34   9  4  4  30:21    2  5 10  17:32    47:53   -6   42
11. TSV 1860 München              34   5  7  5  21:20    4  7  6  21:25    42:45   -3   41
12. Osnabrück                     34   8  5  4  25:18    2  5 10  18:36    43:54  -11   40
13. 1. FC Kaiserslautern          34   6  5  6  21:16    3  7  7  16:21    37:37        39
14. FC Augsburg                   34   7  6  4  24:20    3  2 12  15:31    39:51  -12   38
15. Kickers Offenbach             34   7  7  3  25:25    2  4 11  13:35    38:60  -22   38
16. FC Erzgebirge Aue             34   6  9  2  36:18    1  2 14  13:39    49:57   -8   32
17. SC Paderborn 07               34   5  6  6  24:25    1  7  9   9:29    33:54  -21   31
18. FC Carl Zeiss Jena            34   4  4  9  22:26    2  7  8  23:42    45:68  -23   29
```

(Source: [`2-bundesliga2.csv`](2-bundesliga2.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

