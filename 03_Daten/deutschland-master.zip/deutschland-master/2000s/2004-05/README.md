

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bayern München                34  14  2  1  44:14   10  3  4  31:19    75:33  +42   77
 2. FC Schalke 04                 34  11  2  4  33:24    9  1  7  23:22    56:46  +10   63
 3. Werder Bremen                 34   9  4  4  33:15    9  1  7  35:22    68:37  +31   59
 4. Hertha BSC                    34   8  8  1  34:13    7  5  5  25:18    59:31  +28   58
 5. VfB Stuttgart                 34  12  2  3  34:15    5  5  7  20:25    54:40  +14   58
 6. Bayer 04 Leverkusen           34  12  3  2  42:18    4  6  7  23:26    65:44  +21   57
 7. Borussia Dortmund             34   8  5  4  24:18    7  5  5  23:26    47:44   +3   55
 8. Hamburger SV                  34   9  1  7  27:22    7  2  8  28:28    55:50   +5   51
 9. VfL Wolfsburg                 34  10  1  6  35:20    5  2 10  14:31    49:51   -2   48
10. Hannover 96                   34   8  2  7  21:19    5  4  8  13:17    34:36   -2   45
11. 1. FSV Mainz 05               34   9  3  5  28:21    3  4 10  22:34    50:55   -5   43
12. 1. FC Kaiserslautern          34   8  2  7  20:21    4  4  9  23:31    43:52   -9   42
13. Arminia Bielefeld             34   7  3  7  21:21    4  4  9  16:28    37:49  -12   40
14. 1. FC Nürnberg                34   4  6  7  25:25    6  2  9  30:38    55:63   -8   38
15. Bor. Mönchengladbach          34   8  5  4  26:21    0  7 10   9:30    35:51  -16   36
16. VfL Bochum                    34   6  5  6  30:29    3  3 11  17:39    47:68  -21   35
17. Hansa Rostock                 34   4  5  8  17:31    3  4 10  14:34    31:65  -34   30
18. SC Freiburg                   34   2  6  9  18:31    1  3 13  12:44    30:75  -45   18
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. 1. FC Köln                    34  12  4  1  38:13    8  3  6  24:20    62:33  +29   67
 2. MSV Duisburg                  34  13  2  2  35:18    6  3  8  15:19    50:37  +13   62
 3. Eintracht Frankfurt           34  14  0  3  35:12    5  4  8  30:27    65:39  +26   61
 4. TSV 1860 München              34  10  5  2  31:16    5  7  5  21:23    52:39  +13   57
 5. Greuther Fürth                34  11  2  4  30:20    6  3  8  21:22    51:42   +9   56
 6. Alemannia Aachen              34   9  3  5  40:22    7  3  7  20:18    60:40  +20   54
 7. FC Erzgebirge Aue             34  10  3  4  27:19    5  3  9  22:21    49:40   +9   51
 8. Dynamo Dresden                34  12  2  3  30:18    3  2 12  18:35    48:53   -5   49
 9. Wacker Burghausen             34   5  6  6  20:24    8  3  6  28:31    48:55   -7   48
10. Karlsruher SC                 34   7  6  4  23:15    4  4  9  23:32    46:47   -1   43
11. SpVgg Unterhaching            34   9  1  7  26:18    4  2 11  12:27    38:45   -7   42
12. 1. FC Saarbrücken             34   7  4  6  27:19    4  3 10  17:31    44:50   -6   40
13. Rot Weiss Ahlen               34   7  3  7  29:27    3  6  8  14:22    43:49   -6   39
14. Energie Cottbus               34   8  5  4  22:17    2  4 11  13:31    35:48  -13   39
15. Eintracht Trier               34   7  6  4  21:21    2  6  9  18:32    39:53  -14   39
16. Rot-Weiß Oberhausen           34   6  6  5  20:20    2  4 11  20:42    40:62  -22   34
17. Rot-Weiss Essen               34   6  6  5  24:26    0  9  8  11:25    35:51  -16   33
18. FC Rot-Weiß Erfurt            34   5  7  5  19:19    3  2 12  17:39    36:58  -22   33
```

(Source: [`2-bundesliga2.csv`](2-bundesliga2.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

