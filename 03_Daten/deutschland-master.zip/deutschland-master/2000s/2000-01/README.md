

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bayern München                34  12  1  4  37:20    7  5  5  25:17    62:37  +25   63
 2. FC Schalke 04                 34  12  4  1  36:13    6  4  7  29:22    65:35  +30   62
 3. Borussia Dortmund             34   9  4  4  34:20    7  6  4  28:22    62:42  +20   58
 4. Bayer 04 Leverkusen           34  10  2  5  30:16    7  4  6  24:24    54:40  +14   57
 5. Hertha BSC                    34  11  2  4  38:22    7  0 10  20:30    58:52   +6   56
 6. SC Freiburg                   34   9  5  3  36:15    6  5  6  18:22    54:37  +17   55
 7. Werder Bremen                 34  10  4  3  33:18    5  4  8  20:30    53:48   +5   53
 8. 1. FC Kaiserslautern          34   8  3  6  24:19    7  2  8  25:35    49:54   -5   50
 9. VfL Wolfsburg                 34   8  6  3  38:18    4  5  8  22:27    60:45  +15   47
10. 1. FC Köln                    34   8  5  4  33:18    4  5  8  26:34    59:52   +7   46
11. TSV 1860 München              34   8  3  6  23:25    4  5  8  20:30    43:55  -12   44
12. Hansa Rostock                 34   8  5  4  22:20    4  2 11  12:27    34:47  -13   43
13. Hamburger SV                  34   8  6  3  33:21    2  5 10  25:37    58:58        41
14. Energie Cottbus               34  10  1  6  27:20    2  2 13  11:32    38:52  -14   39
15. VfB Stuttgart                 34   9  5  3  31:20    0  6 11  11:29    42:49   -7   38
16. SpVgg Unterhaching            34   7  6  4  21:20    1  5 11  14:39    35:59  -24   35
17. Eintracht Frankfurt           34   8  3  6  26:22    2  2 13  15:46    41:68  -27   35
18. VfL Bochum                    34   5  4  8  20:28    2  2 13  10:39    30:67  -37   27
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. 1. FC Nürnberg                34  13  0  4  35:16    7  5  5  23:19    58:35  +23   65
 2. Bor. Mönchengladbach          34   9  6  2  33:11    8  5  4  29:20    62:31  +31   62
 3. FC St. Pauli                  34  10  5  2  39:21    7  4  6  31:31    70:52  +18   60
 4. VfR Mannheim                  34  11  3  3  41:19    6  5  6  16:23    57:42  +15   59
 5. Greuther Fürth                34  12  2  3  32:14    3  7  7  23:24    55:38  +17   54
 6. Rot Weiss Ahlen               34  11  2  4  33:21    4  7  6  28:32    61:53   +8   54
 7. SSV Reutlingen 05             34  12  4  1  44:18    3  4 10  20:34    64:52  +12   53
 8. 1. FC Saarbrücken             34   9  5  3  28:24    5  3  9  20:35    48:59  -11   50
 9. Hannover 96                   34   8  7  2  29:14    4  3 10  23:31    52:45   +7   46
10. Alemannia Aachen              34   9  3  5  21:15    4  4  9  21:45    42:60  -18   46
11. MSV Duisburg                  34   7  6  4  29:22    5  3  9  17:18    46:40   +6   45
12. Rot-Weiß Oberhausen           34   9  4  4  32:18    4  2 11  13:32    45:50   -5   45
13. Arminia Bielefeld             34   7  8  2  36:20    3  3 11  17:26    53:46   +7   41
14. 1. FSV Mainz 05               34   7  5  5  20:19    3  5  9  17:26    37:45   -8   40
15. Osnabrück                     34   7  5  5  24:21    2  5 10  16:31    40:52  -12   37
16. SSV Ulm 1846                  34   5  4  8  25:28    4  3 10  17:30    42:58  -16   34
17. Stuttgarter Kickers           34   6  5  6  18:23    2  5 10  13:28    31:51  -20   34
18. Chemnitzer FC                 34   2  3 12  12:32    1  4 12  12:46    24:78  -54   16
```

(Source: [`2-bundesliga2.csv`](2-bundesliga2.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

