

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Werder Bremen                 34  11  4  2  42:21   11  4  2  37:17    79:38  +41   74
 2. Bayern München                34  13  3  1  43:19    7  5  5  27:20    70:39  +31   68
 3. Bayer 04 Leverkusen           34  12  1  4  43:18    7  7  3  30:21    73:39  +34   65
 4. VfB Stuttgart                 34   9  7  1  29:13    9  3  5  23:11    52:24  +28   64
 5. VfL Bochum                    34  11  5  1  30:6     4  6  7  27:33    57:39  +18   56
 6. Borussia Dortmund             34  12  3  2  39:16    4  4  9  20:32    59:48  +11   55
 7. FC Schalke 04                 34   7  7  3  28:16    6  4  7  21:26    49:42   +7   50
 8. Hamburger SV                  34  11  3  3  33:22    3  4 10  14:38    47:60  -13   49
 9. Hansa Rostock                 34  10  1  6  34:18    2  7  8  21:36    55:54   +1   44
10. VfL Wolfsburg                 34  11  1  5  38:25    2  2 13  18:36    56:61   -5   42
11. Bor. Mönchengladbach          34   7  6  4  21:16    3  3 11  19:33    40:49   -9   39
12. Hertha BSC                    34   6  6  5  26:24    3  6  8  16:35    42:59  -17   39
13. 1. FC Kaiserslautern          34   8  5  4  25:19    3  1 13  14:43    39:62  -23   39
14. SC Freiburg                   34  10  3  4  32:25    0  5 12  10:42    42:67  -25   38
15. Hannover 96                   34   5  7  5  27:26    4  3 10  22:37    49:63  -14   37
16. Eintracht Frankfurt           34   6  4  7  25:24    3  1 13  11:29    36:53  -17   32
17. TSV 1860 München              34   5  4  8  16:25    3  4 10  16:30    32:55  -23   32
18. 1. FC Köln                    34   6  2  9  22:23    0  3 14  10:34    32:57  -25   23
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. 1. FC Nürnberg                34  12  3  2  35:13    6  4  7  33:32    68:45  +23   61
 2. Arminia Bielefeld             34   9  3  5  31:21    7  5  5  19:16    50:37  +13   56
 3. 1. FSV Mainz 05               34  10  5  2  30:15    3 10  4  19:19    49:34  +15   54
 4. Energie Cottbus               34  11  3  3  36:21    4  6  7  16:23    52:44   +8   54
 5. Rot-Weiß Oberhausen           34   7  4  6  26:27    8  4  5  26:21    52:48   +4   53
 6. Alemannia Aachen              34  11  4  2  29:14    4  4  9  22:37    51:51        53
 7. MSV Duisburg                  34   8  4  5  24:20    5  5  7  28:26    52:46   +6   48
 8. FC Erzgebirge Aue             34   8  7  2  25:15    4  5  8  22:30    47:45   +2   48
 9. Greuther Fürth                34   8  6  3  42:26    3  6  8  16:25    58:51   +7   45
10. Wacker Burghausen             34   7  5  5  24:14    5  4  8  16:25    40:39   +1   45
11. Eintracht Trier               34   8  6  3  28:18    4  3 10  18:33    46:51   -5   45
12. Rot Weiss Ahlen               34   7  5  5  22:18    5  3  9  14:27    36:45   -9   44
13. SpVgg Unterhaching            34   6  7  4  21:17    5  3  9  20:29    41:46   -5   43
14. Karlsruher SC                 34   8  3  6  22:20    3  7  7  16:24    38:44   -6   43
15. Lübeck                        34   4  8  5  23:29    5  4  8  24:28    47:57  -10   39
16. SSV Jahn Regensburg           34   6  6  5  17:21    3  6  8  20:30    37:51  -14   39
17. 1. FC Union Berlin            34   6  5  6  26:24    2  4 11  17:29    43:53  -10   33
18. Osnabrück                     34   6  3  8  26:22    1  4 12   9:33    35:55  -20   28
```

(Source: [`2-bundesliga2.csv`](2-bundesliga2.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

