

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Werder Bremen                 30   9  6  0  30:10    6  5  4  24:19    54:29  +25   56
 2. 1. FC Köln                    30   8  3  4  37:23    6  7  2  29:22    66:45  +21   52
 3. Borussia Dortmund             30   9  3  3  38:22    6  3  6  29:26    67:48  +19   51
 4. TSV 1860 München              30  11  2  2  48:20    3  5  7  22:30    70:50  +20   49
 5. Hannover 96                   30   9  3  3  30:17    4  4  7  18:25    48:42   +6   46
 6. MSV Duisburg                  30   8  5  2  29:21    4  3  8  17:27    46:48   -2   44
 7. 1. FC Nürnberg                30   9  4  2  28:15    2  6  7  16:23    44:38   +6   43
 8. Eintracht Frankfurt           30   4  4  7  24:33    7  3  5  26:25    50:58   -8   40
 9. Eintracht Braunschweig        30   7  5  3  21:13    3  3  9  21:34    42:47   -5   38
10. Hamburger SV                  30   8  2  5  28:25    3  3  9  18:31    46:56  -10   38
11. Borussia Neunkirchen          30   8  5  2  29:17    1  4 10  15:31    44:48   -4   36
12. 1. FC Kaiserslautern          30   9  1  5  24:17    2  2 11  17:36    41:53  -12   36
13. VfB Stuttgart                 30   8  3  4  31:25    1  5  9  15:25    46:50   -4   35
14. Karlsruher SC                 30   6  4  5  28:24    3  2 10  19:38    47:62  -15   33
15. Hertha BSC                    30   4  7  4  18:21    3  4  8  22:41    40:62  -22   32
16. FC Schalke 04                 30   5  5  5  24:26    2  3 10  21:34    45:60  -15   29
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

