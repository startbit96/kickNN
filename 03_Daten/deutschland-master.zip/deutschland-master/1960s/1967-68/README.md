

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. 1. FC Nürnberg                34  13  2  2  46:17    6  7  4  25:20    71:37  +34   66
 2. Werder Bremen                 34  11  2  4  36:27    7  6  4  32:24    68:51  +17   62
 3. Bor. Mönchengladbach          34   8  8  1  45:19    7  4  6  32:26    77:45  +32   57
 4. 1. FC Köln                    34  12  3  2  49:22    5  1 11  19:30    68:52  +16   55
 5. Bayern München                34  12  1  4  37:18    4  5  8  31:40    68:58  +10   54
 6. Eintracht Frankfurt           34  11  3  3  45:22    4  5  8  13:29    58:51   +7   53
 7. Eintracht Braunschweig        34  10  1  6  20:15    5  4  8  17:24    37:39   -2   50
 8. MSV Duisburg                  34   7  6  4  38:25    6  4  7  31:33    69:58  +11   49
 9. VfB Stuttgart                 34  12  2  3  37:15    2  5 10  28:39    65:54  +11   49
10. Alemannia Aachen              34  10  6  1  38:24    3  2 12  14:42    52:66  -14   47
11. Hannover 96                   34   9  7  1  32:18    3  3 11  16:34    48:52   -4   46
12. TSV 1860 München              34   8  2  7  35:19    3  9  5  20:20    55:39  +16   44
13. Hamburger SV                  34   6  7  4  28:22    5  4  8  23:32    51:54   -3   44
14. Borussia Dortmund             34  12  3  2  44:17    0  4 13  16:42    60:59   +1   43
15. FC Schalke 04                 34   7  5  5  19:17    4  3 10  23:31    42:48   -6   41
16. 1. FC Kaiserslautern          34   6  9  2  22:17    2  3 12  17:50    39:67  -28   36
17. Borussia Neunkirchen          34   7  4  6  23:32    0  1 16  10:61    33:93  -60   26
18. Karlsruher SC                 34   6  2  9  24:29    0  3 14   8:41    32:70  -38   23
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

