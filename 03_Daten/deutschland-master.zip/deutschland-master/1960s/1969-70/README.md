

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bor. Mönchengladbach          34  14  2  1  47:15    9  3  5  24:14    71:29  +42   74
 2. Bayern München                34  13  1  3  54:15    8  4  5  34:22    88:37  +51   68
 3. Hertha BSC                    34  14  2  1  42:12    6  3  8  25:29    67:41  +26   65
 4. 1. FC Köln                    34  13  0  4  58:18    7  3  7  25:20    83:38  +45   63
 5. Borussia Dortmund             34  12  4  1  36:18    2  4 11  24:49    60:67   -7   50
 6. VfB Stuttgart                 34  11  3  3  40:24    3  4 10  19:38    59:62   -3   49
 7. Hamburger SV                  34   9  3  5  36:29    3  8  6  21:25    57:54   +3   47
 8. Eintracht Frankfurt           34  10  5  2  38:20    2  5 10  16:34    54:54        46
 9. FC Schalke 04                 34   7  8  2  29:18    4  4  9  14:36    43:54  -11   45
10. 1. FC Kaiserslautern          34   9  6  2  28:19    1  6 10  16:36    44:55  -11   42
11. Werder Bremen                 34   8  6  3  22:16    2  5 10  16:31    38:47   -9   41
12. Hannover 96                   34  11  3  3  37:19    0  5 12  12:42    49:61  -12   41
13. Rot-Weiß Oberhausen           34   9  4  4  30:21    2  3 12  20:41    50:62  -12   40
14. Rot-Weiss Essen               34   7 10  0  29:17    1  5 11  12:37    41:54  -13   39
15. MSV Duisburg                  34   7  6  4  19:15    2  5 10  16:33    35:48  -13   38
16. Eintracht Braunschweig        34   7  4  6  23:21    2  6  9  17:28    40:49   -9   37
17. TSV 1860 München              34   8  4  5  23:15    1  3 13  18:41    41:56  -15   34
18. Alemannia Aachen              34   5  6  6  22:26    0  1 16   9:57    31:83  -52   22
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

