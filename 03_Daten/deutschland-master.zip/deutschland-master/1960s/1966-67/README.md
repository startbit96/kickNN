

### Standings


```
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Eintracht Braunschweig        34  13  3  1  35:8     4  6  7  14:19    49:27  +22   60
 2. TSV 1860 München              34  12  2  3  34:17    5  5  7  26:30    60:47  +13   58
 3. Borussia Dortmund             34  11  4  2  45:14    4  5  8  25:27    70:41  +29   54
 4. Eintracht Frankfurt           34  10  4  3  45:23    5  5  7  21:26    66:49  +17   54
 5. Bayern München                34  11  3  3  37:14    5  2 10  25:33    62:47  +15   53
 6. 1. FC Kaiserslautern          34  10  6  1  26:14    3  6  8  17:28    43:42   +1   51
 7. 1. FC Köln                    34   9  5  3  29:20    5  4  8  19:28    48:48        51
 8. Hannover 96                   34  11  3  3  30:17    2  5 10  10:29    40:46   -6   47
 9. Bor. Mönchengladbach          34   9  5  3  45:19    3  5  9  25:30    70:49  +21   46
10. 1. FC Nürnberg                34   6  6  5  24:26    6  4  7  19:24    43:50   -7   46
11. MSV Duisburg                  34   7  6  4  19:14    3  7  7  21:28    40:42   -2   43
12. VfB Stuttgart                 34   7  3  7  23:22    3 10  4  25:32    48:54   -6   43
13. Karlsruher SC                 34   8  6  3  34:25    3  3 11  20:37    54:62   -8   42
14. FC Schalke 04                 34   9  4  4  19:17    3  2 12  18:46    37:63  -26   42
15. Hamburger SV                  34   8  6  3  21:16    2  4 11  16:37    37:53  -16   40
16. Werder Bremen                 34   7  5  5  34:27    3  4 10  15:29    49:56   -7   39
17. Fortuna Düsseldorf            34   5  6  6  24:31    4  1 12  20:35    44:66  -22   34
18. Rot-Weiss Essen               34   5  7  5  24:23    1  6 10  11:30    35:53  -18   31
```

(Source: [`1-bundesliga.csv`](1-bundesliga.csv))



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

