% Dieses Skript variiert verschiedenste Parameter und durchläuft
% verschiedenste Konzepte des neuronalen Netzes.
% Diese werden anhand der Kriterien verglichen und abgespeichert, sodass am
% Ende ein neuronales Netz ausgewählt werden kann.
% Hintergrund ist das Generieren eines Verständnisses darüber, was welcher
% Parameter am neuronalen Netz im konkreten Fall bewirkt.

% Zeitmessung beginnen.
tStartzeit_Gesamt = tic;

% Verschiedene Features.
% Erstellung siehe "kickNN_featuregenerator_Vxxx.m"
features = 0;
anzahl_features = length(features);
anzahl_outputs = 2;

% Verschiedene Aktivierungsfunktionen.
% 1. Sigmoid.
% 2. Tanh.
% 3. ReLU.
% 4. Leaky ReLU.
% 5. Swish.
% 6. SVM.

% Verschiedene Anzahl an Hidden-Layers.
variation_anzahl_hiddenlayer = [1 2 5];
for anzahl_hiddenlayer = variation_anzahl_hiddenlayer
    % Verschiedene Anzahl an Knoten eines Hidden-Layers.
    variation_anzahl_knoten_hiddenlayer = [10 25 50 100];
    for anzahl_knoten_hiddenlayer = variation_anzahl_knoten_hiddenlayer
        % Variation des Regularization-Parameters Lambda.
        variation_lambda = [0.001, 0.003, 0.01, 0.03, 0.1, 0.3, 1, 3, 10];
        for lambda = variation_lambda
            % Initialisierungs-Parameter generieren.
            % Die Matrizen haben die Größe (s_j+1 x (s_j + 1)) --> +1 aufgrund der Bias-Unit.
            Theta = zufallsinitialisierung_gewichte_V001(anzahl_features, anzahl_hiddenlayer, anzahl_knoten_hiddenlayer, anzahl_outputs);
            % Paramter-Unrolling. (Matrizen werden zu einem langen Vektor)
            Theta_unroll = [];
            for iterTheta = 1:1:length(Theta)
                Theta_unroll = [Theta_unroll; Theta{iterTheta}(:)];         %#ok<AGROW>
            end
            
            % Optionen für Anlernen definieren.
            options = optimset('MaxIter', 50);
            
            % Funktionszeiger auf die Costfunction erzeugen.
            
            % Neuronales Netz anlernen.
            [Theta_unroll, Cost] = fmincg(costFunction, Theta_unroll, options);
            
            % Reshapen der Theta-Matrizen. (Langer Vektor wird zu Matrizen)
            for iterTheta = 1:1:length(Theta)
                
            end
            
            % Feedforward auf das Validationset.
            
            % Feedforward auf das Trainingsset.
            
        end
    end
end

% Zeitmessung beenden.
tEndzeit_Gesamt = toc(tStartzeit_Gesamt);