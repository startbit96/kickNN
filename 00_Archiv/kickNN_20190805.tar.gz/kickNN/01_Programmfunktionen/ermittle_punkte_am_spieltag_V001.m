function punkte = ermittle_punkte_am_spieltag_V001(liga, saison, team, spieltag)
% ERMITTLE_PUNKTE_AM_SPIELTAG_V001 Ermittelt für ein definiertes Team die
% Tabellenpunkte zu einem definierten Spieltag.

% Einlesen der Punktetabelle.
punktetabelle = evalin('base', 'punktetabelle');

% Finden der Position im Struct.
pos_daten = find((punktetabelle.liga == liga) & (punktetabelle.saison == saison));


if (isempty(pos_daten) == true)
    disp(['Punktetabelle für Liga ' num2str(liga) ' | Saison ' num2str(saison) ' existiert nicht!']);
    punkte = -1;
    return;
end

end

