function punktzahl = berechne_tabellenpunkte_V001(saison, spieltag, team_nummer)
% BERECHNE_PUNKTE_V001 Berechnet die Punkte eines Teams in einer
% definierten Saison und zu einem bestimmten Spieltag.

% Import der Datentabelle.
rohdatentabelle = evalin('base', 'rohdatentabelle');



end

