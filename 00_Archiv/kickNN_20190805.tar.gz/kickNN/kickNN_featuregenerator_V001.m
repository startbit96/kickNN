% Ermittlung der verschiedenen Features.
disp('Berechnung verschiedener Features für das neuronale Netz.');
disp(' ');

%% Feature-Variante 1:
disp('Feature-Variante 1:');
disp('- Spieltag');
disp('- Aktuelle Tabellenpunktzahl Team 1 und x vorherige Spiele.');
disp('- Aktuelle Tabellenpunktzahl Team 2 und x vorherige Spiele.');
disp(' ');

x = 0;
rohdatentabelle.feature1 = zeros(size(rohdatentabelle, 1), 3 + 2*x);

for i = 1:1:size(rohdatentabelle, 1)
    
end

% Feature-Scaling.

%% Feature-Variante 2:

%% Feature-Variante 3:
